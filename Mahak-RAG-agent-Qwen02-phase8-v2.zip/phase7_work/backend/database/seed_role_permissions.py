from backend.database.database import SessionLocal
from backend.models.role import Role
from backend.models.permission import Permission
from backend.models.role_permission import RolePermission


ROLE_PERMISSIONS = {
    "super_admin": "*",

    "admin": [
        "users.view",
        "users.manage",
        "products.view",
        "products.manage",
        "orders.view",
        "orders.manage",
        "payments.view",
        "payments.manage",
        "subscriptions.view",
        "subscriptions.manage",
        "reports.view",
        "settings.view",
        "settings.manage",
        "ai_admin.use",
    ],

    "manager": [
        "users.view",
        "products.view",
        "products.manage",
        "orders.view",
        "orders.manage",
        "payments.view",
        "subscriptions.view",
        "reports.view",
        "ai_admin.use",
    ],

    "staff": [
        "users.view",
        "products.view",
        "orders.view",
        "orders.manage",
        "payments.view",
    ],

    "user": [
        "products.view",
        "orders.view",
        "subscriptions.view",
    ],
}


def seed_role_permissions():
    db = SessionLocal()

    try:
        roles = {
            role.name: role
            for role in db.query(Role).all()
        }

        permissions = {
            permission.name: permission
            for permission in db.query(Permission).all()
        }

        for role_name, permission_names in ROLE_PERMISSIONS.items():

            role = roles.get(role_name)

            if not role:
                continue

            if permission_names == "*":
                selected_permissions = list(permissions.values())
            else:
                selected_permissions = [
                    permissions[name]
                    for name in permission_names
                    if name in permissions
                ]

            for permission in selected_permissions:

                existing = (
                    db.query(RolePermission)
                    .filter(
                        RolePermission.role_id == role.id,
                        RolePermission.permission_id == permission.id,
                    )
                    .first()
                )

                if not existing:
                    db.add(
                        RolePermission(
                            role_id=role.id,
                            permission_id=permission.id,
                        )
                    )

        db.commit()
        print("ROLE PERMISSIONS SEEDED")

    finally:
        db.close()


if __name__ == "__main__":
    seed_role_permissions()