from backend.database.database import SessionLocal
from backend.models.role import Role


ROLES = [
    ("super_admin", "مدیر ارشد سیستم"),
    ("admin", "مدیر سیستم"),
    ("manager", "مدیر بخش"),
    ("staff", "کارمند"),
    ("user", "کاربر عادی"),
]


def seed_roles():
    db = SessionLocal()

    try:
        for name, description in ROLES:
            existing = (
                db.query(Role)
                .filter(Role.name == name)
                .first()
            )

            if not existing:
                db.add(
                    Role(
                        name=name,
                        description=description,
                    )
                )

        db.commit()
        print("ROLES SEEDED")

    finally:
        db.close()


if __name__ == "__main__":
    seed_roles()