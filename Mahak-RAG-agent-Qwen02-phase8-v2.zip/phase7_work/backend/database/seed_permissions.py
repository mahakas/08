from backend.database.database import SessionLocal
from backend.models.permission import Permission


PERMISSIONS = [
    ("users.view", "مشاهده کاربران"),
    ("users.manage", "مدیریت کاربران"),

    ("products.view", "مشاهده محصولات"),
    ("products.manage", "مدیریت محصولات"),

    ("orders.view", "مشاهده سفارش‌ها"),
    ("orders.manage", "مدیریت سفارش‌ها"),

    ("payments.view", "مشاهده پرداخت‌ها"),
    ("payments.manage", "مدیریت پرداخت‌ها"),

    ("subscriptions.view", "مشاهده اشتراک‌ها"),
    ("subscriptions.manage", "مدیریت اشتراک‌ها"),

    ("reports.view", "مشاهده گزارش‌ها"),

    ("settings.view", "مشاهده تنظیمات"),
    ("settings.manage", "مدیریت تنظیمات"),

    ("ai_admin.use", "استفاده از دستیار هوشمند مدیر"),
]


def seed_permissions():
    db = SessionLocal()

    try:
        for name, description in PERMISSIONS:
            existing = (
                db.query(Permission)
                .filter(Permission.name == name)
                .first()
            )

            if not existing:
                db.add(
                    Permission(
                        name=name,
                        description=description,
                    )
                )

        db.commit()
        print("PERMISSIONS SEEDED")

    finally:
        db.close()


if __name__ == "__main__":
    seed_permissions()