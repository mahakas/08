from enum import StrEnum


class ChatMode(StrEnum):
    EDUCATIONAL = "educational"
    GENERAL = "general"


class SourceType(StrEnum):
    TXT = "txt"
    MD = "md"
    DOCX = "docx"
    PDF = "pdf"
    HTML = "html"
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"
    OTHER = "other"


class SourceStatus(StrEnum):
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    NEEDS_REVIEW = "needs_review"
    APPROVED = "approved"
    INDEXED = "indexed"
    FAILED = "failed"
    REJECTED = "rejected"


class SourceScope(StrEnum):
    PERMANENT = "permanent"
    SESSION = "session"


class JobStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    RETRYING = "retrying"


class ProviderStatus(StrEnum):
    ENABLED = "enabled"
    DISABLED = "disabled"


class Capability(StrEnum):
    CHAT = "chat"
    VISION = "vision"
    EMBEDDING = "embedding"
    RERANKING = "reranking"
    OCR = "ocr"
    TRANSCRIPTION = "transcription"
    STRUCTURED_OUTPUT = "structured_output"
    WEB_SEARCH = "web_search"
