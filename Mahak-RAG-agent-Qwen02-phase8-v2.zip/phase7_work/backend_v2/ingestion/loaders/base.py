from __future__ import annotations

from pathlib import Path
from typing import Protocol

from backend_v2.ingestion.analyzer import FileAnalysis
from backend_v2.ingestion.document import ExtractedDocument


class Loader(Protocol):
    def load(self, analysis: FileAnalysis) -> ExtractedDocument: ...


def require_exists(path: Path) -> None:
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(path)
