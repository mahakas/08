from __future__ import annotations

from PIL import Image

from backend_v2.core.enums import Capability, SourceType
from backend_v2.ingestion.analyzer import FileAnalysis
from backend_v2.ingestion.document import ExtractedDocument
from backend_v2.ingestion.loaders.base import require_exists


class ImageLoader:
    def load(self, analysis: FileAnalysis) -> ExtractedDocument:
        require_exists(analysis.path)
        with Image.open(analysis.path) as image:
            metadata = {
                "path": str(analysis.path),
                "format": image.format,
                "width": image.width,
                "height": image.height,
                "mode": image.mode,
            }
        return ExtractedDocument(
            source_type=SourceType.IMAGE,
            text="",
            title=analysis.path.stem,
            metadata=metadata,
            requires=frozenset({Capability.VISION}),
        )


class VideoLoader:
    def load(self, analysis: FileAnalysis) -> ExtractedDocument:
        require_exists(analysis.path)
        return ExtractedDocument(
            source_type=SourceType.VIDEO,
            text="",
            title=analysis.path.stem,
            metadata={"path": str(analysis.path)},
            requires=frozenset({Capability.VISION, Capability.TRANSCRIPTION}),
        )
