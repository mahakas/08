from __future__ import annotations

import re
from uuid import uuid4

from backend_v2.ingestion.document import ContentChunk, ExtractedDocument, SourceLocation


class TextChunker:
    def __init__(self, *, chunk_size: int = 900, overlap: int = 120) -> None:
        if chunk_size <= 0 or overlap < 0 or overlap >= chunk_size:
            raise ValueError("chunk_size must be > 0 and overlap must be >= 0 and < chunk_size")
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk(self, document: ExtractedDocument) -> list[ContentChunk]:
        if not document.text.strip():
            return []
        text = document.text.strip()
        pieces = self._paragraph_or_window_split(text)
        chunks: list[ContentChunk] = []
        cursor = 0
        for index, piece in enumerate(pieces):
            piece = piece.strip()
            if not piece:
                continue
            location = document.locations[index] if index < len(document.locations) else None
            chunks.append(
                ContentChunk(
                    chunk_id=str(uuid4()),
                    text=piece,
                    index=len(chunks),
                    metadata={"title": document.title, **document.metadata},
                    location=location,
                )
            )
            cursor += max(len(piece) - self.overlap, 0)
        return chunks

    def _paragraph_or_window_split(self, text: str) -> list[str]:
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
        if paragraphs and max(map(len, paragraphs)) <= self.chunk_size:
            result: list[str] = []
            current = ""
            for paragraph in paragraphs:
                candidate = f"{current}\n\n{paragraph}" if current else paragraph
                if len(candidate) <= self.chunk_size:
                    current = candidate
                else:
                    if current:
                        result.append(current)
                    current = paragraph
            if current:
                result.append(current)
            if result:
                return result

        result = []
        start = 0
        while start < len(text):
            end = min(start + self.chunk_size, len(text))
            if end < len(text):
                boundary = text.rfind(" ", start, end)
                if boundary > start + self.chunk_size // 2:
                    end = boundary
            result.append(text[start:end].strip())
            if end >= len(text):
                break
            start = max(end - self.overlap, start + 1)
        return result
