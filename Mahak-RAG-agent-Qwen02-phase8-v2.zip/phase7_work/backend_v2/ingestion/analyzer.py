from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from mimetypes import guess_type

from backend_v2.core.enums import Capability, SourceType


@dataclass(frozen=True, slots=True)
class FileAnalysis:
    path: Path
    source_type: SourceType
    mime_type: str | None
    size_bytes: int
    requires: frozenset[Capability] = field(default_factory=frozenset)

    @property
    def is_supported(self) -> bool:
        return self.source_type is not SourceType.OTHER

    @property
    def requires_vision(self) -> bool:
        return Capability.VISION in self.requires


class FileAnalyzer:
    EXTENSIONS: dict[str, SourceType] = {
        ".txt": SourceType.TXT,
        ".text": SourceType.TXT,
        ".md": SourceType.MD,
        ".markdown": SourceType.MD,
        ".docx": SourceType.DOCX,
        ".pdf": SourceType.PDF,
        ".html": SourceType.HTML,
        ".htm": SourceType.HTML,
        ".jpg": SourceType.IMAGE,
        ".jpeg": SourceType.IMAGE,
        ".png": SourceType.IMAGE,
        ".webp": SourceType.IMAGE,
        ".bmp": SourceType.IMAGE,
        ".gif": SourceType.IMAGE,
        ".mp4": SourceType.VIDEO,
        ".mov": SourceType.VIDEO,
        ".mkv": SourceType.VIDEO,
        ".webm": SourceType.VIDEO,
        ".avi": SourceType.VIDEO,
    }

    def analyze(self, path: Path) -> FileAnalysis:
        path = Path(path)
        source_type = self.EXTENSIONS.get(path.suffix.lower(), SourceType.OTHER)
        requires: set[Capability] = set()
        if source_type is SourceType.IMAGE:
            requires.add(Capability.VISION)
        if source_type is SourceType.VIDEO:
            requires.update({Capability.VISION, Capability.TRANSCRIPTION})
        if source_type is SourceType.PDF:
            # PDFs can be text-native or scanned; OCR/Vision is decided after extraction.
            pass
        mime_type, _ = guess_type(path.name)
        size_bytes = path.stat().st_size if path.exists() and path.is_file() else 0
        return FileAnalysis(
            path=path,
            source_type=source_type,
            mime_type=mime_type,
            size_bytes=size_bytes,
            requires=frozenset(requires),
        )
