from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from backend_v2.chat.context import ConversationContext
from backend_v2.chat.planner import QueryPlanner
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.retrieval.citation_builder import CitationRef, citation_from_hit
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalRequest, RetrievalService


NO_KNOWLEDGE_MESSAGE = "این سؤال در منابع آموزشی انتخاب‌شده برای این درس پیدا نشد."


@dataclass(frozen=True, slots=True)
class EducationalChatResponse:
    answer: str
    found: bool
    citations: tuple[CitationRef, ...]
    retrieval_count: int
    provider: str | None
    model: str | None
    fallback_available: bool = True


class EducationalChatService:
    """Educational closed-world chat: retrieve from scoped knowledge, then ask the LLM."""

    def __init__(
        self,
        retrieval: RetrievalService,
        llm_orchestrator: ProviderOrchestrator,
        *,
        planner: QueryPlanner | None = None,
        collection: str = "mahak_knowledge",
        top_k: int = 8,
        min_score: float = 0.35,
    ) -> None:
        self.retrieval = retrieval
        self.llm_orchestrator = llm_orchestrator
        self.planner = planner or QueryPlanner()
        self.collection = collection
        self.top_k = top_k
        self.min_score = min_score

    def ask(self, context: ConversationContext, query: str, *, has_file: bool = False) -> EducationalChatResponse:
        if context.mode is not ChatMode.EDUCATIONAL:
            raise ValueError("EducationalChatService requires educational conversation mode")
        clean_query = str(query).strip()
        if not clean_query:
            raise ValueError("Message cannot be empty")

        plan = self.planner.plan(context, has_file=has_file)
        if not plan.enabled:
            raise RuntimeError("Educational retrieval plan is disabled")

        scope = RetrievalScope(
            grade_id=context.grade_id,
            subject_id=context.subject_id,
            course_id=context.course_id,
            chapter_id=context.chapter_id,
            lesson_id=context.lesson_id,
            source_ids=tuple(context.session_file_ids),
        )
        retrieval_result = self.retrieval.retrieve(
            RetrievalRequest(
                clean_query,
                scope,
                self.collection,
                top_k=self.top_k,
                min_score=self.min_score,
            )
        )

        if not retrieval_result.found:
            context.add_message("user", clean_query)
            context.add_message("assistant", NO_KNOWLEDGE_MESSAGE, retrieval_found=False)
            return EducationalChatResponse(
                answer=NO_KNOWLEDGE_MESSAGE,
                found=False,
                citations=(),
                retrieval_count=0,
                provider=None,
                model=None,
            )

        citations = tuple(citation_from_hit(hit) for hit in retrieval_result.accepted)
        prompt = self._build_prompt(context, clean_query, retrieval_result.accepted)
        orchestration = self.llm_orchestrator.execute(
            Capability.CHAT,
            {"messages": prompt, "mode": "educational"},
            metadata={"conversation_id": context.conversation_id, "citation_count": len(citations)},
        )
        answer = self._normalize_answer(orchestration.response.output)
        context.add_message("user", clean_query)
        context.add_message(
            "assistant",
            answer,
            retrieval_found=True,
            citations=[asdict(citation) for citation in citations],
        )
        return EducationalChatResponse(
            answer=answer,
            found=True,
            citations=citations,
            retrieval_count=len(citations),
            provider=orchestration.response.provider,
            model=orchestration.response.model,
        )

    @staticmethod
    def _build_prompt(context: ConversationContext, query: str, hits: list[Any]) -> list[dict[str, str]]:
        source_blocks = []
        for index, hit in enumerate(hits, start=1):
            title = hit.metadata.get("title") or hit.metadata.get("source_title") or "منبع"
            source_blocks.append(f"[منبع {index}] {title}\n{hit.document}")
        system = (
            "تو دستیار آموزشی ماهک هستی. فقط بر اساس منابع داده‌شده پاسخ بده. "
            "اگر منابع برای ادعا کافی نیستند، صریحاً بگو اطلاعات کافی در منابع نیست. "
            "پاسخ را به فارسی، آموزشی و دقیق بده و ادعای بدون منبع نساز."
        )
        scope = (
            f"پایه={context.grade_id or '-'}، درس={context.subject_id or '-'}، "
            f"دوره={context.course_id or '-'}، فصل={context.chapter_id or '-'}، مبحث={context.lesson_id or '-'}"
        )
        user = f"حوزه آموزشی: {scope}\n\nمنابع:\n" + "\n\n".join(source_blocks) + f"\n\nسؤال دانش‌آموز:\n{query}"
        return [{"role": "system", "content": system}, {"role": "user", "content": user}]

    @staticmethod
    def _normalize_answer(output: Any) -> str:
        if isinstance(output, str):
            return output.strip()
        if isinstance(output, dict):
            for key in ("answer", "content", "text", "output"):
                value = output.get(key)
                if isinstance(value, str):
                    return value.strip()
        return str(output).strip()
