from __future__ import annotations

from fastapi import APIRouter

from backend_v2.chat.context import ConversationContext
from dataclasses import asdict

from backend_v2.chat.educational import EducationalChatResponse, EducationalChatService
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.retrieval.service import RetrievalService
from backend_v2.schemas.chat import CitationOut, EducationalChatRequest, EducationalChatResponseOut
from backend_v2.vectorstores.embedding import EmbeddingService
from backend_v2.vectorstores.memory import InMemoryVectorStore

router = APIRouter(prefix="/chat", tags=["chat"])


def _build_default_service() -> EducationalChatService:
    registry = ProviderRegistry()
    embedding_adapter = MockProviderAdapter("default-embedding", {Capability.EMBEDDING}, default_model="embed-v1", embedding_dimension=8)
    chat_adapter = MockProviderAdapter(
        "default-chat",
        {Capability.CHAT},
        default_model="chat-v1",
        handler=lambda payload: "پاسخ آموزشی تولیدشده بر اساس منابع بازیابی‌شده.",
    )
    registry.register(embedding_adapter, priority=1)
    registry.register(chat_adapter, priority=1)
    health = ProviderHealthManager()
    embedding = EmbeddingService(ProviderOrchestrator(registry, health))
    retrieval = RetrievalService(InMemoryVectorStore(), embedding)
    llm = ProviderOrchestrator(registry, health)
    return EducationalChatService(retrieval, llm)


@router.post("/educational", response_model=EducationalChatResponseOut)
def educational_chat(request: EducationalChatRequest):
    service = _build_default_service()
    context = ConversationContext(
        conversation_id=request.conversation_id,
        user_id=None,
        mode=ChatMode.EDUCATIONAL,
        grade_id=request.grade_id,
        subject_id=request.subject_id,
        course_id=request.course_id,
        chapter_id=request.chapter_id,
        lesson_id=request.lesson_id,
        session_file_ids=request.session_file_ids,
    )
    result: EducationalChatResponse = service.ask(context, request.query, has_file=bool(request.session_file_ids))
    return EducationalChatResponseOut(
        answer=result.answer,
        found=result.found,
        retrieval_count=result.retrieval_count,
        provider=result.provider,
        model=result.model,
        fallback_available=result.fallback_available,
        citations=[CitationOut(**asdict(citation)) for citation in result.citations],
    )
