from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend_v2.api.dependencies import get_db
from backend_v2.database.repositories import CatalogRepository
from backend_v2.schemas import CourseCreate, CourseOut, GradeCreate, GradeOut, SubjectCreate, SubjectOut

router = APIRouter(prefix="/catalog", tags=["catalog"])


@router.get("/grades", response_model=list[GradeOut])
def list_grades(db: Session = Depends(get_db)):
    return CatalogRepository(db).list_grades()


@router.post("/grades", response_model=GradeOut, status_code=status.HTTP_201_CREATED)
def create_grade(payload: GradeCreate, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    if repo.get_grade_by_name(payload.name):
        raise HTTPException(409, "Grade already exists")
    obj = repo.create_grade(payload.name, payload.sort_order)
    db.commit()
    return obj


@router.get("/grades/{grade_id}/subjects", response_model=list[SubjectOut])
def list_subjects(grade_id: str, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    if not repo.get_grade(grade_id):
        raise HTTPException(404, "Grade not found")
    return repo.list_subjects(grade_id)


@router.post("/grades/{grade_id}/subjects", response_model=SubjectOut, status_code=status.HTTP_201_CREATED)
def create_subject(grade_id: str, payload: SubjectCreate, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    if not repo.get_grade(grade_id):
        raise HTTPException(404, "Grade not found")
    if repo.get_subject_by_name(grade_id, payload.name):
        raise HTTPException(409, "Subject already exists for this grade")
    obj = repo.create_subject(grade_id, payload.name, payload.sort_order)
    db.commit()
    return obj


@router.get("/subjects/{subject_id}/courses", response_model=list[CourseOut])
def list_courses(subject_id: str, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    if not repo.get_subject(subject_id):
        raise HTTPException(404, "Subject not found")
    return repo.list_courses(subject_id)


@router.post("/subjects/{subject_id}/courses", response_model=CourseOut, status_code=status.HTTP_201_CREATED)
def create_course(subject_id: str, payload: CourseCreate, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    if not repo.get_subject(subject_id):
        raise HTTPException(404, "Subject not found")
    obj = repo.create_course(subject_id, payload.name, payload.description)
    db.commit()
    return obj


@router.delete("/grades/{grade_id}", status_code=status.HTTP_204_NO_CONTENT)
def disable_grade(grade_id: str, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    obj = repo.get_grade(grade_id)
    if not obj:
        raise HTTPException(404, "Grade not found")
    obj.is_active = False
    db.commit()


@router.delete("/subjects/{subject_id}", status_code=status.HTTP_204_NO_CONTENT)
def disable_subject(subject_id: str, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    obj = repo.get_subject(subject_id)
    if not obj:
        raise HTTPException(404, "Subject not found")
    obj.is_active = False
    db.commit()


@router.delete("/courses/{course_id}", status_code=status.HTTP_204_NO_CONTENT)
def disable_course(course_id: str, db: Session = Depends(get_db)):
    repo = CatalogRepository(db)
    obj = repo.get_course(course_id)
    if not obj:
        raise HTTPException(404, "Course not found")
    obj.is_active = False
    db.commit()
