from __future__ import annotations

from fastapi import APIRouter

from backend_v2.chat.context import ConversationContext
from backend_v2.chat.general import FileContext, GeneralChatService, InMemoryFileContextProvider
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.schemas.general_chat import GeneralChatRequest, GeneralChatResponseOut, GeneralCitationOut
from backend_v2.web.search import InMemoryWebSearchAdapter, WebSearchResult

router = APIRouter(prefix="/chat", tags=["chat"])


def _build_service() -> GeneralChatService:
    registry = ProviderRegistry()

    def handler(payload):
        return "پاسخ عمومی تولیدشده بر اساس زمینهٔ ارائه‌شده."

    chat = MockProviderAdapter("default-general-chat", {Capability.CHAT}, handler, default_model="general-chat-v1")
    registry.register(chat, priority=1)
    orchestrator = ProviderOrchestrator(registry, ProviderHealthManager())

    web = InMemoryWebSearchAdapter({
        "آخرین اخبار فناوری": [
            WebSearchResult("نمونه خبر فناوری", "https://example.test/news", "این یک نتیجهٔ نمونه برای تست است.", source="mock-web")
        ]
    })
    files = InMemoryFileContextProvider({
        "sample-file": FileContext("sample-file", "فایل نمونه", "این محتوای فایل نمونه برای تست چت عمومی است."),
    })
    return GeneralChatService(orchestrator, web_search=web, file_context=files)


@router.post("/general", response_model=GeneralChatResponseOut)
def general_chat(request: GeneralChatRequest):
    context = ConversationContext(
        conversation_id=request.conversation_id,
        user_id=None,
        mode=ChatMode.GENERAL,
        session_file_ids=request.session_file_ids,
    )
    result = _build_service().ask(context, request.query, use_web=request.use_web, top_k_web=request.top_k_web)
    return GeneralChatResponseOut(
        answer=result.answer,
        used_web=result.used_web,
        used_files=result.used_files,
        provider=result.provider,
        model=result.model,
        web_provider=result.web_provider,
        citations=[GeneralCitationOut(title=c.title, url=c.url, snippet=c.snippet) for c in result.citations],
    )
