from __future__ import annotations

from uuid import uuid4
from sqlalchemy import Boolean, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from backend_v2.database.connection import Base


def uid() -> str:
    return str(uuid4())


class VectorIndex(Base):
    __tablename__ = "vector_indexes"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uid)
    name: Mapped[str] = mapped_column(String(200), unique=True, nullable=False)
    backend: Mapped[str] = mapped_column(String(100), nullable=False)
    collection_name: Mapped[str] = mapped_column(String(200), nullable=False)
    embedding_profile_id: Mapped[str] = mapped_column(ForeignKey("embedding_profiles.id"), nullable=False)
    dimension: Mapped[int] = mapped_column(Integer, nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
