# پوشهٔ دیتا

فایل‌های متنی و تصویری خودت را اینجا بریز — ایجنت فقط از همین دیتا جواب می‌دهد:

| فرمت | توضیح |
|---|---|
| `.docx` | متن پاراگراف‌ها |
| `.pdf` | متن همهٔ صفحه‌ها (pypdf / pdfplumber) |
| `.txt` / `.md` | متن خام |
| `.html` / `.htm` | متن بدون تگ |
| `.png` / `.jpg` / `.webp` / `.bmp` / `.gif` / `.tiff` | تحلیل با Vision Model (qwen/gemini) یا OCR |
| `.doc` | پشتیبانی نمی‌شود — اول به `.docx` تبدیل کن |

هر فایل یک منبع است — می‌تواند اسکریپت ویدیو، جزوهٔ درسی، مستندات کار، یا هر متنی باشد که می‌خواهی ایجنت از رویش جواب بدهد.

بعد از گذاشتن فایل‌ها، ایندکس را بساز:

```bash
python ingest.py            # اسناد + تصاویر
python ingest.py --no-images    # فقط اسناد
python ingest.py --only-images  # فقط تصاویر
```

اختیاری: فایل `metadata.csv` یا `metadata.xlsx` کنار همین پوشه بساز با ستون‌های `file`, `title`, `url` تا جواب‌ها به منبع لینک بخورند.

---

Put your data files here — text sources (`.docx`, `.pdf`, `.txt`, `.md`, `.html`) and images (analyzed by a Vision model / OCR).
Then run `python ingest.py` to build the index.
