from fastapi import FastAPI

app = FastAPI(
    title="Mahak AI Backend",
    version="1.0.0",
    description="Backend API for Mahak General AI"
)


@app.get("/")
def root():
    return {
        "status": "online",
        "service": "Mahak AI Backend",
        "version": "1.0.0"
    }


@app.get("/health")
def health():
    return {
        "status": "healthy"
    }