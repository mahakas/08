from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class ConversationMemory:
    max_messages: int = 50

    messages: List[Dict[str, str]] = field(default_factory=list)

    def add_user_message(self, content: str) -> None:
        content = content.strip()

        if not content:
            return

        self.messages.append({
            "role": "user",
            "content": content,
        })

        self._limit_messages()

    def add_assistant_message(self, content: str) -> None:
        content = content.strip()

        if not content:
            return

        self.messages.append({
            "role": "assistant",
            "content": content,
        })

        self._limit_messages()

    def add_message(self, role: str, content: str) -> None:
        content = content.strip()

        if not content:
            return

        self.messages.append({
            "role": role,
            "content": content,
        })

        self._limit_messages()

    def get_messages(self) -> List[Dict[str, str]]:
        return list(self.messages)

    def get_recent(self, count: int = 10) -> List[Dict[str, str]]:
        if count <= 0:
            return []

        return self.messages[-count:]

    def clear(self) -> None:
        self.messages.clear()

    def _limit_messages(self) -> None:
        if self.max_messages <= 0:
            self.messages.clear()
            return

        if len(self.messages) > self.max_messages:
            self.messages = self.messages[-self.max_messages:]


class MemoryManager:

    def __init__(self, max_messages: int = 50):
        self.max_messages = max_messages
        self._sessions: Dict[str, ConversationMemory] = {}

    def get_session(self, session_id: str) -> ConversationMemory:
        if session_id not in self._sessions:
            self._sessions[session_id] = ConversationMemory(
                max_messages=self.max_messages
            )

        return self._sessions[session_id]

    def add_user_message(
        self,
        session_id: str,
        content: str,
    ) -> None:
        self.get_session(session_id).add_user_message(content)

    def add_assistant_message(
        self,
        session_id: str,
        content: str,
    ) -> None:
        self.get_session(session_id).add_assistant_message(content)

    def get_messages(
        self,
        session_id: str,
    ) -> List[Dict[str, str]]:
        return self.get_session(session_id).get_messages()

    def get_recent(
        self,
        session_id: str,
        count: int = 10,
    ) -> List[Dict[str, str]]:
        return self.get_session(session_id).get_recent(count)

    def clear_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)

    def clear_all(self) -> None:
        self._sessions.clear()


if __name__ == "__main__":
    memory = ConversationMemory(max_messages=10)

    memory.add_user_message("سلام")
    memory.add_assistant_message("سلام! چطور می‌توانم کمک کنم؟")
    memory.add_user_message("تو چه کاری انجام می‌دهی؟")

    print("=" * 60)
    print("GENERAL AI MEMORY TEST")
    print("=" * 60)

    for message in memory.get_messages():
        print(f"{message['role']}: {message['content']}")