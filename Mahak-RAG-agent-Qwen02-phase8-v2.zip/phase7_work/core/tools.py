from __future__ import annotations

import ast
import math
import operator
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional


@dataclass
class ToolResult:
    success: bool
    tool: str
    result: Any
    error: Optional[str] = None


class ToolRegistry:

    def __init__(self):
        self.tools: Dict[str, Callable[..., Any]] = {}

    def register(self, name: str, function: Callable[..., Any]) -> None:
        self.tools[name] = function

    def get(self, name: str) -> Optional[Callable[..., Any]]:
        return self.tools.get(name)

    def list_tools(self) -> List[str]:
        return list(self.tools.keys())

    def execute(self, name: str, **kwargs) -> ToolResult:
        function = self.get(name)

        if function is None:
            return ToolResult(
                success=False,
                tool=name,
                result=None,
                error=f"Tool not found: {name}",
            )

        try:
            result = function(**kwargs)

            return ToolResult(
                success=True,
                tool=name,
                result=result,
            )

        except Exception as exc:
            return ToolResult(
                success=False,
                tool=name,
                result=None,
                error=str(exc),
            )


# ---------------------------------------------------------
# Safe calculator
# ---------------------------------------------------------

_ALLOWED_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}


def _safe_eval(node: ast.AST) -> float:

    if isinstance(node, ast.Constant):

        if isinstance(node.value, (int, float)):
            return node.value

        raise ValueError("Invalid number.")

    if isinstance(node, ast.UnaryOp):

        operation = _ALLOWED_OPERATORS.get(type(node.op))

        if operation is None:
            raise ValueError("Invalid unary operator.")

        return operation(
            _safe_eval(node.operand)
        )

    if isinstance(node, ast.BinOp):

        operation = _ALLOWED_OPERATORS.get(type(node.op))

        if operation is None:
            raise ValueError("Invalid operator.")

        left = _safe_eval(node.left)
        right = _safe_eval(node.right)

        return operation(left, right)

    raise ValueError("Unsupported expression.")


def calculate(expression: str) -> float:

    expression = (
        expression.strip()
        .replace("×", "*")
        .replace("÷", "/")
        .replace("^", "**")
    )

    if not expression:
        raise ValueError("Expression is empty.")

    tree = ast.parse(
        expression,
        mode="eval",
    )

    result = _safe_eval(tree.body)

    return result


# ---------------------------------------------------------
# Text tools
# ---------------------------------------------------------

def count_words(text: str) -> int:
    return len(text.split())


def count_characters(text: str) -> int:
    return len(text)


def reverse_text(text: str) -> str:
    return text[::-1]


def uppercase_text(text: str) -> str:
    return text.upper()


def lowercase_text(text: str) -> str:
    return text.lower()


# ---------------------------------------------------------
# Math tools
# ---------------------------------------------------------

def square_root(number: float) -> float:
    return math.sqrt(number)


def power(base: float, exponent: float) -> float:
    return base ** exponent


def absolute(number: float) -> float:
    return abs(number)


# ---------------------------------------------------------
# Default registry
# ---------------------------------------------------------

def create_default_registry() -> ToolRegistry:

    registry = ToolRegistry()

    registry.register(
        "calculate",
        calculate,
    )

    registry.register(
        "count_words",
        count_words,
    )

    registry.register(
        "count_characters",
        count_characters,
    )

    registry.register(
        "reverse_text",
        reverse_text,
    )

    registry.register(
        "uppercase_text",
        uppercase_text,
    )

    registry.register(
        "lowercase_text",
        lowercase_text,
    )

    registry.register(
        "square_root",
        square_root,
    )

    registry.register(
        "power",
        power,
    )

    registry.register(
        "absolute",
        absolute,
    )

    return registry


# ---------------------------------------------------------
# Test
# ---------------------------------------------------------

if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI TOOLS TEST")
    print("=" * 60)

    tools = create_default_registry()

    print()
    print("Available tools:")
    print(tools.list_tools())

    print()
    print("Calculator test:")

    result = tools.execute(
        "calculate",
        expression="25 * 40 + 10",
    )

    print("Success:", result.success)
    print("Result:", result.result)

    print()
    print("Text test:")

    result = tools.execute(
        "count_words",
        text="Hello this is a general AI",
    )

    print("Success:", result.success)
    print("Word count:", result.result)

    print()
    print("Square root test:")

    result = tools.execute(
        "square_root",
        number=144,
    )

    print("Success:", result.success)
    print("Result:", result.result)

    print()
    print("Tools module is working correctly.")