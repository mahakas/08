from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class RouteResult:
    route: str
    reason: str
    confidence: float


class RequestRouter:

    def __init__(self):

        self.video_keywords: List[str] = [
            "video",
            "ভিডিও",
            "فیلم",
            "ویدئو",
            "ویدیو",
            "analyze video",
            "analyse video",
        ]

        self.rag_keywords: List[str] = [
            "pdf",
            "document",
            "file",
            "knowledge base",
            "knowledgebase",
            "knowledge",
            "database",
            "my files",
            "my documents",
            "document search",
            "search my file",
            "search my pdf",
            "from my files",
            "from the knowledge base",
            "in the knowledge base",
            "based on my file",
            "based on the document",
            "بر اساس فایل",
            "فایل من",
            "فایل",
            "پی دی اف",
            "pdf من",
            "دانش",
            "پایگاه دانش",
            "پایگاه داده",
        ]

        self.web_keywords: List[str] = [
            "latest news",
            "latest",
            "news",
            "current news",
            "today",
            "recent",
            "search web",
            "search online",
            "internet",
            "online",
            "website",
            "web search",
            "سایت",
            "اینترنت",
            "اخبار",
            "خبر",
            "جدیدترین",
            "امروز",
            "اخبار امروز",
        ]

        self.tool_keywords: List[str] = [
            "calculate",
            "compute",
            "calculator",
            "calculate:",
            "sum",
            "multiply",
            "divide",
            "subtract",
            "add",
            "sqrt",
            "square root",
            "محاسبه",
            "حساب کن",
        ]

    def _contains_any(
        self,
        text: str,
        keywords: List[str],
    ) -> bool:

        text = text.lower()

        return any(
            keyword.lower() in text
            for keyword in keywords
        )

    def classify(
        self,
        user_input: str,
    ) -> RouteResult:

        text = user_input.strip().lower()

        if not text:

            return RouteResult(
                route="chat",
                reason="Empty input",
                confidence=0.5,
            )

        # -------------------------------------------------
        # 1. Video
        # -------------------------------------------------

        if self._contains_any(
            text,
            self.video_keywords,
        ):

            return RouteResult(
                route="video",
                reason="Video-related request detected",
                confidence=0.90,
            )

        # -------------------------------------------------
        # 2. RAG / Knowledge Base
        # -------------------------------------------------

        if self._contains_any(
            text,
            self.rag_keywords,
        ):

            return RouteResult(
                route="rag",
                reason="Knowledge-base or document request detected",
                confidence=0.92,
            )

        # -------------------------------------------------
        # 3. Web
        # -------------------------------------------------

        if self._contains_any(
            text,
            self.web_keywords,
        ):

            return RouteResult(
                route="web",
                reason="Web or current-information request detected",
                confidence=0.85,
            )

        # -------------------------------------------------
        # 4. Tools
        # -------------------------------------------------

        if self._contains_any(
            text,
            self.tool_keywords,
        ):

            return RouteResult(
                route="tool",
                reason="Tool or calculation request detected",
                confidence=0.80,
            )

        # -------------------------------------------------
        # 5. General chat
        # -------------------------------------------------

        return RouteResult(
            route="chat",
            reason="General conversation request",
            confidence=0.70,
        )


if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI ROUTER TEST")
    print("=" * 60)

    router = RequestRouter()

    tests = [
        "hello",
        "what is the latest news?",
        "search my PDF file",
        "what is the test text in the knowledge base?",
        "analyze this video",
        "calculate 25 times 40",
        "write a story for me",
    ]

    for text in tests:

        result = router.classify(text)

        print()
        print(text)
        print("Route:", result.route)
        print("Reason:", result.reason)
        print("Confidence:", result.confidence)

    print()
    print("Router test completed.")