"""
Central Error Handler
General AI Project
"""

from dataclasses import dataclass
from typing import Optional
import traceback


@dataclass
class ErrorResult:
    success: bool
    message: str
    error_type: str = ""
    route: str = ""
    details: str = ""


class ErrorHandler:
    """
    Central error handling system for the General AI.
    """

    def __init__(self, debug: bool = False):
        self.debug = debug

    def handle(
        self,
        error: Exception,
        route: str = "",
        user_message: Optional[str] = None,
    ) -> ErrorResult:

        error_type = type(error).__name__
        details = str(error)

        if self.debug:
            details = traceback.format_exc()

        message = self._friendly_message(
            error_type=error_type,
            route=route,
            error_message=str(error),
        )

        return ErrorResult(
            success=False,
            message=message,
            error_type=error_type,
            route=route,
            details=details,
        )

    def _friendly_message(
        self,
        error_type: str,
        route: str,
        error_message: str,
    ) -> str:

        route_name = route or "unknown"

        if "Connection" in error_type:
            return (
                "اتصال به سرویس موردنیاز برقرار نشد. "
                "لطفاً دوباره تلاش کنید."
            )

        if "Timeout" in error_type:
            return (
                "زمان پاسخ سرویس تمام شد. "
                "لطفاً دوباره تلاش کنید."
            )

        if "Permission" in error_type:
            return (
                "دسترسی لازم برای این سرویس وجود ندارد."
            )

        if "FileNotFound" in error_type:
            return (
                "فایل یا منبع موردنظر پیدا نشد."
            )

        if route_name == "rag":
            return (
                "در پردازش اطلاعات پایگاه دانش خطایی رخ داد."
            )

        if route_name == "web":
            return (
                "در جستجوی اینترنتی خطایی رخ داد."
            )

        if route_name == "video":
            return (
                "در پردازش ویدئو خطایی رخ داد."
            )

        if route_name == "tool":
            return (
                "در اجرای ابزار موردنظر خطایی رخ داد."
            )

        return (
            "در پردازش درخواست خطایی رخ داد. "
            "لطفاً دوباره تلاش کنید."
        )

    def safe_execute(self, function, *args, route: str = "", **kwargs):
        """
        Execute a function safely.

        Returns:
            (result, None) on success
            (None, ErrorResult) on failure
        """

        try:
            result = function(*args, **kwargs)
            return result, None

        except Exception as error:
            return None, self.handle(
                error=error,
                route=route,
            )


def create_error_handler(debug: bool = False) -> ErrorHandler:
    return ErrorHandler(debug=debug)


if __name__ == "__main__":
    print("GENERAL AI - ERROR HANDLER TEST")
    print("-" * 40)

    handler = create_error_handler(debug=True)

    def working_function():
        return "OK"

    def failing_function():
        raise ConnectionError("Test connection failure")

    result, error = handler.safe_execute(
        working_function,
        route="chat",
    )

    print("Working function:")
    print("Result:", result)
    print("Error:", error)

    result, error = handler.safe_execute(
        failing_function,
        route="web",
    )

    print("\nFailing function:")
    print("Result:", result)

    if error:
        print("Success:", error.success)
        print("Message:", error.message)
        print("Type:", error.error_type)
        print("Route:", error.route)

    print("\nERROR HANDLER TEST COMPLETED")