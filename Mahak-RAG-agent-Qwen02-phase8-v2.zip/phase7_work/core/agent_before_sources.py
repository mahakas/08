from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from core.memory import MemoryManager
from core.context import create_context_manager
from core.error_handler import create_error_handler

from core.prompts import (
    get_system_prompt,
    build_chat_prompt,
    build_rag_prompt,
    build_web_prompt,
    build_video_prompt,
    build_tool_prompt,
)

from core.router import RequestRouter
from core.tools import create_default_registry
from core.web_search import WebSearchEngine

from rag.vector_store import VectorStoreManager
from rag.video_retriever import VideoRetriever

from video_citation import (
    build_citations_from_agent_sources,
    format_sources_block,
)

from security.guard import create_security_guard


@dataclass
class AIState:
    user_input: str
    messages: List[Dict[str, str]] = field(default_factory=list)
    history: List[Dict[str, str]] = field(default_factory=list)
    context: str = ""
    sources: List[Dict[str, Any]] = field(default_factory=list)
    tool_results: List[Dict[str, Any]] = field(default_factory=list)
    route: str = "chat"
    answer: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


class GeneralAI:

    def __init__(self, session_id: str = "default"):

        self.session_id = session_id

        # -------------------------------------------------
        # Core systems
        # -------------------------------------------------

        self.memory = MemoryManager()
        self.context_manager = create_context_manager()

        # Central Error Handler
        self.error_handler = create_error_handler(
            debug=False
        )

        self.router = RequestRouter()
        self.tools = create_default_registry()

        # -------------------------------------------------
        # Security
        # -------------------------------------------------

        self.security = create_security_guard()

        # -------------------------------------------------
        # RAG
        # -------------------------------------------------

        self.vector_store = VectorStoreManager()

        # -------------------------------------------------
        # Web
        # -------------------------------------------------

        self.web_search = WebSearchEngine()

        # -------------------------------------------------
        # Video
        # -------------------------------------------------

        self.video_retriever = VideoRetriever()

        # -------------------------------------------------
        # System prompt
        # -------------------------------------------------

        self.system_prompt = get_system_prompt()

    # =====================================================
    # State
    # =====================================================

    def create_state(self, user_input: str) -> AIState:

        history = self.memory.get_messages(
            self.session_id
        )

        conversation_context = (
            self.context_manager.get_context(
                self.session_id
            )
        )

        return AIState(
            user_input=user_input,
            history=history,
            context=conversation_context,
        )

    # =====================================================
    # Central error handling
    # =====================================================

    def handle_error(
        self,
        state: AIState,
        error: Exception,
        route: str = "",
    ) -> AIState:

        error_result = self.error_handler.handle(
            error=error,
            route=route or state.route,
            user_message=state.user_input,
        )

        state.metadata["error"] = True
        state.metadata["error_type"] = (
            error_result.error_type
        )
        state.metadata["error_route"] = (
            error_result.route
        )
        state.metadata["error_details"] = (
            error_result.details
        )
        state.metadata["error_message"] = (
            error_result.message
        )

        state.answer = error_result.message

        return state

    # =====================================================
    # Security + Input validation
    # =====================================================

    def validate_input(self, state: AIState) -> AIState:

        try:

            security_result = self.security.validate(
                state.user_input
            )

            # -------------------------------------------------
            # Blocked
            # -------------------------------------------------

            if not security_result.allowed:

                state.user_input = ""

                state.metadata["security_blocked"] = True

                state.metadata["security_reason"] = (
                    security_result.reason
                )

                state.answer = (
                    "Your request could not be processed.\n\n"
                    f"Reason: {security_result.reason}"
                )

                return state

            # -------------------------------------------------
            # Allowed
            # -------------------------------------------------

            state.user_input = security_result.text

            state.metadata["security_blocked"] = False
            state.metadata["security_reason"] = ""

            return state

        except Exception as e:

            return self.handle_error(
                state,
                e,
                route="security",
            )

    # =====================================================
    # Routing
    # =====================================================

    def route_request(self, state: AIState) -> AIState:

        try:

            result = self.router.classify(
                state.user_input
            )

            state.route = result.route

            state.metadata["route_reason"] = (
                result.reason
            )

            state.metadata["route_confidence"] = (
                result.confidence
            )

            return state

        except Exception as e:

            return self.handle_error(
                state,
                e,
                route="router",
            )

    # =====================================================
    # RAG retrieval
    # =====================================================

    def retrieve_rag(self, state: AIState) -> AIState:

        if state.route != "rag":
            return state

        try:

            results = self.vector_store.search(
                query=state.user_input,
                top_k=5,
            )

            state.sources = results

            if not results:

                state.context = ""

                state.metadata["rag_results"] = 0

                return state

            context_parts = []

            for index, result in enumerate(
                results,
                start=1,
            ):

                text = result.get(
                    "text",
                    "",
                )

                metadata = result.get(
                    "metadata",
                    {},
                )

                context_parts.append(
                    f"[Source {index}]\n"
                    f"{text}\n"
                    f"Metadata: {metadata}"
                )

            state.context = "\n\n".join(
                context_parts
            )

            state.metadata["rag_results"] = len(
                results
            )

        except Exception as e:

            state.context = ""
            state.sources = []

            state.metadata["rag_results"] = 0

            error_result = self.error_handler.handle(
                error=e,
                route="rag",
                user_message=state.user_input,
            )

            state.metadata["rag_error"] = (
                error_result.message
            )

            state.metadata["error"] = True

        return state

    # =====================================================
    # Web search
    # =====================================================

    def retrieve_web(self, state: AIState) -> AIState:

        if state.route != "web":
            return state

        try:

            results = self.web_search.search(
                query=state.user_input,
                max_results=5,
            )

            if not results:

                state.context = ""
                state.sources = []

                state.metadata["web_results"] = 0

                return state

            context_parts = []
            sources = []

            for index, result in enumerate(
                results,
                start=1,
            ):

                context_parts.append(
                    f"[Web Source {index}]\n"
                    f"Title: {result.title}\n"
                    f"URL: {result.url}\n"
                    f"Snippet: {result.snippet}"
                )

                sources.append(
                    {
                        "type": "web",
                        "title": result.title,
                        "url": result.url,
                        "snippet": result.snippet,
                    }
                )

            state.context = "\n\n".join(
                context_parts
            )

            state.sources = sources

            state.metadata["web_results"] = len(
                results
            )

        except Exception as e:

            state.context = ""
            state.sources = []

            state.metadata["web_results"] = 0

            error_result = self.error_handler.handle(
                error=e,
                route="web",
                user_message=state.user_input,
            )

            state.metadata["web_error"] = (
                error_result.message
            )

            state.metadata["error"] = True

        return state

    # =====================================================
    # Video retrieval
    # =====================================================

    def retrieve_video(self, state: AIState) -> AIState:

        if state.route != "video":
            return state

        try:

            results = self.video_retriever.search(
                query=state.user_input,
                top_k=5,
            )

            # -------------------------------------------------
            # No results
            # -------------------------------------------------

            if not results:

                state.context = ""
                state.sources = []

                state.metadata["video_results"] = 0
                state.metadata["video_segments"] = []
                state.metadata["video_citations"] = []

                return state

            # -------------------------------------------------
            # Format segments
            # -------------------------------------------------

            state.context = (
                self.video_retriever.format_results(
                    results
                )
            )

            sources = []
            video_results = []

            for result in results:

                metadata = result.metadata or {}

                title = metadata.get(
                    "title",
                    metadata.get(
                        "video_title",
                        "Unknown video",
                    ),
                )

                start_time = metadata.get(
                    "start_time",
                    metadata.get(
                        "start",
                        None,
                    ),
                )

                end_time = metadata.get(
                    "end_time",
                    metadata.get(
                        "end",
                        None,
                    ),
                )

                url = metadata.get(
                    "url",
                    metadata.get(
                        "source",
                        "",
                    ),
                )

                source = {
                    "type": "video",
                    "title": title,
                    "start_time": start_time,
                    "end_time": end_time,
                    "url": url,
                    "text": result.text,
                    "score": result.score,
                }

                sources.append(source)
                video_results.append(source)

            state.sources = sources

            state.metadata["video_results"] = len(
                results
            )

            state.metadata["video_segments"] = (
                video_results
            )

            # -------------------------------------------------
            # Safe citations
            # -------------------------------------------------

            citations = (
                build_citations_from_agent_sources(
                    state.sources
                )
            )

            state.metadata["video_citations"] = (
                citations
            )

        except Exception as e:

            state.context = ""
            state.sources = []

            state.metadata["video_results"] = 0
            state.metadata["video_segments"] = []
            state.metadata["video_citations"] = []

            error_result = self.error_handler.handle(
                error=e,
                route="video",
                user_message=state.user_input,
            )

            state.metadata["video_error"] = (
                error_result.message
            )

            state.metadata["error"] = True

        return state

    # =====================================================
    # Tool execution
    # =====================================================

    def execute_tool(self, state: AIState) -> AIState:

        try:

            text = state.user_input.lower()

            calculation_expression = None

            if "calculate" in text:

                calculation_expression = (
                    text.replace(
                        "calculate",
                        "",
                    ).strip()
                )

            elif "compute" in text:

                calculation_expression = (
                    text.replace(
                        "compute",
                        "",
                    ).strip()
                )

            if calculation_expression:

                result = self.tools.execute(
                    "calculate",
                    expression=calculation_expression,
                )

                state.tool_results.append(
                    {
                        "tool": result.tool,
                        "success": result.success,
                        "result": result.result,
                        "error": result.error,
                    }
                )

                if result.success:

                    state.answer = (
                        f"The result is: {result.result}"
                    )

                else:

                    state.answer = (
                        f"Calculation failed: "
                        f"{result.error}"
                    )

                return state

            state.answer = (
                "The tool system is ready, but "
                "this request needs a specific tool "
                "implementation."
            )

            return state

        except Exception as e:

            return self.handle_error(
                state,
                e,
                route="tool",
            )

    # =====================================================
    # Prompt generation
    # =====================================================

    def build_prompt(self, state: AIState) -> str:

        try:

            conversation_context = (
                self.context_manager.get_context(
                    self.session_id
                )
            )

            # -------------------------------------------------
            # RAG
            # -------------------------------------------------

            if state.route == "rag":

                return build_rag_prompt(
                    state.user_input,
                    state.context,
                )

            # -------------------------------------------------
            # Web
            # -------------------------------------------------

            if state.route == "web":

                return build_web_prompt(
                    state.user_input,
                    state.context,
                )

            # -------------------------------------------------
            # Video
            # -------------------------------------------------

            if state.route == "video":

                return build_video_prompt(
                    state.user_input,
                    state.context,
                )

            # -------------------------------------------------
            # Tool
            # -------------------------------------------------

            if state.route == "tool":

                return build_tool_prompt(
                    state.user_input,
                    state.context,
                )

            # -------------------------------------------------
            # General Chat
            # -------------------------------------------------

            prompt = build_chat_prompt(
                state.user_input
            )

            if conversation_context:

                prompt = (
                    "Previous conversation:\n\n"
                    f"{conversation_context}\n\n"
                    "Current request:\n\n"
                    f"{prompt}"
                )

            return prompt

        except Exception as e:

            self.handle_error(
                state,
                e,
                route=state.route,
            )

            return ""

    # =====================================================
    # Generate response
    # =====================================================

    def generate(self, state: AIState) -> AIState:

        try:

            # -------------------------------------------------
            # Tool
            # -------------------------------------------------

            if state.route == "tool":

                return self.execute_tool(state)

            # -------------------------------------------------
            # RAG
            # -------------------------------------------------

            if state.route == "rag":

                state = self.retrieve_rag(state)

            # -------------------------------------------------
            # Web
            # -------------------------------------------------

            if state.route == "web":

                state = self.retrieve_web(state)

            # -------------------------------------------------
            # Video
            # -------------------------------------------------

            if state.route == "video":

                state = self.retrieve_video(state)

            # -------------------------------------------------
            # Prompt
            # -------------------------------------------------

            prompt = self.build_prompt(state)

            state.metadata["prompt"] = prompt

            # -------------------------------------------------
            # RAG result
            # -------------------------------------------------

            if state.route == "rag":

                if state.context:

                    state.answer = (
                        "RAG retrieval completed successfully.\n\n"
                        "Retrieved context:\n\n"
                        f"{state.context}"
                    )

                else:

                    rag_error = state.metadata.get(
                        "rag_error"
                    )

                    if rag_error:

                        state.answer = rag_error

                    else:

                        state.answer = (
                            "No relevant information was found "
                            "in the connected knowledge base."
                        )

                return state

            # -------------------------------------------------
            # Web result
            # -------------------------------------------------

            if state.route == "web":

                if state.context:

                    state.answer = (
                        "Web search completed successfully.\n\n"
                        "Search results:\n\n"
                        f"{state.context}"
                    )

                else:

                    web_error = state.metadata.get(
                        "web_error"
                    )

                    if web_error:

                        state.answer = web_error

                    else:

                        state.answer = (
                            "No web search results were found."
                        )

                return state

            # -------------------------------------------------
            # Video result
            # -------------------------------------------------

            if state.route == "video":

                if state.context:

                    state.answer = (
                        "Video retrieval completed successfully.\n\n"
                        "Relevant video segments:\n\n"
                        f"{state.context}"
                    )

                    citations = state.metadata.get(
                        "video_citations",
                        [],
                    )

                    if citations:

                        citation_block = (
                            format_sources_block(
                                citations
                            )
                        )

                        if citation_block:

                            state.answer += (
                                "\n\n"
                                "Sources:\n\n"
                                f"{citation_block}"
                            )

                else:

                    video_error = state.metadata.get(
                        "video_error"
                    )

                    if video_error:

                        state.answer = video_error

                    else:

                        state.answer = (
                            "No relevant video segments "
                            "were found."
                        )

                return state

            # -------------------------------------------------
            # General chat
            # -------------------------------------------------

            state.answer = (
                "The general AI core is working.\n\n"
                f"Detected route: {state.route}\n\n"
                "The language model connection will be "
                "added in the next stage."
            )

            return state

        except Exception as e:

            return self.handle_error(
                state,
                e,
                route=state.route,
            )

    # =====================================================
    # Save conversation
    # =====================================================

    def save_memory(self, state: AIState) -> AIState:

        try:

            # -------------------------------------------------
            # Do not save blocked requests
            # -------------------------------------------------

            if state.metadata.get(
                "security_blocked",
                False,
            ):

                return state

            if not state.user_input:

                return state

            # -------------------------------------------------
            # Existing MemoryManager
            # -------------------------------------------------

            self.memory.add_user_message(
                self.session_id,
                state.user_input,
            )

            if state.answer:

                self.memory.add_assistant_message(
                    self.session_id,
                    state.answer,
                )

            # -------------------------------------------------
            # ContextManager
            # -------------------------------------------------

            self.context_manager.add_user_message(
                self.session_id,
                state.user_input,
            )

            if state.answer:

                self.context_manager.add_assistant_message(
                    self.session_id,
                    state.answer,
                )

            # -------------------------------------------------
            # Update state context
            # -------------------------------------------------

            state.context = (
                self.context_manager.get_context(
                    self.session_id
                )
            )

            return state

        except Exception as e:

            return self.handle_error(
                state,
                e,
                route="memory",
            )

    # =====================================================
    # Main pipeline
    # =====================================================

    def run(self, user_input: str) -> AIState:

        state = self.create_state(
            user_input
        )

        try:

            # -------------------------------------------------
            # Security
            # -------------------------------------------------

            state = self.validate_input(
                state
            )

            # -------------------------------------------------
            # Stop blocked request
            # -------------------------------------------------

            if state.answer:

                return state

            # -------------------------------------------------
            # Routing
            # -------------------------------------------------

            state = self.route_request(
                state
            )

            # -------------------------------------------------
            # Stop if routing failed
            # -------------------------------------------------

            if state.metadata.get(
                "error",
                False,
            ):

                return state

            # -------------------------------------------------
            # Generate
            # -------------------------------------------------

            state = self.generate(
                state
            )

            # -------------------------------------------------
            # Save memory + context
            # -------------------------------------------------

            if not state.metadata.get(
                "error",
                False,
            ):

                state = self.save_memory(
                    state
                )

            return state

        except Exception as e:

            return self.handle_error(
                state,
                e,
                route=state.route,
            )

    # =====================================================
    # Simple ask interface
    # =====================================================

    def ask(
        self,
        user_input: str,
    ) -> str:

        state = self.run(
            user_input
        )

        return state.answer


# =========================================================
# Simple helper
# =========================================================

def ask(
    user_input: str,
    session_id: str = "default",
) -> str:

    ai = GeneralAI(
        session_id=session_id
    )

    return ai.ask(
        user_input
    )


# =========================================================
# Test
# =========================================================

if __name__ == "__main__":

    print("=" * 60)

    print(
        "GENERAL AI + CENTRAL ERROR HANDLER TEST"
    )

    print("=" * 60)

    ai = GeneralAI(
        session_id="full-core-test"
    )

    tests = [
        "Hello",
        "Calculate 25 * 40",
        "Search my PDF file",
        "What is the latest technology news?",
        "Analyze this video",
        "rm -rf /",
        "format c:",
    ]

    for question in tests:

        print()
        print("-" * 60)

        print(
            "User:",
            question
        )

        state = ai.run(
            question
        )

        print(
            "Security blocked:",
            state.metadata.get(
                "security_blocked",
                False,
            ),
        )

        if state.metadata.get(
            "security_blocked",
            False,
        ):

            print(
                "Security reason:",
                state.metadata.get(
                    "security_reason",
                    "",
                ),
            )

            print(
                "Answer:"
            )

            print(
                state.answer
            )

            continue

        print(
            "Route:",
            state.route
        )

        print(
            "Confidence:",
            state.metadata.get(
                "route_confidence"
            ),
        )

        if state.metadata.get(
            "error",
            False,
        ):

            print(
                "Central error:",
                state.metadata.get(
                    "error_message",
                    "",
                ),
            )

            print(
                "Error type:",
                state.metadata.get(
                    "error_type",
                    "",
                ),
            )

        if state.route == "rag":

            print(
                "RAG results:",
                state.metadata.get(
                    "rag_results",
                    0,
                ),
            )

        if state.route == "web":

            print(
                "Web results:",
                state.metadata.get(
                    "web_results",
                    0,
                ),
            )

        if state.route == "video":

            print(
                "Video results:",
                state.metadata.get(
                    "video_results",
                    0,
                ),
            )

            print(
                "Video citations:",
                len(
                    state.metadata.get(
                        "video_citations",
                        [],
                    )
                ),
            )

        print(
            "Answer:"
        )

        print(
            state.answer
        )

    # =====================================================
    # Context test
    # =====================================================

    print()
    print("=" * 60)

    print(
        "CONTEXT MANAGER TEST"
    )

    print("=" * 60)

    context_ai = GeneralAI(
        session_id="context-test"
    )

    context_ai.run(
        "اسم من علی است."
    )

    context_ai.run(
        "من برنامه نویسی پایتون را دوست دارم."
    )

    print()
    print(
        "Stored conversation:"
    )

    print("-" * 60)

    print(
        context_ai.context_manager.get_context(
            "context-test"
        )
    )

    print()
    print(
        "Context message count:"
    )

    context_object = (
        context_ai.context_manager.get(
            "context-test"
        )
    )

    print(
        len(context_object.messages)
    )

    print()
    print("=" * 60)

    print(
        "GENERAL AI TEST COMPLETED"
    )

    print("=" * 60)