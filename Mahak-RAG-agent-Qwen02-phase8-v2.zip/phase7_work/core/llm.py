"""
General AI - LLM Interface

این فایل یک لایه عمومی روی LLM اصلی پروژه است.

منطق اصلی مدل، retry و fallback در config.py
قرار دارد و این فایل فقط رابط استاندارد Agent را فراهم می‌کند.
"""

from dataclasses import dataclass
from typing import Optional

import config


@dataclass
class LLMResponse:
    """نتیجه پاسخ مدل."""

    text: str
    model: str
    success: bool
    error: Optional[str] = None


class LLMClient:
    """
    رابط عمومی مدل زبانی.

    مدل‌ها از .env و توسط config.py خوانده می‌شوند.
    """

    def __init__(self):
        self.base_url = config.BASE_URL
        self.api_key = config.API_KEY

        self.gen_chain = list(
            getattr(config, "GEN_CHAIN", [])
        )

        self.fast_chain = list(
            getattr(config, "FAST_CHAIN", [])
        )

    @property
    def configured(self) -> bool:
        """
        بررسی می‌کند که حداقل یک مدل Generation
        در config تنظیم شده باشد.
        """

        return bool(
            self.api_key
            and self.gen_chain
        )

    @property
    def model(self) -> str:
        """
        مدل اصلی Generation.
        """

        if self.gen_chain:
            return self.gen_chain[0]

        return "model-not-configured"

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        fast: bool = False,
        temperature: float = 0.0,
    ) -> LLMResponse:
        """
        تولید پاسخ توسط LLM.

        مدل اصلی و fallbackها توسط config.call()
        مدیریت می‌شوند.
        """

        if not prompt or not prompt.strip():
            return LLMResponse(
                text="",
                model=self.model,
                success=False,
                error="Prompt is empty.",
            )

        # ساخت prompt نهایی
        final_prompt = prompt

        if system_prompt:
            final_prompt = (
                f"{system_prompt}\n\n"
                f"User request:\n{prompt}"
            )

        logs = []

        try:
            result = config.call(
                final_prompt,
                fast=fast,
                temperature=temperature,
                log=logs,
            )

            if result is None:
                error_text = (
                    "No configured model returned a response."
                )

                if logs:
                    error_text += (
                        "\n" + "\n".join(logs)
                    )

                return LLMResponse(
                    text="",
                    model=self.model,
                    success=False,
                    error=error_text,
                )

            used_model = self.model

            # config.call در log نام مدل واقعی
            # استفاده‌شده را ثبت می‌کند.
            for item in logs:
                if item.startswith("مدل:"):
                    used_model = (
                        item.replace(
                            "مدل:",
                            "",
                            1
                        )
                        .strip()
                    )

            return LLMResponse(
                text=result,
                model=used_model,
                success=True,
            )

        except Exception as exc:

            return LLMResponse(
                text="",
                model=self.model,
                success=False,
                error=str(exc),
            )


def create_llm_client() -> LLMClient:
    """ساخت LLM Client پیش‌فرض."""

    return LLMClient()


if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI - LLM CLIENT TEST")
    print("=" * 60)

    llm = create_llm_client()

    print()
    print("Configured:", llm.configured)
    print("Base URL:", llm.base_url)
    print("Primary model:", llm.model)

    print()
    print("Generation models:")

    for index, model in enumerate(
        llm.gen_chain,
        start=1
    ):
        print(
            f"  {index}. {model}"
        )

    print()
    print("Fast models:")

    for index, model in enumerate(
        llm.fast_chain,
        start=1
    ):
        print(
            f"  {index}. {model}"
        )

    print()
    print("Testing LLM connection...")

    result = llm.generate(
        "Hello. Respond with a short test message.",
        temperature=0.0,
    )

    print()
    print("Success:", result.success)
    print("Model:", result.model)

    if result.error:
        print()
        print("Error:")
        print(result.error)

    print()
    print("Response:")

    if result.text:
        print(result.text)
    else:
        print("(empty)")

    print()
    print("=" * 60)
    print("LLM CLIENT TEST COMPLETED")
    print("=" * 60)