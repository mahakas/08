"""
Unified source and citation system for General AI.

This module normalizes sources from:
- RAG
- Web Search
- Video RAG
- Generic documents

The goal is to give every route a consistent source structure.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Source:
    """Unified representation of one source."""

    source_type: str
    title: str = ""
    text: str = ""
    url: str = ""
    file_name: str = ""
    source_id: str = ""
    video_id: str = ""
    start: Optional[float] = None
    end: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert source to a dictionary."""

        data = {
            "type": self.source_type,
            "title": self.title,
            "text": self.text,
            "url": self.url,
            "file_name": self.file_name,
            "source_id": self.source_id,
            "video_id": self.video_id,
            "start": self.start,
            "end": self.end,
            "metadata": self.metadata,
        }

        return data


class SourceManager:
    """Normalize and format sources from all AI routes."""

    def __init__(self):
        self.sources: List[Source] = []

    def clear(self):
        """Clear current sources."""
        self.sources = []

    def add(self, source: Source) -> Source:
        """Add a source."""
        self.sources.append(source)
        return source

    def add_rag(
        self,
        text: str,
        metadata: Optional[Dict[str, Any]] = None,
        score: Optional[float] = None,
    ) -> Source:
        """Add a RAG/document source."""

        metadata = dict(metadata or {})

        title = (
            metadata.get("title")
            or metadata.get("source")
            or metadata.get("file_name")
            or "Knowledge Base"
        )

        source_id = str(
            metadata.get("id")
            or metadata.get("source_id")
            or metadata.get("document_id")
            or ""
        )

        if score is not None:
            metadata["score"] = score

        source = Source(
            source_type="rag",
            title=str(title),
            text=str(text or ""),
            file_name=str(metadata.get("file_name") or ""),
            source_id=source_id,
            metadata=metadata,
        )

        return self.add(source)

    def add_web(
        self,
        title: str,
        url: str = "",
        text: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Source:
        """Add a web source."""

        metadata = dict(metadata or {})

        source = Source(
            source_type="web",
            title=str(title or "Web Result"),
            text=str(text or ""),
            url=str(url or ""),
            source_id=str(metadata.get("source_id") or ""),
            metadata=metadata,
        )

        return self.add(source)

    def add_video(
        self,
        title: str,
        text: str = "",
        file_name: str = "",
        video_id: str = "",
        start: Optional[float] = None,
        end: Optional[float] = None,
        url: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Source:
        """Add a video source."""

        metadata = dict(metadata or {})

        source = Source(
            source_type="video",
            title=str(title or "Video"),
            text=str(text or ""),
            url=str(url or ""),
            file_name=str(file_name or ""),
            video_id=str(video_id or ""),
            start=self._safe_float(start),
            end=self._safe_float(end),
            metadata=metadata,
        )

        return self.add(source)

    def add_generic(
        self,
        source_type: str,
        title: str = "",
        text: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Source:
        """Add a generic source."""

        metadata = dict(metadata or {})

        source = Source(
            source_type=str(source_type or "unknown"),
            title=str(title or "Source"),
            text=str(text or ""),
            url=str(metadata.get("url") or ""),
            file_name=str(metadata.get("file_name") or ""),
            source_id=str(metadata.get("source_id") or ""),
            video_id=str(metadata.get("video_id") or ""),
            start=self._safe_float(metadata.get("start")),
            end=self._safe_float(metadata.get("end")),
            metadata=metadata,
        )

        return self.add(source)

    @staticmethod
    def _safe_float(value: Any) -> Optional[float]:
        """Safely convert a value to float."""

        if value is None or value == "":
            return None

        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def format_timestamp(
        start: Optional[float],
        end: Optional[float],
    ) -> str:
        """Format video timestamps."""

        if start is None:
            return ""

        start_seconds = max(0.0, float(start))

        if end is not None:
            end_seconds = max(start_seconds, float(end))
        else:
            end_seconds = None

        def format_time(seconds: float) -> str:
            total = int(seconds)

            hours = total // 3600
            minutes = (total % 3600) // 60
            secs = total % 60

            if hours > 0:
                return f"{hours:02d}:{minutes:02d}:{secs:02d}"

            return f"{minutes:02d}:{secs:02d}"

        start_text = format_time(start_seconds)

        if end_seconds is None:
            return start_text

        end_text = format_time(end_seconds)

        return f"{start_text} – {end_text}"

    def format_source(self, source: Source, index: int = 1) -> str:
        """Format one source for display."""

        lines = [
            f"[Source {index}]",
            f"Type: {source.source_type}",
        ]

        if source.title:
            lines.append(f"Title: {source.title}")

        if source.file_name:
            lines.append(f"File: {source.file_name}")

        if source.url:
            lines.append(f"URL: {source.url}")

        if source.source_type == "video":
            timestamp = self.format_timestamp(
                source.start,
                source.end,
            )

            if timestamp:
                lines.append(f"Timestamp: {timestamp}")

            if source.video_id:
                lines.append(f"Video ID: {source.video_id}")

        if source.text:
            clean_text = source.text.strip()

            if len(clean_text) > 1200:
                clean_text = clean_text[:1200] + "..."

            lines.append(f"Content: {clean_text}")

        return "\n".join(lines)

    def format_all(self) -> str:
        """Format all sources."""

        if not self.sources:
            return ""

        blocks = []

        for index, source in enumerate(self.sources, start=1):
            blocks.append(
                self.format_source(
                    source,
                    index=index,
                )
            )

        return "\n\n".join(blocks)

    def to_list(self) -> List[Dict[str, Any]]:
        """Return all sources as dictionaries."""

        return [
            source.to_dict()
            for source in self.sources
        ]


def create_source_manager() -> SourceManager:
    """Create a SourceManager instance."""
    return SourceManager()


def normalize_rag_results(results: List[Any]) -> List[Source]:
    """Convert RAG retrieval results into unified Source objects."""

    manager = SourceManager()

    for result in results or []:
        if isinstance(result, dict):
            text = result.get("text", "")
            metadata = result.get("metadata", {}) or {}
            score = result.get("score")

        else:
            text = getattr(result, "text", "")
            metadata = getattr(result, "metadata", {}) or {}
            score = getattr(result, "score", None)

        manager.add_rag(
            text=text,
            metadata=metadata,
            score=score,
        )

    return manager.sources


def normalize_web_results(results: List[Any]) -> List[Source]:
    """Convert web search results into unified Source objects."""

    manager = SourceManager()

    for result in results or []:

        if isinstance(result, dict):
            title = result.get("title", "")
            url = result.get("url", "")
            text = (
                result.get("snippet")
                or result.get("text")
                or result.get("content")
                or ""
            )

            metadata = result.get("metadata", {}) or {}

        else:
            title = getattr(result, "title", "")
            url = getattr(result, "url", "")
            text = (
                getattr(result, "snippet", "")
                or getattr(result, "text", "")
                or getattr(result, "content", "")
                or ""
            )

            metadata = getattr(result, "metadata", {}) or {}

        manager.add_web(
            title=title,
            url=url,
            text=text,
            metadata=metadata,
        )

    return manager.sources


def normalize_video_results(results: List[Any]) -> List[Source]:
    """Convert video retrieval results into unified Source objects."""

    manager = SourceManager()

    for result in results or []:

        if isinstance(result, dict):
            metadata = result.get("metadata", {}) or {}

            text = (
                result.get("text")
                or result.get("content")
                or ""
            )

            title = (
                metadata.get("title")
                or metadata.get("file_name")
                or "Video"
            )

            file_name = (
                result.get("file_name")
                or metadata.get("file_name")
                or ""
            )

            video_id = (
                result.get("video_id")
                or metadata.get("video_id")
                or ""
            )

            start = (
                result.get("start")
                if result.get("start") is not None
                else metadata.get("start", metadata.get("start_time"))
            )

            end = (
                result.get("end")
                if result.get("end") is not None
                else metadata.get("end", metadata.get("end_time"))
            )

            url = (
                result.get("url")
                or metadata.get("url")
                or ""
            )

        else:
            metadata = getattr(result, "metadata", {}) or {}

            text = (
                getattr(result, "text", "")
                or getattr(result, "content", "")
                or ""
            )

            title = (
                getattr(result, "title", "")
                or metadata.get("title")
                or metadata.get("file_name")
                or "Video"
            )

            file_name = (
                getattr(result, "file_name", "")
                or metadata.get("file_name")
                or ""
            )

            video_id = (
                getattr(result, "video_id", "")
                or metadata.get("video_id")
                or ""
            )

            start = (
                getattr(result, "start", None)
                if getattr(result, "start", None) is not None
                else metadata.get("start", metadata.get("start_time"))
            )

            end = (
                getattr(result, "end", None)
                if getattr(result, "end", None) is not None
                else metadata.get("end", metadata.get("end_time"))
            )

            url = (
                getattr(result, "url", "")
                or metadata.get("url")
                or ""
            )

        manager.add_video(
            title=title,
            text=text,
            file_name=file_name,
            video_id=video_id,
            start=start,
            end=end,
            url=url,
            metadata=metadata,
        )

    return manager.sources


def build_sources_block(
    rag_results: Optional[List[Any]] = None,
    web_results: Optional[List[Any]] = None,
    video_results: Optional[List[Any]] = None,
) -> str:
    """Build one unified sources block from all route results."""

    manager = SourceManager()

    for source in normalize_rag_results(rag_results or []):
        manager.add(source)

    for source in normalize_web_results(web_results or []):
        manager.add(source)

    for source in normalize_video_results(video_results or []):
        manager.add(source)

    return manager.format_all()


# ---------------------------------------------------------
# Standalone test
# ---------------------------------------------------------

if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI - SOURCES SYSTEM TEST")
    print("=" * 60)

    manager = create_source_manager()

    manager.add_rag(
        text="این یک متن آزمایشی برای تست RAG است.",
        metadata={
            "source": "test-document.pdf",
            "file_name": "test-document.pdf",
        },
        score=0.91,
    )

    manager.add_web(
        title="Technology News",
        url="https://example.com/news",
        text="This is a technology news result.",
    )

    manager.add_video(
        title="آموزش هوش مصنوعی",
        text="توضیح درباره سیستم هوش مصنوعی.",
        file_name="ai-course.mp4",
        video_id="video-001",
        start=1040.5,
        end=1105.2,
    )

    print()
    print(manager.format_all())

    print()
    print("-" * 60)
    print("SOURCE DICTIONARIES")
    print("-" * 60)

    for source in manager.to_list():
        print(source)

    print()
    print("=" * 60)
    print("SOURCES SYSTEM TEST COMPLETED")
    print("=" * 60)