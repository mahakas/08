"""
رابط چت — گرِیدیو (نسخه Hybrid RAG: اسناد + تصویر + ویدئو)

پنج بخش دارد:

1. چت — ایجنت از اسناد، تصاویر و ویدئوها جواب می‌گیرد.
2. اسناد — ساخت ایندکس DOCX / PDF / TXT / HTML / MD.
3. تصاویر — تحلیل تصویر با Vision Model و ایندکس در collection جدا.
4. آپلود MP4 — تحلیل و ایندکس ویدئو.
5. لینک یوتیوب — تحلیل مستقیم لینک و ساخت ایندکس timestamp‌دار.

اجرا:
    python app.py
"""

import re
import shutil
from pathlib import Path

import gradio as gr

import config
import agent
from agent import ask
import video_citation
import ingest
import video_ingest
from video_provider import get_provider, VideoUnderstandingError


# =========================================================
# CSS
# =========================================================

CSS = """
.rtl,
.rtl textarea,
.rtl input {
    direction: rtl !important;
    text-align: right !important;
}

.message,
.markdown-body,
.prose {
    direction: rtl;
    text-align: right;
}

#chat_input textarea {
    direction: rtl !important;
    text-align: right !important;
    resize: vertical !important;
}

#chatbot {
    direction: rtl;
}

.gradio-container {
    direction: rtl;
    overflow-x: hidden;
}

footer {
    display: none !important;
}
"""


# =========================================================
# نمونه سؤال‌ها
# =========================================================

NEMOONE = [
    "چانکینگ چیه؟",
    "وکتور دیتابیس چیه و چرا لازمه؟",
    "کانتکست ویندو یعنی چی؟",
    "پرامپت اینجکشن چیه؟",
    "لنگ‌گراف چیه؟",
    "قیمت دلار امروز چنده؟",
]


# =========================================================
# تنظیمات
# =========================================================

MAX_MB = config.VIDEO_MAX_FILE_SIZE_MB

DOCUMENT_EXT = sorted(config.DOCUMENT_EXTENSIONS)
IMAGE_EXT = sorted(config.IMAGE_EXTENSIONS)
VIDEO_EXT = sorted(config.VIDEO_EXTENSIONS)


# =========================================================
# ابزار فایل
# =========================================================

def _src(f):
    """
    مسیر فایل آپلودی.
    سازگار با Gradio جدید و قدیمی.
    """

    if f is None:
        return None

    if isinstance(f, (str, Path)):
        return Path(f)

    name = getattr(f, "name", None)

    if name:
        return Path(name)

    return Path(str(f))


# =========================================================
# تبدیل تاریخچه چت
# =========================================================

def _tabdil(tarikhche):
    """
    تاریخچه را به فرمت messages تبدیل می‌کند.

    خروجی:
    [
        {"role": "user", "content": "..."},
        {"role": "assistant", "content": "..."}
    ]
    """

    out = []

    if not tarikhche:
        return out

    for m in tarikhche:

        # Gradio type="messages"
        if isinstance(m, dict):

            role = m.get("role", "user")
            content = m.get("content")

            if content is not None:
                out.append(
                    {
                        "role": role,
                        "content": str(content),
                    }
                )

        # فرمت قدیمی Gradio
        elif isinstance(m, (list, tuple)) and len(m) == 2:

            if m[0]:
                out.append(
                    {
                        "role": "user",
                        "content": str(m[0]),
                    }
                )

            if m[1]:
                out.append(
                    {
                        "role": "assistant",
                        "content": str(m[1]),
                    }
                )

    return out


# =========================================================
# چت
# =========================================================

def chat(payam, tarikhche):

    if not payam or not str(payam).strip():
        return "", tarikhche or [], ""

    tarikhche = _tabdil(tarikhche)

    try:

        # ایجنت سؤال فعلی را خودش دریافت می‌کند
        javab, masir, manabe = ask(
            payam,
            tarikhche
        )

    except (Exception, SystemExit) as e:

        javab = (
            f"خطا: {type(e).__name__} — {e}"
        )

        masir = []
        manabe = []

    # -----------------------------------------------------
    # مسیر ایجنت
    # -----------------------------------------------------

    khat = "\n".join(
        f"{i + 1}. {s}"
        for i, s in enumerate(masir)
    )

    if khat:

        blok = (
            f"{javab}\n\n"
            "---\n"
            "**مسیر ایجنت:**\n"
            f"{khat}"
        )

    else:
        blok = javab

    # -----------------------------------------------------
    # تاریخچه جدید
    # -----------------------------------------------------

    new_hist = tarikhche + [
        {
            "role": "user",
            "content": str(payam),
        },
        {
            "role": "assistant",
            "content": str(blok),
        },
    ]

    # -----------------------------------------------------
    # منابع
    # -----------------------------------------------------

    manabe_text = ""

    if manabe:

        try:
            manabe_text = video_citation.format_sources_block(
                manabe
            )
        except Exception as e:
            manabe_text = (
                f"خطا در نمایش منابع: "
                f"{type(e).__name__} — {e}"
            )

    if manabe_text:

        manabe_md = (
            "**منابع (از متادیتای واقعی):**\n\n"
            f"{manabe_text}"
        )

    else:
        manabe_md = ""

    return "", new_hist, manabe_md


# =========================================================
# پاک کردن چت
# =========================================================

def clear_chat():
    return [], ""


# =========================================================
# آپلود اسناد (DOCX / PDF / TXT / HTML)
# =========================================================

def upload_docs(files, progress=gr.Progress()):

    if not files:
        return "هیچ فایلی انتخاب نشد."

    log = []

    try:

        ingest.SCRIPTS_DIR.mkdir(
            exist_ok=True
        )

        # -------------------------------------------------
        # ذخیره فایل‌ها
        # -------------------------------------------------

        for f in files:

            p = _src(f)

            if p is None:
                continue

            if p.suffix.lower() not in config.DOCUMENT_EXTENSIONS:

                log.append(
                    f"[!] {p.name} — این فرمت پشتیبانی نمی‌شود، رد شد"
                )

                continue

            dest = ingest.SCRIPTS_DIR / p.name

            shutil.copy(
                str(p),
                str(dest)
            )

            log.append(
                f"ذخیره شد: scripts/{p.name}"
            )

        # -------------------------------------------------
        # خواندن سندها (load_all همهٔ فایل‌های پشتیبانی‌شده
        # را می‌خواند، نه فقط فایل‌های تازه)
        # -------------------------------------------------

        progress(
            0.05,
            desc="خواندن سندها ..."
        )

        docs = ingest.load_all()

        if not docs:

            return (
                "\n".join(log)
                + "\nهیچ سند معتبری پیدا نشد."
            )

        # -------------------------------------------------
        # Chunking
        # -------------------------------------------------

        progress(
            0.15,
            desc="چانک‌بندی ..."
        )

        chunks = ingest.chunk_documents(docs)

        # -------------------------------------------------
        # Embedding
        # -------------------------------------------------

        progress(
            0.25,
            desc="آماده‌سازی امبدینگ ..."
        )

        emb = config.embedder()

        total = len(chunks)

        if total == 0:

            return (
                "\n".join(log)
                + "\nهیچ چانکی ساخته نشد."
            )

        BATCH = 64

        # فقط collection متن پاک می‌شود — نه ویدئو، نه تصویر
        store = ingest._fresh_store(
            config.TEXT_COLLECTION,
            emb
        )

        for i in range(0, total, BATCH):

            store.add_documents(
                chunks[
                    i:i + BATCH
                ]
            )

            done = min(
                i + BATCH,
                total
            )

            progress(
                0.3 + 0.65 * done / total,
                desc=f"امبد {done:,} / {total:,}"
            )

        # کش ایجنت پاک شود
        agent._store = None

        progress(
            1.0,
            desc="تمام شد"
        )

        log.append(
            f"{len(docs)} سند → "
            f"{total:,} تکه در "
            f"«{config.TEXT_COLLECTION}»"
        )

        return "\n".join(log)

    except (Exception, SystemExit) as e:

        return (
            "\n".join(log)
            + f"\nخطا: {type(e).__name__} — {e}"
        )


# =========================================================
# آپلود تصویر (تحلیل با Vision Model)
# =========================================================

def upload_images(files, progress=gr.Progress()):

    if not files:
        return "هیچ فایلی انتخاب نشد."

    log = []

    def cb(message=""):

        text = str(message)

        log.append(text)

        mm = _PROG_RE.search(text)

        if mm:

            progress(
                0.1 + 0.8 * int(mm.group(1)) / 100,
                desc=mm.group(2)[:60]
            )

    try:

        ingest.SCRIPTS_DIR.mkdir(
            exist_ok=True
        )

        for f in files:

            p = _src(f)

            if p is None:
                continue

            if p.suffix.lower() not in config.IMAGE_EXTENSIONS:

                log.append(
                    f"[!] {p.name} — تصویر نیست، رد شد"
                )

                continue

            size_mb = p.stat().st_size / (1024 * 1024)

            if size_mb > config.IMAGE_MAX_FILE_SIZE_MB:

                log.append(
                    f"[!] {p.name} — حجم {size_mb:.1f} MB "
                    f"بیش از سقف {config.IMAGE_MAX_FILE_SIZE_MB} MB است، رد شد"
                )

                continue

            shutil.copy(
                str(p),
                str(ingest.SCRIPTS_DIR / p.name)
            )

            log.append(
                f"ذخیره شد: scripts/{p.name}"
            )

        progress(
            0.1,
            desc="خواندن متادیتا ..."
        )

        meta = ingest.read_metadata()

        # همهٔ تصاویر داخل scripts/ تحلیل و دوباره ایندکس می‌شوند؛
        # مثل مسیر اسناد، ایندکس کامل و idempotent است.
        docs = ingest.load_images(meta, log=cb)

        if not docs:

            return (
                "\n".join(log)
                + "\nهیچ تصویری تحلیل نشد. "
                  "کلید QWEN_API_KEY یا GEMINI_API_KEY را چک کن."
            )

        progress(
            0.85,
            desc="چانک و امبد ..."
        )

        chunks = ingest.chunk_documents(docs)

        emb = config.embedder()

        store = ingest._fresh_store(
            config.IMAGE_COLLECTION,
            emb
        )

        store.add_documents(chunks)

        progress(
            1.0,
            desc="تمام شد"
        )

        log.append(
            f"{len(docs)} تصویر → "
            f"{len(chunks):,} تکه در "
            f"«{config.IMAGE_COLLECTION}»"
        )

        return "\n".join(log)

    except (Exception, SystemExit) as e:

        return (
            "\n".join(log)
            + f"\nخطا: {type(e).__name__} — {e}"
        )


# =========================================================
# آپلود MP4
# =========================================================

_PROVIDER = None

_PROG_RE = re.compile(
    r"\[\s*(\d+)%\]\s*(.*)"
)


def _provider():

    global _PROVIDER

    if _PROVIDER is None:
        _PROVIDER = get_provider()

    return _PROVIDER


# =========================================================
# ثبت Metadata ویدئو
# =========================================================

def _append_video_meta(
    name: str,
    url: str
):

    path = video_ingest.META_CSV

    row = f"{name},,{url}"

    if path.exists():

        text = path.read_text(
            encoding="utf-8-sig"
        )

        lines_raw = text.splitlines()

        first = (
            lines_raw[0]
            if lines_raw
            else "file,title,url"
        )

        delim = (
            ";"
            if first.count(";") > first.count(",")
            else ","
        )

        row = (
            f"{name}"
            f"{delim}"
            f"{delim}"
            f"{url}"
        )

        lines = [
            l
            for l in lines_raw
            if l.strip()
        ]

        # حذف رکورد قبلی همین فایل
        filtered = []

        for line in lines:

            parts = line.split(delim)

            if not parts:
                continue

            if parts[0].strip() == name:
                continue

            filtered.append(line)

        filtered.append(row)

        path.write_text(
            "\n".join(filtered) + "\n",
            encoding="utf-8"
        )

    else:

        path.write_text(
            f"file,title,url\n{row}\n",
            encoding="utf-8"
        )


# =========================================================
# آپلود ویدئو
# =========================================================

def upload_video(
    file,
    url,
    progress=gr.Progress()
):

    if not file:
        return "هیچ فایلی انتخاب نشد."

    log = []

    try:

        p = _src(file)

        if p is None:
            return "فایل معتبر نیست."

        if p.suffix.lower() not in config.VIDEO_EXTENSIONS:

            return (
                f"[!] «{p.name}» فرمت ویدئوی پشتیبانی‌شده نیست "
                "(mp4/mov/avi/mkv/webm)."
            )

        # -------------------------------------------------
        # ذخیره ویدئو
        # -------------------------------------------------

        video_ingest.VIDEOS_DIR.mkdir(
            exist_ok=True
        )

        dest = (
            video_ingest.VIDEOS_DIR
            / p.name
        )

        shutil.copy(
            str(p),
            str(dest)
        )

        log.append(
            f"ذخیره شد: videos/{p.name}"
        )

        # -------------------------------------------------
        # بررسی حجم
        # -------------------------------------------------

        size_mb = (
            dest.stat().st_size
            / (1024 * 1024)
        )

        if size_mb > MAX_MB:

            return (
                "\n".join(log)
                + f"\n[!] حجم {size_mb:.0f} MB "
                  f"بیش از سقف {MAX_MB} MB است."
            )

        # -------------------------------------------------
        # لینک یوتیوب
        # -------------------------------------------------

        if url and url.strip():

            _append_video_meta(
                p.name,
                url.strip()
            )

            log.append(
                "لینک یوتیوب به "
                "video_metadata.csv اضافه شد "
                "(برای لینک timestamp‌دار)"
            )

        # -------------------------------------------------
        # شروع تحلیل
        # -------------------------------------------------

        progress(
            0.05,
            desc=f"آماده‌سازی تحلیل {p.name} ..."
        )

        def cb(m):

            log.append(m)

            mm = _PROG_RE.search(
                str(m)
            )

            if mm:

                pct = int(
                    mm.group(1)
                )

                progress(
                    0.05 + 0.9 * pct / 100,
                    desc=mm.group(2)[:60]
                )

        meta = video_ingest.read_metadata()

        provider = _provider()

        n = video_ingest.process_video(
            dest,
            meta,
            provider,
            force=False,
            log=cb
        )

        # -------------------------------------------------
        # نتیجه
        # -------------------------------------------------

        if n == 0:

            log.append(
                "= قبلاً ایندکس شده بود "
                "یا محتوای جدیدی نداشت — SKIP"
            )

        else:

            log.append(
                f"✓ {n} چانک ویدئویی به "
                f"«{config.VIDEO_COLLECTION}» "
                "اضافه شد"
            )

        progress(
            1.0,
            desc="تمام شد"
        )

        return "\n".join(log)

    except (VideoUnderstandingError, Exception, SystemExit) as e:

        return (
            "\n".join(log)
            + f"\n[x] خطای پرووایدر: {e}"
        )


# =========================================================
# لینک یوتیوب
# =========================================================

def ingest_youtube(
    url,
    title,
    progress=gr.Progress()
):

    if not url or not url.strip():

        return "لینک یوتیوب را وارد کن."

    log = []

    try:

        # -------------------------------------------------
        # استخراج ID
        # -------------------------------------------------

        vid = video_ingest.extract_youtube_id(
            url.strip()
        )

        if not vid:

            return (
                "[!] لینک یوتیوب معتبر نیست.\n"
                "نمونه:\n"
                "https://www.youtube.com/watch?v=XXXXXXXXXXX"
            )

        progress(
            0.05,
            desc=f"تحلیل یوتیوب {vid} ..."
        )

        # -------------------------------------------------
        # Callback
        # -------------------------------------------------

        def cb(m):

            log.append(m)

            mm = _PROG_RE.search(
                str(m)
            )

            if mm:

                pct = int(
                    mm.group(1)
                )

                progress(
                    0.05 + 0.9 * pct / 100,
                    desc=mm.group(2)[:60]
                )

        # -------------------------------------------------
        # Provider
        # -------------------------------------------------

        provider = _provider()

        n = video_ingest.process_youtube(
            url.strip(),
            (title or "").strip(),
            provider,
            force=False,
            log=cb
        )

        # -------------------------------------------------
        # نتیجه
        # -------------------------------------------------

        if n == 0:

            log.append(
                "= قبلاً ایندکس شده بود — SKIP"
            )

        else:

            log.append(
                f"✓ {n} چانک ویدئویی به "
                f"«{config.VIDEO_COLLECTION}» "
                "اضافه شد"
            )

        progress(
            1.0,
            desc="تمام شد"
        )

        return "\n".join(log)

    except (VideoUnderstandingError, Exception, SystemExit) as e:

        return (
            "\n".join(log)
            + f"\n[x] خطای پرووایدر: {e}"
        )


# =========================================================
# رابط کاربری
# =========================================================

with gr.Blocks(
    title="دستیار مهک",
    css=CSS
) as demo:

    # -----------------------------------------------------
    # عنوان
    # -----------------------------------------------------

    gr.Markdown(
        """
        ## دستیار مهک

        از اسناد (DOCX/PDF/TXT/HTML)، تصاویر و ویدئوهای کانال بپرس —
        جواب‌ها با ذکر منبع و timestamp دقیق می‌آیند.
        """
    )

    # =====================================================
    # TAB: CHAT
    # =====================================================

    with gr.Tab("💬 چت"):

        chatbot = gr.Chatbot(
            label="گفت‌وگو",
            elem_id="chatbot",
            elem_classes=["rtl"],
            height=420,
        )

        msg = gr.Textbox(
            label="پیام",
            placeholder="سؤالت را بنویس ...",
            elem_id="chat_input",
            elem_classes=["rtl"],
            lines=2,
            max_lines=6,
            autofocus=True,
        )

        with gr.Row():

            send = gr.Button(
                "بفرست",
                variant="primary",
            )

            clear = gr.Button(
                "پاک کن"
            )

        gr.Examples(
            examples=NEMOONE,
            inputs=msg,
            label="نمونه سؤال‌ها",
        )

        manabe_md = gr.Markdown(
            elem_classes=["rtl"]
        )

    # =====================================================
    # TAB: DOCUMENTS
    # =====================================================

    with gr.Tab("📄 اسناد (PDF/DOCX/TXT/HTML)"):

        gr.Markdown(
            "فایل‌های DOCX، PDF، TXT، MD و HTML را آپلود کن و ایندکس متن را بساز. "
            "ایندکس ویدئو و تصویر دست نمی‌خورد."
        )

        doc_files = gr.File(
            label="فایل‌های متنی",
            file_types=DOCUMENT_EXT,
            file_count="multiple",
            type="filepath",
        )

        btn_docx = gr.Button(
            "ساخت ایندکس متن",
            variant="primary",
        )

        out_docx = gr.Textbox(
            label="گزارش",
            lines=10,
            elem_classes=["rtl"],
        )

    # =====================================================
    # TAB: IMAGES
    # =====================================================

    with gr.Tab("🖼 تصاویر"):

        gr.Markdown(
            "تصاویر (PNG/JPG/WEBP/BMP/GIF/TIFF) را آپلود کن. "
            "تصویر با Vision Model تحلیل می‌شود (قwen یا gemini) "
            "و در collection «" + config.IMAGE_COLLECTION + "» ذخیره می‌شود. "
            "متن داخل تصویر و توضیح تصویری هر دو قابل جست‌وجو خواهند بود. "
            "اگر کلید Vision موجود نباشد از pytesseract (OCR) استفاده می‌شود."
        )

        img_files = gr.File(
            label="فایل‌های تصویری",
            file_types=IMAGE_EXT,
            file_count="multiple",
            type="filepath",
        )

        btn_img = gr.Button(
            "تحلیل و ایندکس تصاویر",
            variant="primary",
        )

        out_img = gr.Textbox(
            label="گزارش و مراحل",
            lines=12,
            elem_classes=["rtl"],
        )

    # =====================================================
    # TAB: MP4
    # =====================================================

    with gr.Tab("🎥 ویدئو (MP4)"):

        gr.Markdown(
            "فایل MP4 را آپلود کن. تحلیل با Vision Provider انجام می‌شود "
            "و ممکن است دقایقی طول بکشد. اگر لینک یوتیوب همین "
            "ویدئو را بدهی، منابع با لینک timestamp‌دار ساخته می‌شوند."
        )

        vid_file = gr.File(
            label="فایل MP4",
            file_types=VIDEO_EXT,
            file_count="single",
            type="filepath",
        )

        vid_url = gr.Textbox(
            label="لینک یوتیوب (اختیاری)",
            placeholder="https://www.youtube.com/watch?v=...",
            elem_classes=["rtl"],
        )

        btn_vid = gr.Button(
            "تحلیل و ایندکس ویدئو",
            variant="primary",
        )

        out_vid = gr.Textbox(
            label="گزارش و مراحل",
            lines=14,
            elem_classes=["rtl"],
        )

    # =====================================================
    # TAB: YOUTUBE
    # =====================================================

    with gr.Tab("🔗 لینک یوتیوب"):

        gr.Markdown(
            """
            فقط لینک یوتیوب را بده — **بدون دانلود و آپلود**.

            ویدئو مستقیم توسط Vision Provider تحلیل می‌شود و منابع
            با لینک timestamp‌دار ساخته می‌شوند.
            """
        )

        yt_url = gr.Textbox(
            label="لینک یوتیوب",
            placeholder="https://www.youtube.com/watch?v=...",
            elem_classes=["rtl"],
        )

        yt_title = gr.Textbox(
            label="عنوان (اختیاری — اگر خالی بماند شناسه ویدئو استفاده می‌شود)",
            elem_classes=["rtl"],
        )

        btn_yt = gr.Button(
            "تحلیل و ایندکس لینک",
            variant="primary",
        )

        out_yt = gr.Textbox(
            label="گزارش و مراحل",
            lines=14,
            elem_classes=["rtl"],
        )

    # =====================================================
    # EVENT: CHAT
    # =====================================================

    msg.submit(
        fn=chat,
        inputs=[msg, chatbot],
        outputs=[msg, chatbot, manabe_md],
        queue=True,
    )

    send.click(
        fn=chat,
        inputs=[msg, chatbot],
        outputs=[msg, chatbot, manabe_md],
        queue=True,
    )

    clear.click(
        fn=clear_chat,
        inputs=None,
        outputs=[chatbot, manabe_md],
        queue=False,
    )

    # =====================================================
    # EVENT: DOCUMENTS
    # =====================================================

    btn_docx.click(
        fn=upload_docs,
        inputs=[doc_files],
        outputs=[out_docx],
        queue=True,
    )

    # =====================================================
    # EVENT: IMAGES
    # =====================================================

    btn_img.click(
        fn=upload_images,
        inputs=[img_files],
        outputs=[out_img],
        queue=True,
    )

    # =====================================================
    # EVENT: MP4
    # =====================================================

    btn_vid.click(
        fn=upload_video,
        inputs=[vid_file, vid_url],
        outputs=[out_vid],
        queue=True,
    )

    # =====================================================
    # EVENT: YOUTUBE
    # =====================================================

    btn_yt.click(
        fn=ingest_youtube,
        inputs=[yt_url, yt_title],
        outputs=[out_yt],
        queue=True,
    )


# =========================================================
# اجرای برنامه
# =========================================================

if __name__ == "__main__":

    demo.launch(
        inbrowser=True
    )