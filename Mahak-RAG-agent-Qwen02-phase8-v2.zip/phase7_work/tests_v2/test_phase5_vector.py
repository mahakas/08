from pathlib import Path

import pytest

from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.vectorstores.embedding import EmbeddingService
from backend_v2.vectorstores.indexing import IndexSpec, VectorIndexService


def _embedding_service(dimension: int = 8):
    registry = ProviderRegistry()
    registry.register(
        MockProviderAdapter("embedder", {Capability.EMBEDDING}, default_model="embed-v1", embedding_dimension=dimension),
        priority=1,
    )
    return EmbeddingService(ProviderOrchestrator(registry, ProviderHealthManager()))


def test_embedding_service_returns_consistent_vectors():
    result = _embedding_service(8).embed(["سلام", "فیزیک"])
    assert len(result.vectors) == 2
    assert result.dimension == 8
    assert all(len(vector) == 8 for vector in result.vectors)


def test_embedding_service_rejects_invalid_batch(monkeypatch):
    class BadAdapter(MockProviderAdapter):
        def execute(self, request):
            from backend_v2.providers.contracts import ProviderResponse
            return ProviderResponse([[0.1]], self.provider_name, request.model)

    registry = ProviderRegistry()
    registry.register(BadAdapter("bad", {Capability.EMBEDDING}, default_model="bad"), priority=1)
    service = EmbeddingService(ProviderOrchestrator(registry))
    with pytest.raises(ValueError):
        service.embed(["a", "b"])


def test_index_spec_collection_name_is_versioned():
    spec = IndexSpec("physics10", "profile-1", "e5-v1", 8, version=3)
    assert spec.collection_name == "physics10__v3__e5-v1"


def test_vector_index_rejects_dimension_mismatch():
    class DummyStore:
        pass
    service = VectorIndexService(DummyStore())
    spec = IndexSpec("physics10", "profile-1", "e5-v1", 8)
    embedding = _embedding_service(16).embed(["text"])
    with pytest.raises(ValueError):
        service.upsert_texts(spec, ["text"], embedding)


def test_chroma_round_trip(tmp_path: Path):
    pytest.importorskip("chromadb")
    from backend_v2.vectorstores.base import VectorRecord
    from backend_v2.vectorstores.chroma import ChromaVectorStore

    store = ChromaVectorStore(tmp_path / "chroma")
    collection = "phase5_test"
    store.reset_for_tests(collection=collection)
    store.upsert(
        [
            VectorRecord("1", [1.0, 0.0, 0.0], "کتاب فیزیک", {"subject": "physics", "grade": "10"}),
            VectorRecord("2", [0.0, 1.0, 0.0], "کتاب شیمی", {"subject": "chemistry", "grade": "10"}),
        ],
        collection=collection,
    )
    hits = store.search([1.0, 0.0, 0.0], collection=collection, top_k=2, filters={"subject": "physics"})
    assert len(hits) == 1
    assert hits[0].id == "1"
    assert hits[0].metadata["grade"] == "10"
    assert store.count(collection=collection) == 2
