from fastapi.testclient import TestClient

from backend_v2.chat.context import ConversationContext
from backend_v2.chat.general import FileContext, GeneralChatService, InMemoryFileContextProvider
from backend_v2.core.enums import Capability, ChatMode
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.web.search import InMemoryWebSearchAdapter, WebSearchResult


def _service():
    registry = ProviderRegistry()

    def handler(payload):
        if payload["use_web"]:
            return "پاسخ بر اساس نتایج وب."
        return "پاسخ عمومی بر اساس زمینهٔ گفتگو و فایل."

    chat = MockProviderAdapter("general-chat", {Capability.CHAT}, handler, default_model="general-v1")
    registry.register(chat, priority=1)
    orchestrator = ProviderOrchestrator(registry, ProviderHealthManager())
    web = InMemoryWebSearchAdapter({
        "آخرین اخبار فناوری": [WebSearchResult("خبر فناوری", "https://example.test/news", "نمونه نتیجه وب", "mock")]
    })
    files = InMemoryFileContextProvider({
        "file-1": FileContext("file-1", "جزوه", "محتوای اختصاصی فایل کاربر")
    })
    return GeneralChatService(orchestrator, web_search=web, file_context=files)


def _ctx(file_ids=None):
    return ConversationContext("g1", None, ChatMode.GENERAL, session_file_ids=file_ids or [])


def test_general_chat_without_web():
    result = _service().ask(_ctx(), "یک توضیح ساده دربارهٔ جاذبه بده", use_web=False)
    assert result.answer.startswith("پاسخ عمومی")
    assert not result.used_web
    assert not result.used_files


def test_general_chat_uses_session_file():
    service = _service()
    context = _ctx(["file-1"])
    result = service.ask(context, "این فایل درباره چیست؟", use_web=False)
    assert result.used_files
    assert not result.used_web
    assert context.messages[-1]["metadata"]["used_files"] is True


def test_general_chat_planner_can_trigger_web_for_current_query():
    result = _service().ask(_ctx(), "آخرین اخبار فناوری چیست؟")
    assert result.used_web
    assert result.web_provider == "memory-web"
    assert result.citations[0].url == "https://example.test/news"


def test_general_chat_can_force_web():
    result = _service().ask(_ctx(), "آخرین اخبار فناوری", use_web=True)
    assert result.used_web
    assert result.citations


def test_general_chat_rejects_educational_context():
    context = ConversationContext("e1", None, ChatMode.EDUCATIONAL)
    try:
        _service().ask(context, "سؤال")
    except ValueError as exc:
        assert "general" in str(exc).lower()
    else:
        raise AssertionError("educational context should be rejected")


def test_general_chat_api_endpoint():
    from backend_v2.api.app import create_app
    client = TestClient(create_app())
    response = client.post(
        "/api/chat/general",
        json={"conversation_id": "api-general", "query": "سلام", "use_web": False},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["used_web"] is False
    assert body["provider"] == "default-general-chat"
