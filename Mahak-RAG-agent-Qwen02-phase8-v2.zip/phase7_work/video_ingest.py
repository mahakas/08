"""
ساخت ایندکس ویدئو — ایجنت عمومی

ویدئوهای پوشه videos/ را می‌گیرد، از طریق provider تحلیل
می‌کند، به چانک‌های زمان‌دار تبدیل و در collection ویدئویی Chroma
ذخیره می‌کند.

اجرا:

    python video_ingest.py
    python video_ingest.py --force
    python video_ingest.py --file example.mp4
    python video_ingest.py --url "https://www.youtube.com/watch?v=..."
    python video_ingest.py --url "https://www.youtube.com/watch?v=..." --title "عنوان"

نکات:
- Video ID فایل = SHA256
- Video ID یوتیوب = YouTube ID
- timestamp از Provider گرفته می‌شود
- فایل‌های قبلاً پردازش‌شده دوباره پردازش نمی‌شوند
- اطلاعات در collection ویدئویی Chroma ذخیره می‌شود
"""

import argparse
import csv
import hashlib
import math
import os
import re
import time
from pathlib import Path

from langchain_core.documents import Document

import config
from video_provider import (
    get_provider,
    VideoUnderstandingError,
    URL_WINDOW_SECONDS,
)


VIDEOS_DIR = Path("videos")
META_CSV = Path("video_metadata.csv")

# حداقل محتوای قابل قبول برای ذخیره
MIN_CHARS = 40

# تعداد پنجره‌های پیش‌فرض برای YouTube
URL_MAX_WINDOWS = int(
    os.getenv("VIDEO_URL_MAX_WINDOWS", "20")
)


YOUTUBE_RE = re.compile(
    r"(?:youtube\.com/watch\?.*v=|youtu\.be/|"
    r"youtube\.com/shorts/|youtube\.com/embed/)"
    r"([\w-]{6,})"
)


def extract_youtube_id(url: str) -> str:
    """استخراج شناسه ویدئوی YouTube."""
    match = YOUTUBE_RE.search(url or "")

    if match:
        return match.group(1)

    return ""


def sha256_file(
    path: Path,
    buf_size: int = 1024 * 1024,
) -> str:
    """ساخت SHA256 پایدار برای فایل."""

    hash_object = hashlib.sha256()

    with open(path, "rb") as file:

        while True:

            block = file.read(buf_size)

            if not block:
                break

            hash_object.update(block)

    return hash_object.hexdigest()


def read_metadata() -> dict:
    """
    خواندن video_metadata.csv.

    ساختار:

        file,title,url
        video.mp4,عنوان ویدئو,https://...
    """

    if not META_CSV.exists():

        print(
            "video_metadata.csv پیدا نشد."
            " نام فایل به عنوان عنوان استفاده می‌شود."
        )

        return {}

    text = None

    for encoding in (
        "utf-8-sig",
        "utf-8",
        "cp1256",
        "cp1252",
    ):

        try:

            text = META_CSV.read_text(
                encoding=encoding
            )

            break

        except (
            UnicodeDecodeError,
            LookupError,
        ):

            continue

    if text is None:

        raise SystemExit(
            "video_metadata.csv با هیچ کدگذاری خوانده نشد."
        )

    lines = [
        line
        for line in text.splitlines()
        if line.strip()
    ]

    if not lines:
        return {}

    delimiter = (
        ";"
        if lines[0].count(";") > lines[0].count(",")
        else ","
    )

    output = {}

    for row in csv.DictReader(
        lines,
        delimiter=delimiter,
    ):

        name = (
            row.get("file") or ""
        ).strip()

        if not name:
            continue

        title = (
            row.get("title") or ""
        ).strip()

        url = (
            row.get("url") or ""
        ).strip()

        output[name] = (
            title,
            url,
        )

    return output


def build_windows(duration: float):
    """
    ساخت پنجره‌های زمانی برای فایل ویدئویی.
    """

    step = float(
        config.VIDEO_CHUNK_DURATION
    )

    if step <= 0:
        step = 60.0

    windows = []

    current = 0.0

    while current < duration - 0.01:

        end = min(
            current + step,
            duration,
        )

        windows.append(
            {
                "start": current,
                "end": end,
            }
        )

        current += step

    if not windows:

        windows.append(
            {
                "start": 0.0,
                "end": max(duration, 1.0),
            }
        )

    return windows


def get_duration(path: Path) -> float:
    """
    دریافت مدت ویدئو با ffprobe.

    اگر ffprobe در سیستم موجود نباشد،
    مقدار صفر برگردانده می‌شود.
    """

    try:

        import subprocess

        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                str(path),
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )

        value = result.stdout.strip()

        if not value:
            return 0.0

        return float(value)

    except Exception:

        return 0.0


def _ts(seconds: float) -> str:
    """
    تبدیل ثانیه به timestamp.

    مثال:
        1040 -> 17:20
        3725 -> 1:02:05
    """

    seconds = int(
        round(seconds)
    )

    hours, remainder = divmod(
        seconds,
        3600,
    )

    minutes, seconds = divmod(
        remainder,
        60,
    )

    if hours:

        return (
            f"{hours:d}:"
            f"{minutes:02d}:"
            f"{seconds:02d}"
        )

    return (
        f"{minutes:02d}:"
        f"{seconds:02d}"
    )


def segment_to_document(
    seg: dict,
    video: dict,
) -> Document:
    """
    تبدیل سگمنت Video Provider به Document قابل ذخیره در Chroma.
    """

    title = video["title"]

    start = float(
        seg.get("start_time", 0.0)
    )

    end = float(
        seg.get("end_time", start)
    )

    parts = [
        f"ویدئو: {title}",
        f"زمان: {_ts(start)} تا {_ts(end)}",
    ]

    transcript = (
        seg.get("transcript") or ""
    ).strip()

    visual_description = (
        seg.get("visual_description") or ""
    ).strip()

    code = (
        seg.get("code") or ""
    ).strip()

    if transcript:

        parts.append(
            f"گفتار:\n{transcript}"
        )

    if visual_description:

        parts.append(
            f"تصویر:\n{visual_description}"
        )

    if code:

        parts.append(
            f"کد روی صفحه:\n{code}"
        )

    metadata = {
        "source_type": "video",
        "video_id": video["video_id"],
        "file_name": video["file_name"],
        "title": title,
        "start_time": start,
        "end_time": end,
        "start_timestamp": _ts(start),
        "end_timestamp": _ts(end),
        "content_type": (
            seg.get("content_type")
            or "mixed"
        ),
        "url": video.get("url", ""),
    }

    return Document(
        page_content="\n".join(parts),
        metadata=metadata,
    )


def process_video(
    path: Path,
    meta: dict,
    provider,
    force: bool,
    log=None,
):
    """
    پردازش یک فایل ویدئویی.
    """

    if log is None:
        log = print

    size_mb = (
        path.stat().st_size
        / (1024 * 1024)
    )

    video_hash = sha256_file(path)

    store = config.video_store()

    existing = store.get(
        where={
            "video_id": video_hash
        }
    )

    existing_ids = (
        existing.get("ids")
        or []
    )

    if existing_ids and not force:

        old_metadata_list = (
            existing.get("metadatas")
            or []
        )

        old_metadata = (
            old_metadata_list[0]
            if old_metadata_list
            else {}
        )

        same_file = (
            old_metadata.get("file_name")
            == path.name
            and old_metadata.get("file_size")
            == round(size_mb, 2)
        )

        if (
            same_file
            or config.VIDEO_ENABLE_CACHE
        ):

            log(
                f"  = {path.name} "
                "قبلاً ایندکس شده — SKIP"
            )

            return 0

    if existing_ids:

        log(
            f"  ↻ {path.name} "
            "در حال ایندکس مجدد — REINDEX"
        )

        store.delete(
            where={
                "video_id": video_hash
            }
        )

    title, url = meta.get(
        path.name,
        (
            path.stem,
            "",
        ),
    )

    if not title:
        title = path.stem

    duration = get_duration(path)

    windows = build_windows(
        duration
    )

    log(
        f"  … تحلیل {path.name} "
        f"— {len(windows)} پنجره زمانی"
    )

    start_time = time.time()

    segments = provider.understand(
        str(path),
        windows,
        progress=(
            lambda message, percent:
            log(
                f"    [{percent:3d}%] "
                f"{message}"
            )
        ),
    )

    elapsed = (
        time.time()
        - start_time
    )

    log(
        f"  ✓ {len(segments)} سگمنت "
        f"در {elapsed / 60:.1f} دقیقه"
    )

    documents = []

    for index, segment in enumerate(
        segments,
        start=1,
    ):

        transcript = (
            segment.get("transcript")
            or ""
        )

        visual = (
            segment.get(
                "visual_description"
            )
            or ""
        )

        semantic_text = (
            transcript
            + " "
            + visual
        )

        if len(
            semantic_text.strip()
        ) < MIN_CHARS:

            continue

        # timestamp واقعی Provider
        segment = dict(segment)

        segment["start_time"] = float(
            segment.get(
                "start_time",
                0.0,
            )
        )

        segment["end_time"] = float(
            segment.get(
                "end_time",
                segment["start_time"],
            )
        )

        document = segment_to_document(
            segment,
            {
                "video_id": video_hash,
                "file_name": path.name,
                "title": title,
                "url": url,
            },
        )

        document.metadata["chunk"] = index

        document.metadata["file_size"] = round(
            size_mb,
            2,
        )

        documents.append(
            document
        )

    if not documents:

        log(
            f"  [!] {path.name}: "
            "هیچ محتوای معناداری استخراج نشد."
        )

        return 0

    store.add_documents(
        documents
    )

    log(
        f"  ✓ {len(documents)} چانک "
        f"در collection "
        f"«{config.VIDEO_COLLECTION}» ذخیره شد"
    )

    return len(documents)


def probe_youtube_duration(url: str) -> float:
    """
    تخمین مدت ویدئوی YouTube از صفحهٔ آن (بدون دانلود).

    اگر نشد 0.0 برمیگرداند و رفتار قبلی (پنجرههای ثابت) حفظ میشود.
    """

    try:
        import requests

        response = requests.get(
            url,
            timeout=15,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                )
            },
        )

        text = response.text or ""

        match = re.search(
            r'"lengthSeconds"\s*:\s*"(\d+)"',
            text,
        )

        if match:
            return float(match.group(1))

        match = re.search(
            r'"approxDurationMs"\s*:\s*"(\d+)"',
            text,
        )

        if match:
            return round(float(match.group(1)) / 1000.0, 1)

    except Exception:
        pass

    return 0.0


def _url_windows(duration: float = 0.0):
    """
    ساخت پنجره‌های متوالی برای YouTube.

    اگر مدت واقعی ویدئو مشخص باشد، دقیقاً همان‌قدر پنجره ساخته
    میشود (سقف: VIDEO_URL_MAX_WINDOWS). اگر مشخص نباشد، مثل قبل
    پنجره‌های ثابت ساخته میشوند.
    """

    step = float(
        URL_WINDOW_SECONDS
    )

    if step <= 0:
        step = 600.0

    if duration and duration > 0:

        count = int(
            math.ceil(duration / step)
        )

        count = max(1, min(count, max(URL_MAX_WINDOWS, 1)))

        return [
            {
                "start": round(
                    min(index * step, max(duration - 1.0, 0.0)),
                    1,
                ),
                "end": round(
                    min((index + 1) * step, duration),
                    1,
                ),
            }
            for index in range(count)
        ]

    return [
        {
            "start": float(
                index * step
            ),
            "end": float(
                (index + 1) * step
            ),
        }
        for index in range(
            max(
                URL_MAX_WINDOWS,
                1,
            )
        )
    ]


def process_youtube(
    url: str,
    title_hint: str,
    provider,
    force: bool,
    log=None,
):
    """
    تحلیل مستقیم ویدئوی YouTube.
    """

    if log is None:
        log = print

    video_id = extract_youtube_id(
        url
    )

    if not video_id:

        raise VideoUnderstandingError(
            (
                "لینک یوتیوب معتبر نیست. "
                "نمونه: "
                "https://www.youtube.com/watch?v=XXXXXXXXXXX"
            ),
            kind="fatal",
        )

    store = config.video_store()

    existing = store.get(
        where={
            "video_id": video_id
        }
    )

    existing_ids = (
        existing.get("ids")
        or []
    )

    if existing_ids and not force:

        log(
            f"  = ویدئوی یوتیوب "
            f"{video_id} قبلاً ایندکس شده — SKIP"
        )

        return 0

    if existing_ids:

        log(
            f"  ↻ ویدئوی یوتیوب "
            f"{video_id} — REINDEX"
        )

        store.delete(
            where={
                "video_id": video_id
            }
        )

    title = (
        title_hint or ""
    ).strip()

    if not title:

        title = (
            f"یوتیوب {video_id}"
        )

    duration = probe_youtube_duration(url)

    windows = _url_windows(duration)

    log(
        f"  … تحلیل لینک یوتیوب "
        f"{video_id} "
        f"— پنجره‌های "
        f"{URL_WINDOW_SECONDS} ثانیه‌ای"
    )

    start_time = time.time()

    segments = provider.understand_url(
        url,
        windows,
        progress=(
            lambda message, percent:
            log(
                f"    [{percent:3d}%] "
                f"{message}"
            )
        ),
    )

    elapsed = (
        time.time()
        - start_time
    )

    log(
        f"  ✓ {len(segments)} سگمنت "
        f"در {elapsed / 60:.1f} دقیقه"
    )

    documents = []

    for index, segment in enumerate(
        segments,
        start=1,
    ):

        transcript = (
            segment.get("transcript")
            or ""
        )

        visual = (
            segment.get(
                "visual_description"
            )
            or ""
        )

        semantic_text = (
            transcript
            + " "
            + visual
        )

        if len(
            semantic_text.strip()
        ) < MIN_CHARS:

            continue

        document = segment_to_document(
            segment,
            {
                "video_id": video_id,
                "file_name": (
                    f"https://youtu.be/"
                    f"{video_id}"
                ),
                "title": title,
                "url": url,
            },
        )

        document.metadata["chunk"] = index

        documents.append(
            document
        )

    if not documents:

        log(
            "  [!] هیچ محتوای معناداری "
            "از ویدئو استخراج نشد."
        )

        return 0

    store.add_documents(
        documents
    )

    log(
        f"  ✓ {len(documents)} چانک "
        f"در collection "
        f"«{config.VIDEO_COLLECTION}» ذخیره شد"
    )

    return len(documents)


def main():

    parser = argparse.ArgumentParser(
        description="ساخت ایندکس ویدئو"
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help=(
            "ایندکس مجدد حتی اگر "
            "ویدئو قبلاً پردازش شده باشد"
        ),
    )

    parser.add_argument(
        "--file",
        help=(
            "فقط همین فایل "
            "(نام یا مسیر داخل videos/)"
        ),
    )

    parser.add_argument(
        "--url",
        help=(
            "تحلیل مستقیم لینک یوتیوب "
            "(بدون دانلود)"
        ),
    )

    parser.add_argument(
        "--title",
        help=(
            "عنوان ویدئوی یوتیوب "
            "(با --url)"
        ),
    )

    args = parser.parse_args()

    print("=" * 60)

    print(
        "  ساخت ایندکس ویدئو — "
        "ایجنت عمومی"
    )

    print("=" * 60)

    print(
        f"پرووایدر: "
        f"{config.VIDEO_PROVIDER}"
        f" | مدل: "
        f"{config.VIDEO_MODEL}"
    )

    print()

    try:

        provider = get_provider()

    except VideoUnderstandingError as error:

        raise SystemExit(
            f"خطای provider: {error}"
        )

    # -------------------------
    # YouTube
    # -------------------------

    if args.url:

        try:

            total = process_youtube(
                args.url,
                args.title or "",
                provider,
                force=args.force,
            )

        except VideoUnderstandingError as error:

            print(
                f"[x] خطای YouTube: "
                f"{error}"
            )

            return

        except Exception as error:

            print(
                "[x] خطای غیرمنتظره: "
                f"{type(error).__name__}: "
                f"{error}"
            )

            return

        print()

        print(
            f"تمام شد. مجموع چانک‌های جدید: "
            f"{total}"
        )

        print(
            "برای سؤال درباره ویدئوها "
            "بعداً Agent را اجرا می‌کنیم."
        )

        return

    # -------------------------
    # Local videos
    # -------------------------

    if not VIDEOS_DIR.exists():

        raise SystemExit(
            "پوشه videos پیدا نشد. "
            "آن را بساز و فایل‌های mp4 را داخلش بگذار."
        )

    files = sorted(
        f
        for f in VIDEOS_DIR.iterdir()
        if f.is_file()
        and f.suffix.lower() in config.VIDEO_EXTENSIONS
    )

    if args.file:

        requested_name = Path(
            args.file
        ).name

        files = [
            file
            for file in files
            if file.name
            == requested_name
        ]

        if not files:

            raise SystemExit(
                f"فایل «{args.file}» "
                "داخل videos/ نیست."
            )

    if not files:

        raise SystemExit(
            "هیچ فایل ویدئویی پشتیبانی‌شده‌ای در پوشه videos نیست."
        )

    metadata = read_metadata()

    total = 0

    for file in files:

        size_mb = (
            file.stat().st_size
            / (1024 * 1024)
        )

        print(
            f"▶ {file.name} "
            f"({size_mb:.0f} MB)"
        )

        try:

            total += process_video(
                file,
                metadata,
                provider,
                force=args.force,
            )

        except VideoUnderstandingError as error:

            print(
                f"  [x] {file.name}: "
                f"{error}"
            )

        except Exception as error:

            print(
                f"  [x] {file.name}: "
                f"خطای غیرمنتظره — "
                f"{type(error).__name__}: "
                f"{error}"
            )

    print()

    print("=" * 60)

    print(
        f"تمام شد. مجموع چانک‌های جدید: "
        f"{total}"
    )

    print(
        "مرحله بعد: اتصال Video Retriever "
        "به Agent."
    )


if __name__ == "__main__":
    main()