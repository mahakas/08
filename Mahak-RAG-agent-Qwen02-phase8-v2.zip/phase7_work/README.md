# Mahak RAG Agent

A Persian-speaking RAG agent built with LangGraph that answers **only from your own data**, cites its sources, and honestly **admits when it doesn't know** — instead of hallucinating. Free, local, and beginner-friendly.

It reads **Word, PDF, TXT, HTML and Markdown documents**, **analyzes images** (via a Vision model or OCR) and **understands videos and YouTube links** — chunks everything, embeds it, stores it in a local Chroma database, and answers grounded in those sources.

> This repo is the companion code for the video tutorial on building an AI agent from scratch.

**[فارسی را پایین‌تر بخوانید ↓](#راهنمای-فارسی)**

---

## What makes this an agent, not a workflow

A plain RAG pipeline is a straight line: question → retrieve → answer. This agent makes real decisions:

1. **Retrieve** from a local vector database (documents + images + videos).
2. **Self-grade** — a model judges whether the retrieved chunks actually answer the question.
3. **Rewrite & loop** — if not, it rewrites the query and searches again (max 2 tries).
4. **Admit & fall back** — if it still can't answer, it says so honestly, then searches the web.

It has two real tools (the archive and the web), a loop, and it judges its own output. That's what makes it an agent.

## Features

- 🎯 Answers grounded in your documents, with source citations
- 📄 Ingests `.docx`, `.pdf`, `.txt`, `.md`, `.html`
- 🖼 Analyses images (`png`, `jpg`, `webp`, `bmp`, `gif`, `tiff`) with a Vision model or OCR
- 🎥 Video (`.mp4`) and YouTube-link understanding with real timestamps
- 🔁 Self-correcting retrieval loop with a hard iteration cap
- 🧠 Conversation memory (follow-up questions work)
- 🛡️ Prompt-injection guardrails (3 layers)
- 🌐 Falls back to web search when the archive has no answer
- ♻️ Model-failover chain — survives rate limits and dead endpoints
- 🇮🇷 Multilingual embeddings — works well with Persian text
- 💰 Fully free: free models, local embeddings, local database

## Stack

| Layer | Tool |
|---|---|
| Orchestration | LangGraph |
| LLM | NVIDIA Build (free tier) / OpenAI-compatible |
| Embeddings | BAAI/bge-m3 (local, CPU) or external BGE Server |
| Vector DB | Chroma (local) |
| Text readers | python-docx, pypdf/pdfplumber, BeautifulSoup |
| Vision | Gemini / Qwen-VL (OpenAI-compatible) / Tesseract OCR |
| Web search | ddgs (DuckDuckGo) |
| UI | Gradio |

## Three Chroma collections

The index is split so re-ingesting one type never wipes another:

| Collection | Holds |
|---|---|
| `TEXT_COLLECTION` (default `mahak_scripts`) | Documents: DOCX, PDF, TXT, HTML, MD |
| `IMAGE_COLLECTION` (default `mahak_images`) | Analysed images (vision text + OCR) |
| `VIDEO_COLLECTION` (default `mahak_videos`) | Time-stamped video segments |

The agent searches all three on every question.

## Setup

**1. Clone and enter**
```bash
git clone <repo-url>
cd mahak-rag-agent
```

**2. Virtual environment**
```bash
python -m venv .venv
# Windows:
.\.venv\Scripts\Activate.ps1
# macOS / Linux:
source .venv/bin/activate
```

**3. Install**
```bash
pip install -r requirements.txt
```

**4. Configure**

Copy `.env.example` to `.env` and add your free NVIDIA API key from [build.nvidia.com](https://build.nvidia.com), plus a Gemini (or Qwen) key if you want video/image analysis:
```
NVIDIA_API_KEY=nvapi-xxxxxxxx
GEMINI_API_KEY=...
EMBED_BACKEND=local
```

> `NVIDIA_BASE_URL` must be the **base URL** (e.g. `https://integrate.api.nvidia.com/v1`), not the full `/chat/completions` endpoint. `config.py` strips an accidental `/chat/completions` suffix as a safety net.

**5. Add your data**

Drop your `.docx`, `.pdf`, `.txt`, `.md`, `.html` and image files into `scripts/`. Optionally add `metadata.xlsx` (or `metadata.csv`) with columns `file`, `title`, `url` so answers can link back to sources.

## Run

```bash
# 1. Build the document + image index
python ingest.py            # everything
python ingest.py --no-images    # documents only
python ingest.py --only-images  # vision/OCR for images only

# 2. (Optional) build the video index from videos/*.mp4
python video_ingest.py

# 3. Launch the chat UI
python app.py
```

## Swapping models

All model names live in `.env`, not in the code. Because the providers follow the OpenAI-compatible standard, switching providers is usually just changing `NVIDIA_BASE_URL` and the model names — the code stays untouched.

If a model gets deprecated, just edit `.env`. No code changes needed.

## Embeddings

- `EMBED_BACKEND=local` (default) loads `BAAI/bge-m3` locally through `sentence-transformers` — no external service, works offline after the first download (~2.3 GB).
- `EMBED_BACKEND=bge` calls an external BGE Server over HTTP at `BGE_SERVER_URL` (default `http://127.0.0.1:8000`). If that server is unreachable, the code prints a warning and falls back to local embeddings automatically.

> Whichever backend you pick must be used consistently for both ingestion and querying — embeddings from different models are not comparable. Re-run ingestion after switching.

## Notes

- The NVIDIA free tier is rate-limited (~40 req/min). The agent handles this with exponential backoff and a model-failover chain.
- The free key is for personal/development use. Commercial use needs a license.
- The `scripts/` and `videos/` folders and the local data files are git-ignored.
- `.doc` (legacy binary Word) is not supported — convert it to `.docx`.

## License

MIT

---
---

<a name="راهنمای-فارسی"></a>

<div dir="rtl">

# دستیار هوش مصنوعی مهک (راهنمای فارسی)

## نسخهٔ Qwen

این کپی برای تحلیل ویدئو و تصویر با Qwen آماده شده است و نسخهٔ اصلی Gemini را تغییر نمی‌دهد.
فایل `.env.example` را به `.env` تبدیل کن و این موارد را تنظیم کن:

```env
VIDEO_PROVIDER=qwen
IMAGE_PROVIDER=qwen
QWEN_API_KEY=کلید سرویس Qwen
QWEN_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
QWEN_VIDEO_MODEL=qwen2.5-vl-72b-instruct
QWEN_IMAGE_MODEL=qwen2.5-vl-72b-instruct
```

`QWEN_BASE_URL` باید endpointی باشد که قالب OpenAI-compatible و ورودی `video_url` / `image_url` را پشتیبانی کند. برای لینک YouTube، سرویس Qwen باید بتواند URL عمومی ویدئو را بخواند. اگر endpoint سرویس شما فقط فایل آپلودشده را می‌پذیرد، ابتدا ویدئو را دانلود کن و از تب «ویدئو (MP4)» استفاده کن.

یک ایجنت هوش مصنوعی فارسی‌زبان، ساخته‌شده با LangGraph، که **فقط از روی دیتای خودت** جواب می‌دهد، منبع هر جوابش را نشان می‌دهد، و هر جا نداند **صادقانه می‌گوید نمی‌دانم** — به‌جای اینکه از خودش در بیاورد. رایگان، لوکال، و مناسب مبتدی.

> این کد، همراه ویدیوی آموزش ساخت ایجنت از صفر است.

## چرا این ایجنت است، نه ورک‌فلو

یک رگ ساده یک خط مستقیم است: سؤال ← بازیابی ← جواب. ولی این ایجنت واقعاً تصمیم می‌گیرد:

۱. **بازیابی** از وکتور دیتابیس لوکال (اسناد + تصاویر + ویدئوها).
۲. **داوری** — یک مدل قضاوت می‌کند که آیا تیکه‌های پیداشده واقعاً جواب سؤال را دارند.
۳. **بازنویسی و حلقه** — اگر نداشتند، سؤال را با کلمات دیگر می‌نویسد و دوباره می‌گردد (سقف: دو بار).
۴. **اعتراف و ابزار دوم** — اگر باز هم نشد، صادقانه می‌گوید بلد نیست، بعد می‌رود سراغ وب.

دو ابزار واقعی دارد (آرشیو و وب)، یک حلقه دارد، و روی خروجی خودش قضاوت می‌کند. همین یعنی ایجنت.

## امکانات

- 🎯 جواب از روی اسناد خودت، با ذکر منبع
- 📄 خواندن `.docx`، `.pdf`، `.txt`، `.md`، `.html`
- 🖼 تحلیل تصویر (jpg، png، webp، bmp، gif، tiff) با Vision Model یا OCR
- 🎥 درک ویدئو (mp4) و لینک YouTube با timestamp واقعی
- 🔁 حلقهٔ بازیابی خوداصلاح، با سقف تکرار مشخص
- 🧠 حافظهٔ مکالمه (سؤال دنباله‌دار کار می‌کند)
- 🛡️ محافظت در برابر پرامپت اینجکشن (سه لایه)
- 🌐 وقتی آرشیو جواب نداشت، می‌رود سراغ وب
- ♻️ زنجیرهٔ جایگزینی مدل — از ریت‌لیمیت و مرگ مدل جان سالم به در می‌برد
- 🇮🇷 امبدینگ چندزبانه — با متن فارسی خوب کار می‌کند
- 💰 کاملاً رایگان: مدل رایگان، امبدینگ لوکال، دیتابیس لوکال

## وارد کردن داده

این پروژه چهار مسیر داده دارد:

| نوع داده | محل قرار دادن | روش اجرا |
|---|---|---|
| Word با پسوند `.docx` | `scripts/` | اجرای `python ingest.py` یا تب «اسناد (DOCX/PDF/TXT/HTML)» در رابط |
| `.pdf` | `scripts/` | در همان تب «اسناد» (پارسر: pypdf، و در صورت نبودش pdfplumber) |
| `.txt` و `.md` | `scripts/` | در همان تب «اسناد» |
| `.html` و `.htm` | `scripts/` | در همان تب «اسناد» (بدون تگ، با BeautifulSoup یا regex) |
| تصویر (`.jpg`، `.png`، `.webp`، `.bmp`، `.gif`، `.tiff`) | `scripts/` | اجرای `python ingest.py --only-images` یا تب «تصاویر (Vision)» |
| ویدئوی `.mp4` | `videos/` | اجرای `python video_ingest.py` یا تب «ویدئو (MP4)» در رابط |
| لینک YouTube | نیازی به ذخیره فایل نیست | تب «لینک یوتیوب» در رابط یا دستور `python video_ingest.py --url "..."` |

### فایل‌های متنی

فایل‌های `.docx`، `.pdf`، `.txt`، `.md`، `.html` را داخل پوشهٔ `scripts/` بریز و سپس ایندکس متن را بساز:

```bash
python ingest.py --no-images
```

برای عنوان و لینک منبع، می‌توانی کنار آن فایل `metadata.xlsx` یا `metadata.csv` قرار بدهی. ستون‌های لازم عبارت‌اند از `file`، `title` و `url`.

### تصاویر

تصاویر هم داخل `scripts/` قرار می‌گیرند ولی با یک collection جدا ایندکس می‌شوند تا بازسازی ایندکس متن، تحلیل تصاویر را پاک نکند:

```bash
python ingest.py --only-images     # فقط تصاویر
python ingest.py                   # اسناد + تصاویر
```

از طریق `IMAGE_PROVIDER` مشخص می‌کنی با Qwen-VL تحلیل شوند یا با Gemini؛ `get_image_provider` اگر هیچ مدلی در دسترس نبود به OCR (pytesseract) برمی‌گردد. خروجی تحلیل شامل متن داخل تصویر، توضیح تصویری و نوع تصویر (photo/screenshot/diagram/scan) است و در collection تصویر ذخیره می‌شود. برای OCR فارسی، موتور Tesseract با زبان `fas` باید نصب باشد (`OCR_LANG=fas+eng`).

### ویدئو و YouTube

فایل `.mp4` را داخل `videos/` قرار بده و اجرا کن:

```bash
python video_ingest.py
```

یا از تب‌های ویدئویی رابط `app.py` استفاده کن. برای لینک YouTube، لینک را مستقیماً در تب «لینک یوتیوب» وارد کن؛ دانلود دستی لازم نیست. در خط فرمان نیز می‌توانی از این شکل استفاده کنی:

```bash
python video_ingest.py --url "https://www.youtube.com/watch?v=VIDEO_ID" --title "عنوان اختیاری"
```

پوشه‌های `scripts/` و `videos/` و فایل‌های دادهٔ محلی در Git نادیده گرفته می‌شوند؛ داده‌ها را فقط در همان پوشه‌های محلی پروژه نگه دار.

## سه collection در کروما

ایندکس به سه collection تقسیم شده تا بازسازی یکی، بقیه را پاک نکند:

| collection | نگه‌دارنده |
|---|---|
| `TEXT_COLLECTION` (پیش‌فرض `mahak_scripts`) | اسناد متنی (DOCX/PDF/TXT/HTML/MD) |
| `IMAGE_COLLECTION` (پیش‌فرض `mahak_images`) | متن تحلیل‌شدهٔ تصاویر (تصویری + OCR) |
| `VIDEO_COLLECTION` (پیش‌فرض `mahak_videos`) | چانک‌های زمان‌دار ویدئو |

ایجنت هنگام بازیابی، در هر سه جستوجو می‌کند و نتایج را merge می‌کند.

## استک

| لایه | ابزار |
|---|---|
| ارکستریشن | LangGraph |
| مدل زبانی | NVIDIA Build (لایهٔ رایگان) / OpenAI-compatible |
| امبدینگ | BAAI/bge-m3 (لوکال، CPU) یا BGE Server خارجی |
| وکتور دیتابیس | Chroma (لوکال) |
| خوانندگان متن | python-docx، pypdf/pdfplumber، BeautifulSoup |
| تحلیل تصویر/ویدئو | Gemini یا Qwen-VL یا Tesseract OCR |
| جست‌وجوی وب | ddgs |
| رابط کاربری | Gradio |

## ساختار پروژه

```
config.py            اتصال به مدل، زنجیرهٔ جایگزین، موتور امبدینگ، collectionها
ingest.py            خوانندهٔ چندفرمتی (docx/pdf/txt/html) + تحلیل تصویر → چانک → کروما
image_provider.py    فکتوری Vision (qwen / gemini / ocr) برای تحلیل تصویر
video_ingest.py      تحلیل ویدئو و لینک YouTube → چانک زمان‌دار → collection ویدئو
video_provider.py    واسط انتزاعی پرووایدر درک ویدئو/تصویر
agent.py             گراف لنگ‌گراف — بازیابی ترکیبی (متن + تصویر + ویدئو)
video_citation.py    ساخت citation فقط از متادیتای واقعی (timestamp / url / منبع)
guard.py             سه لایه گاردریل امنیتی
app.py               رابط چت گرِیدیو — اسناد + تصاویر + ویدئو + YouTube + چت
api_server.py        (اختیاری) backend FastAPI
requirements.txt
scripts/             ← فایل‌های متنی و تصویری خودت را اینجا بگذار
metadata.xlsx        ← اختیاری: file, title, url
```

## نصب

**۱. کلون و ورود به پوشه**
```bash
git clone <repo-url>
cd mahak-rag-agent
```

**۲. محیط مجازی**
```bash
python -m venv .venv
# ویندوز:
.\.venv\Scripts\Activate.ps1
# مک / لینوکس:
source .venv/bin/activate
```

**۳. نصب پکیج‌ها**
```bash
pip install -r requirements.txt
```

**۴. تنظیمات**

فایل `.env.example` را به `.env` تغییر نام بده و کلید رایگان انویدیا را از [build.nvidia.com](https://build.nvidia.com) بگیر و بگذار:
```
NVIDIA_API_KEY=nvapi-xxxxxxxx
```

> `NVIDIA_BASE_URL` باید آدرس پایه باشد (مثلاً `https://integrate.api.nvidia.com/v1`)، نه خود endpoint کامل `/chat/completions`. اگر پسوند اضافه بگذاری، `config.py` به‌صورت خودکار حذفش می‌کند.

**۵. دیتای خودت**

فایل‌های `.docx`، `.pdf`، `.txt`، `.md`، `.html` یا تصاویر را در پوشهٔ `scripts/` بریز. اگر خواستی، `metadata.xlsx` را با ستون‌های `file`، `title`، `url` بساز تا جواب‌ها به منبع لینک بخورند.

## اجرا

```bash
# ۱. ساخت ایندکس (یک بار، چند دقیقه طول می‌کشد)
python ingest.py              # متن + تصاویر
python ingest.py --no-images  # فقط متن اسناد
python ingest.py --only-images  # فقط تحلیل تصاویر

# ۲. اجرای رابط چت
python app.py
```

## امبدینگ

دو راه داری (با `EMBED_BACKEND` در `.env`):

- `local` (پیش‌فرض): مدل `BAAI/bge-m3` روی CPU و همان‌جای پروژه اجرا می‌شود؛ به سرویس جدا نیازی نیست و بعد از یک بار دانلود، آفلاین کار می‌کند.
- `bge`: فراخوانی BGE Server روی `BGE_SERVER_URL` (پیش‌فرض `http://127.0.0.1:8000`). اگر سرور بالا نباشد، کد هشدار می‌دهد و خودکار به امبدینگ لوکال برمی‌گردد تا ingest کرش نکند.

> امبدینگ‌ها باید در زمان ایندکس و زمان بازیابی از یک مدل باشند؛ اگر بک‌اند را عوض کردی، ایندکس را دوباره بساز.

## عوض کردن مدل

اسم همهٔ مدل‌ها در `.env` است، نه در کد. چون سرویس‌ها از استاندارد اوپن‌ای‌آی پیروی می‌کنند، برای رفتن سراغ سرویس دیگر معمولاً فقط `NVIDIA_BASE_URL` و اسم مدل‌ها را عوض می‌کنی — کد دست‌نخورده می‌ماند.

اگر مدلی از دسترس خارج شد، فقط `.env` را عوض کن.

## نکته‌ها

- لایهٔ رایگان انویدیا ریت‌لیمیت دارد (حدود ۴۰ درخواست در دقیقه). ایجنت با عقب‌نشینی نمایی و زنجیرهٔ جایگزین مدل این را مدیریت می‌کند.
- کلید رایگان برای استفادهٔ شخصی و توسعه است. استفادهٔ تجاری به لایسنس نیاز دارد.
- امبدینگ لوکال روی سی‌پی‌یو اجرا می‌شود — بدون ریت‌لیمیت، بدون تاریخ انقضا، و بعد از دانلود اول (حدود ۲.۳ گیگ) آفلاین کار می‌کند.
- فرمت قدیمی `.doc` ورد پشتیبانی نمی‌شود؛ اول به `.docx` تبدیلش کن.

## لایسنس

MIT

</div>

## Phase 7 — Educational Chat

مسیر آموزشی نسخه v2 اکنون به‌صورت closed-world پیاده‌سازی شده است:

```text
ConversationContext
  -> QueryPlanner
  -> RetrievalScope
  -> RetrievalService
  -> Context/Prompt Builder
  -> Provider Orchestrator (CHAT)
  -> Answer + Source-aware Citations
```

اگر Retrieval نتیجه قابل‌اعتماد نداشته باشد، پاسخ کنترل‌شدهٔ زیر برگردانده می‌شود:

`این سؤال در منابع آموزشی انتخاب‌شده برای این درس پیدا نشد.`

Endpoint پایه:

`POST /api/chat/educational`

این endpoint فعلاً از Providerهای Mock برای تست محلی استفاده می‌کند؛ Providerهای واقعی در فازهای بعدی به Registry متصل خواهند شد.
