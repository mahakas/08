"""
ساخت ایندکس — ایجنت مهک

فایلهای پوشهٔ scripts/ را میخواند، تکهتکه میکند، امبد میکند
و در کروما ذخیره میکند.

فرمتهای پشتیبانیشده:

    .docx          → متن پاراگرافها
    .pdf           → متن همهٔ صفحهها (pypdf؛ در صورت نبود pdfplumber)
    .txt / .md     → متن خام
    .html / .htm   → متن بدون تگ (BeautifulSoup؛ در صورت نبود regex)
    .png/.jpg/...  → تحلیل با Vision Model و ذخیره در collection تصویر

ساختار پوشه:
    scripts/
        هر فایل یک منبع
    metadata.csv   (اختیاری ولی توصیهشده)
        file,title,url

اگر metadata.csv نباشد، اسم فایل بهعنوان عنوان استفاده میشود.

اجرا:
    python ingest.py
    python ingest.py --no-images      # تصاویر را نادیده بگیر
    python ingest.py --only-images    # فقط تصاویر
"""

import argparse
import csv
import io
import os
import re
import time
from pathlib import Path

from docx import Document as Docx
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma

import config

from config import (
    embedder,
    CHROMA_DIR,
    COLLECTION,
    IMAGE_COLLECTION,
    DOCUMENT_EXTENSIONS,
    IMAGE_EXTENSIONS,
)

SCRIPTS_DIR = Path("scripts")
META_CSV = Path("metadata.csv")
META_XLSX = Path("metadata.xlsx")

# اسکریپت گفتاری پاراگرافبندی طبیعی دارد، ولی تیتر ندارد.
# ۹۰۰ کاراکتر یعنی حدود یک دقیقه حرف — واحد معنایی خوبی است.
CHUNK_SIZE = 900
CHUNK_OVERLAP = 150

SEPARATORS = ["\n\n", "\n", "؟ ", ". ", "، ", " ", ""]

# حداقل طول متن برای اینکه یک سند اصلا وارد چانکینگ شود
MIN_DOC_CHARS = 200

# اکسل روی ویندوز فارسی معمولا با cp1256 ذخیره میکند، نه یوتیاف-۸
ENCODINGS = ["utf-8-sig", "utf-8", "cp1256", "cp1252"]


# =============================================================
# متادیتا
# =============================================================

def _read_text(path):
    """فایل را با هر کدگذاری که کار کند بخوان."""
    for enc in ENCODINGS:
        try:
            text = path.read_text(encoding=enc)
            if enc not in ("utf-8-sig", "utf-8"):
                print(f"  [!] metadata.csv با کدگذاری {enc} خوانده شد.")
            return text
        except (UnicodeDecodeError, LookupError):
            continue
    raise SystemExit("metadata.csv با هیچ کدگذاری خوانده نشد.")


def _rows_from_xlsx():
    """اکسل را مستقیم بخوان. هیچ مشکل کدگذاریای ندارد."""
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise SystemExit("برای خواندن اکسل این را نصب کن:  pip install openpyxl")

    wb = load_workbook(META_XLSX, read_only=True, data_only=True)
    ws = wb.active

    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []

    header = [str(c).strip().lower() if c else "" for c in rows[0]]
    out = []
    for r in rows[1:]:
        if not any(r):
            continue
        out.append({header[i]: (str(r[i]).strip() if i < len(r) and r[i] else "")
                    for i in range(len(header))})
    print(f"metadata.xlsx خوانده شد — {len(out)} ردیف")
    return out


def _rows_from_csv():
    text = _read_text(META_CSV)
    first = text.splitlines()[0] if text.splitlines() else ""
    delim = ";" if first.count(";") > first.count(",") else ","
    reader = csv.DictReader(io.StringIO(text), delimiter=delim)
    out = [{(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
           for row in reader]
    print(f"metadata.csv خوانده شد — {len(out)} ردیف")
    return out


def read_metadata():
    """اسم فایل → (عنوان، لینک). اول اکسل، بعد سیاسوی."""
    if META_XLSX.exists():
        rows = _rows_from_xlsx()
    elif META_CSV.exists():
        rows = _rows_from_csv()
    else:
        print("فایل متادیتا نبود. اسم فایل بهعنوان عنوان استفاده میشود.")
        return {}

    if rows and "file" not in rows[0]:
        raise SystemExit(
            "ستون file پیدا نشد.\n"
            f"ستونهایی که هست: {list(rows[0].keys())}\n"
            "سه ستون لازم است با همین اسمها: file  title  url"
        )

    meta = {}
    for r in rows:
        name = r.get("file", "")
        if name:
            meta[name] = (r.get("title", ""), r.get("url", ""))
    return meta


# =============================================================
# خوانندههای متن
# =============================================================

def read_docx(path):
    """متن پاراگرافهای فایل Word."""
    doc = Docx(path)
    parts = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    return "\n\n".join(parts)


def read_txt(path):
    """فایل متنی خام با تشخیص خودکار کدگذاری."""
    for enc in ENCODINGS:
        try:
            return path.read_text(encoding=enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return path.read_text(encoding="utf-8", errors="ignore")


def read_pdf(path):
    """
    متن همهٔ صفحههای PDF.

    اول pypdf، اگر نبود pdfplumber. خطاها باعث رد شدن فایل
    میشوند (برمیگردد رشتهٔ خالی) نه کرش کل ingest.
    """
    try:
        from pypdf import PdfReader
    except ImportError:
        PdfReader = None

    if PdfReader is not None:

        try:
            reader = PdfReader(str(path))
            pages = [
                (page.extract_text() or "").strip()
                for page in reader.pages
            ]
            text = "\n\n".join(p for p in pages if p)

            if text.strip():
                return text

        except Exception as error:
            print(f"  [!] pypdf نتوانست {path.name} را بخواند: {type(error).__name__}")

    try:
        import pdfplumber
    except ImportError:
        print(
            f"  [!] {path.name}: نه pypdf موفق بود نه pdfplumber. "
            "نصب کن: pip install pypdf  یا  pip install pdfplumber"
        )
        return ""

    try:
        with pdfplumber.open(str(path)) as pdf:
            pages = [
                (page.extract_text() or "").strip()
                for page in pdf.pages
            ]
        return "\n\n".join(p for p in pages if p)

    except Exception as error:
        print(f"  [!] pdfplumber نتوانست {path.name} را بخواند: {type(error).__name__}")
        return ""


def read_html(path):
    """
    متن بدون تگ فایل HTML.

    اول BeautifulSoup، اگر نبود پاکسازی با regex.
    """
    raw = read_txt(path)

    try:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(raw, "html.parser")

        for tag in soup(["script", "style", "noscript", "template"]):
            tag.decompose()

        text = soup.get_text("\n")

    except ImportError:
        text = re.sub(
            r"<(script|style|noscript)[^>]*>.*?</\1>",
            " ",
            raw,
            flags=re.I | re.S,
        )
        text = re.sub(r"<[^>]+>", "\n", text)

    text = re.sub(r"&nbsp;?", " ", text)
    lines = [line.strip() for line in text.splitlines()]
    return "\n".join(line for line in lines if line)


READERS = {
    ".docx": read_docx,
    ".txt": read_txt,
    ".md": read_txt,
    ".pdf": read_pdf,
    ".html": read_html,
    ".htm": read_html,
}


# =============================================================
# خواندن همهٔ اسناد متنی
# =============================================================

def _iter_files(extensions):
    """فایلهای پوشهٔ scripts با پسوندهای خواستهشده."""
    if not SCRIPTS_DIR.exists():
        return []

    files = [
        f
        for f in sorted(SCRIPTS_DIR.iterdir())
        if f.is_file()
        and f.suffix.lower() in extensions
        and not f.name.startswith("~$")   # فایل موقت ورد
    ]
    return files


def load_all():
    """
    خواندن همهٔ اسناد متنی پوشهٔ scripts.

    تصاویر اینجا واکشی نمیشوند؛ برای آنها load_images() را ببين.
    اگر پوشه نباشد خطا می‌دهد؛ اگر خالی باشد [] برمی‌گرداند.
    """
    if not SCRIPTS_DIR.exists():
        raise SystemExit("پوشهٔ scripts پیدا نشد. بسازش و فایلها را داخلش بگذار.")

    meta = read_metadata()

    files = _iter_files(DOCUMENT_EXTENSIONS)

    if not files:
        print(
            "[!] هیچ فایل متنی پشتیبانی‌شده‌ای در scripts نیست.\n"
            "پسوندهای مجاز: "
            + ", ".join(sorted(DOCUMENT_EXTENSIONS))
        )
        return []

    docs = []

    for f in files:

        reader = READERS.get(f.suffix.lower())

        if reader is None:
            continue

        try:
            text = reader(f)
        except Exception as error:
            print(f"  [!] {f.name} خوانده نشد: {type(error).__name__} — {error}")
            continue

        text = (text or "").strip()

        if len(text) < MIN_DOC_CHARS:
            print(f"  [!] {f.name} تقریبا خالی است، رد شد.")
            continue

        title, url = meta.get(f.name, (f.stem, ""))
        if not title:
            title = f.stem

        docs.append(Document(
            page_content=text,
            metadata={
                "title": title,
                "url": url,
                "file": f.name,
                "source_type": "document",
                "file_type": f.suffix.lower().lstrip("."),
            },
        ))
        print(f"  {f.name}  →  {len(text.split()):,} کلمه  |  {title}")

    return docs


# =============================================================
# خواندن تصاویر
# =============================================================

def load_images(meta=None, log=print):
    """
    تحلیل تصاویر پوشهٔ scripts/ و تبدیل به Document.

    هر تصویر یک Document میشود که متن آن شامل متن OCR و توصیف
    تصویری است. متادیتا نشان میدهد منبع تصویری بوده تا citation
    درست ساخته شود.
    """
    files = _iter_files(IMAGE_EXTENSIONS)

    if not files:
        return []

    from image_provider import (
        get_image_provider,
        ImageUnderstandingError,
    )

    if meta is None:
        meta = read_metadata()

    try:
        provider = get_image_provider()
        log(f"provider تصویر: {provider.name}")
    except ImageUnderstandingError as error:
        log(f"[!] provider تصویر پیدا نشد: {error}")
        return []

    docs = []

    for f in files:

        title, url = meta.get(f.name, (f.stem, ""))
        if not title:
            title = f.stem

        log(f"  ... تحلیل تصویر {f.name} با {provider.name}")

        try:
            result = provider.describe(str(f), hint=title)
        except ImageUnderstandingError as error:
            log(f"  [!] {f.name}: {error}")
            continue
        except Exception as error:
            log(f"  [!] {f.name}: خطای غیرمنتظره — {type(error).__name__}")
            continue

        text = (result.get("text") or "").strip()

        if not text:
            log(f"  [!] {f.name}: محتوایی استخراج نشد، رد شد.")
            continue

        header = f"تصویر: {title}"

        docs.append(Document(
            page_content=f"{header}\n{text}",
            metadata={
                "title": title,
                "url": url,
                "file": f.name,
                "source_type": "image",
                "file_type": f.suffix.lower().lstrip("."),
                "image_kind": result.get("kind", "other"),
            },
        ))

        log(f"  ✓ {f.name}  →  {len(text.split()):,} کلمه  |  {title}")

    return docs


# =============================================================
# چانکینگ
# =============================================================

def build_splitter():
    return RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=SEPARATORS,
        length_function=len,
    )


def chunk_documents(docs, splitter=None):
    """تکهتکه کردن اسناد و شمارهگذاری چانکها."""
    splitter = splitter or build_splitter()
    chunks = splitter.split_documents(docs)

    per_source = {}

    for c in chunks:
        key = c.metadata.get("file") or c.metadata.get("title", "")
        per_source[key] = per_source.get(key, 0) + 1
        c.metadata["chunk"] = per_source[key]

    return chunks


def _fresh_store(collection_name, emb):
    """
    استور تمیز: فقط همین collection پاک میشود — نه کل دیتابیس؛
    وگرنه ایندکس ویدئو/تصویر هم از بین میرفت.
    """
    store = Chroma(
        collection_name=collection_name,
        embedding_function=emb,
        persist_directory=CHROMA_DIR,
    )

    try:
        store.delete_collection()
    except Exception:
        pass

    return Chroma(
        collection_name=collection_name,
        embedding_function=emb,
        persist_directory=CHROMA_DIR,
    )


def index_chunks(chunks, collection_name, emb, label=""):
    """افزودن چانکها به یک collection بهصورت دستهای."""
    store = _fresh_store(collection_name, emb)

    BATCH = 64
    total = len(chunks)

    for i in range(0, total, BATCH):
        store.add_documents(chunks[i:i + BATCH])
        done = min(i + BATCH, total)
        print(f"  {label}{done:,} / {total:,}", end="\r", flush=True)

    print()
    return store


# =============================================================
# main
# =============================================================

def main(only_images=False, skip_images=False):

    print("=" * 60)
    print("  ساخت ایندکس مهک")
    print("=" * 60)

    meta = read_metadata()

    docs = []

    if not only_images:
        docs = load_all()

    print(f"\n{len(docs)} سند متنی خوانده شد.")

    emb = embedder()

    if docs:

        chunks = chunk_documents(docs)

        print(f"{len(chunks):,} تکه ساخته شد.")
        print(f"میانگین {len(chunks) / len(docs):.0f} تکه برای هر سند.\n")

        print("در حال امبد کردن متن. این مرحله چند دقیقه طول میکشد ...\n")
        t = time.time()

        store = index_chunks(chunks, COLLECTION, emb, label="متن ")

        dt = time.time() - t
        print(f"\nمتن: تمام شد در {dt / 60:.1f} دقیقه.")

        print("\n" + "-" * 60)
        print("تست بازیابی متن:")
        hits = store.similarity_search("امبدینگ چیست", k=3)
        for h in hits:
            print(f"  [{h.metadata.get('title', '?')} — تکهٔ {h.metadata.get('chunk', '?')}]")
            print(f"    {h.page_content[:90]} ...")

    elif not only_images:
        print("[!] هیچ سند متنی پیدا نشد — collection متن دست نخورد.")

    # ---------------------------------------------------------
    # تصاویر
    # ---------------------------------------------------------

    if not skip_images:

        image_files = _iter_files(IMAGE_EXTENSIONS)

        if image_files:

            print("\n" + "=" * 60)
            print(f"  تحلیل {len(image_files)} تصویر")
            print("=" * 60)

            image_docs = load_images(meta)

            if image_docs:

                image_chunks = chunk_documents(image_docs)
                print(f"{len(image_chunks):,} تکه تصویری ساخته شد.")

                print("\nدر حال امبد کردن تصاویر ...\n")
                t = time.time()

                image_store = index_chunks(
                    image_chunks,
                    IMAGE_COLLECTION,
                    emb,
                    label="تصویر ",
                )

                dt = time.time() - t
                print(f"\nتصاویر: تمام شد در {dt / 60:.1f} دقیقه.")

                print("\n" + "-" * 60)
                print("تست بازیابی تصویر:")
                hits = image_store.similarity_search("متن تصویر", k=3)
                for h in hits:
                    print(f"  [{h.metadata.get('title', '?')}]")
                    print(f"    {h.page_content[:90]} ...")

            else:
                print("[!] هیچ تصویری تحلیل نشد.")

    print("\n" + "=" * 60)
    print(f"ایندکس در {CHROMA_DIR} ذخیره شد.")
    print(f"  متن    → «{COLLECTION}»")
    print(f"  تصویر  → «{IMAGE_COLLECTION}»")
    print("=" * 60)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(
        description="ساخت ایندکس اسناد و تصاویر"
    )

    parser.add_argument(
        "--only-images",
        action="store_true",
        help="فقط تصاویر تحلیل شوند",
    )

    parser.add_argument(
        "--no-images",
        action="store_true",
        help="تصاویر نادیده گرفته شوند",
    )

    args = parser.parse_args()

    main(
        only_images=args.only_images,
        skip_images=args.no_images,
    )