"""
پیکربندی و لایهٔ مقاوم فراخوانی مدل — ایجنت مهک

دو تصمیم مهم اینجاست:

۱. اسم هیچ مدلی داخل کد هاردکد نشده. همه از .env می‌آیند.
   انویدیا مدل‌ها را سریع بازنشسته می‌کند؛ با این کار، تعویض مدل
   یعنی عوض کردن یک خط در .env، نه دست زدن به کد.

۲. فراخوانی مدل هیچ‌وقت برنامه را نمی‌کشد. اول صبر می‌کند و دوباره
   امتحان می‌کند، بعد می‌رود سراغ مدل جایگزین، و اگر هیچ‌کدام جواب
   ندادند None برمی‌گرداند تا ایجنت بتواند تصمیم امن بگیرد.

بخش Video-RAG:
   - تنظیمات ویدئو هم همه از .env می‌آیند (VIDEO_*، GEMINI_*، QWEN_*)
   - سه collection جدا برای متن، تصویر و ویدئو

بخش Embedding:
   - EMBED_BACKEND=local → مدل لوکال BAAI/bge-m3 (پیش‌فرض)
   - EMBED_BACKEND=bge   → BGE Server روی HTTP؛ اگر نباشد، fallback لوکال
"""

import os
import time
import random
import requests

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.embeddings import Embeddings


load_dotenv()


# =============================================================
# تنظیمات LLM
# =============================================================

API_KEY = os.getenv("NVIDIA_API_KEY")

BASE_URL = os.getenv(
    "NVIDIA_BASE_URL",
    "https://integrate.api.nvidia.com/v1"
)

# اگر کسی آدرس کامل endpoint را بدهد (…/v1/chat/completions)،
# کلاینت OpenAI آن را دوباره به مسیر chat/completions اضافه میکند و
# آدرس خراب میشود. پس پسوند endpoint را حذف میکنیم.
_RAW_BASE_URL = BASE_URL.rstrip("/")

for _suffix in ("/chat/completions", "/completions"):

    if _RAW_BASE_URL.endswith(_suffix):

        _RAW_BASE_URL = _RAW_BASE_URL[: -len(_suffix)]
        break

BASE_URL = _RAW_BASE_URL or "https://integrate.api.nvidia.com/v1"

EMBED_MODEL = os.getenv(
    "EMBED_MODEL",
    "BAAI/bge-m3"
)

if not API_KEY:
    raise SystemExit(
        "NVIDIA_API_KEY در فایل .env پیدا نشد."
    )


def _chain(primary_key, fallback_key):
    primary = os.getenv(primary_key, "")
    extras = os.getenv(fallback_key, "")

    models = [
        primary
    ] + [
        m.strip()
        for m in extras.split(",")
        if m.strip()
    ]

    return [
        m
        for m in models
        if m
    ]


GEN_CHAIN = _chain(
    "GEN_MODEL",
    "GEN_FALLBACKS"
)

FAST_CHAIN = _chain(
    "FAST_MODEL",
    "FAST_FALLBACKS"
)


# =============================================================
# Chroma
# =============================================================

CHROMA_DIR = "./chroma_db"

# سه collection جدا:
# متن (DOCX/PDF/TXT/HTML)
# ویدئو (MP4/YouTube)
# تصویر (PNG/JPG/…)

TEXT_COLLECTION = os.getenv(
    "TEXT_COLLECTION",
    "mahak_scripts"
)

VIDEO_COLLECTION = os.getenv(
    "VIDEO_COLLECTION",
    "mahak_videos"
)

# چانکهای حاصل از تحلیل تصویر (PNG/JPG/…) در collection جدا
# نگه داشته میشوند تا ایندکس مجدد متن، آنها را پاک نکند.
IMAGE_COLLECTION = os.getenv(
    "IMAGE_COLLECTION",
    "mahak_images"
)

# سازگاری با ingest.py قدیمی
COLLECTION = TEXT_COLLECTION


# =============================================================
# Video-RAG
# =============================================================

VIDEO_PROVIDER = os.getenv(
    "VIDEO_PROVIDER",
    "gemini"
)

GEMINI_API_KEY = os.getenv(
    "GEMINI_API_KEY",
    ""
)

GEMINI_VIDEO_MODEL = os.getenv(
    "GEMINI_VIDEO_MODEL",
    "gemini-2.5-flash"
)

QWEN_API_KEY = os.getenv("QWEN_API_KEY", "")
QWEN_BASE_URL = os.getenv(
    "QWEN_BASE_URL",
    "https://dashscope.aliyuncs.com/compatible-mode/v1",
)
QWEN_VIDEO_MODEL = os.getenv(
    "QWEN_VIDEO_MODEL",
    "qwen2.5-vl-72b-instruct",
)
QWEN_TIMEOUT = int(os.getenv("QWEN_TIMEOUT", "180"))

VIDEO_MODEL = (
    QWEN_VIDEO_MODEL
    if VIDEO_PROVIDER == "qwen"
    else GEMINI_VIDEO_MODEL
)


# =============================================================
# Image-RAG
# =============================================================

IMAGE_PROVIDER = (
    os.getenv("IMAGE_PROVIDER", "")
    .strip()
    or VIDEO_PROVIDER
)

QWEN_IMAGE_MODEL = os.getenv(
    "QWEN_IMAGE_MODEL",
    QWEN_VIDEO_MODEL,
)

GEMINI_IMAGE_MODEL = os.getenv(
    "GEMINI_IMAGE_MODEL",
    GEMINI_VIDEO_MODEL,
)

IMAGE_MODEL = (
    QWEN_IMAGE_MODEL
    if IMAGE_PROVIDER == "qwen"
    else GEMINI_IMAGE_MODEL
)

# زبان OCR — پیشفرض فارسی + انگلیسی
OCR_LANG = os.getenv("OCR_LANG", "fas+eng")

# سقف حجم تصویر (مگابایت)
IMAGE_MAX_FILE_SIZE_MB = int(
    os.getenv("IMAGE_MAX_FILE_SIZE_MB", "20")
)


# چانک معنایی ویدئو
VIDEO_CHUNK_DURATION = int(
    os.getenv(
        "VIDEO_CHUNK_DURATION",
        "100"
    )
)


VIDEO_MAX_FILE_SIZE_MB = int(
    os.getenv(
        "VIDEO_MAX_FILE_SIZE_MB",
        "2048"
    )
)


# حداکثر طول پنجره در هر درخواست
VIDEO_MAX_WINDOW_SECONDS = float(
    os.getenv(
        "VIDEO_MAX_WINDOW_SECONDS",
        "3600"
    )
)


VIDEO_ENABLE_VISION = (
    os.getenv(
        "VIDEO_ENABLE_VISION",
        "true"
    ).lower()
    == "true"
)


VIDEO_ENABLE_AUDIO = (
    os.getenv(
        "VIDEO_ENABLE_AUDIO",
        "true"
    ).lower()
    == "true"
)


VIDEO_ENABLE_CACHE = (
    os.getenv(
        "VIDEO_ENABLE_CACHE",
        "true"
    ).lower()
    == "true"
)


# =============================================================
# Timeout
# =============================================================

FAST_TIMEOUT = 30
GEN_TIMEOUT = 90


# =============================================================
# Cache
# =============================================================

_cache = {}
_emb_cache = None


# =============================================================
# LLM
# =============================================================

def _llm(model_id, temperature, timeout):
    key = (
        model_id,
        temperature,
        timeout
    )

    if key not in _cache:
        _cache[key] = ChatOpenAI(
            model=model_id,
            base_url=BASE_URL,
            api_key=API_KEY,
            temperature=temperature,
            timeout=timeout,
            max_retries=0,
        )

    return _cache[key]


# =============================================================
# فراخوانی مقاوم LLM
# =============================================================

def call(
    prompt,
    fast=False,
    temperature=0.0,
    log=None
):
    """
    یک فراخوانی مقاوم.

    اول مدل اصلی.
    در صورت 429 چند بار retry.
    سپس مدل جایگزین.
    اگر هیچ‌کدام جواب ندادند None برمی‌گرداند.
    """

    chain = (
        FAST_CHAIN
        if fast
        else GEN_CHAIN
    )

    timeout = (
        FAST_TIMEOUT
        if fast
        else GEN_TIMEOUT
    )

    for model_id in chain:

        wait = 4

        for attempt in range(3):

            try:

                out = (
                    _llm(
                        model_id,
                        temperature,
                        timeout
                    )
                    .invoke(prompt)
                    .content
                )

                out = (
                    out or ""
                ).strip()

                if not out:
                    raise ValueError(
                        "جواب خالی"
                    )

                if log is not None:
                    log.append(
                        f"مدل: {model_id}"
                    )

                return out

            except Exception as e:

                msg = str(e)

                if (
                    "429" in msg
                    or
                    "Too Many Requests" in msg
                ) and attempt < 2:

                    time.sleep(
                        wait
                        + random.uniform(
                            0,
                            1.5
                        )
                    )

                    wait *= 2

                    continue

                if log is not None:
                    log.append(
                        f"{model_id} نشد "
                        f"({type(e).__name__}) — بعدی"
                    )

                break

    if log is not None:
        log.append(
            "هیچ مدلی جواب نداد — مسیر امن"
        )

    return None


# =============================================================
# BGE HTTP Embeddings
# =============================================================

class BGEHttpEmbeddings(Embeddings):
    """
    اتصال Embedding پروژه اصلی به BGE Server.

    پروژه اصلی مدل BGE را اجرا نمی‌کند.

    به جای آن:

        Main Project
             ↓
        HTTP Request
             ↓
        BGE Server
             ↓
        /embed
             ↓
        Embedding
    """

    def __init__(
        self,
        base_url="http://127.0.0.1:8000",
        timeout=120
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def embed_documents(self, texts):
        """
        تبدیل چند متن به embedding.
        """

        texts = list(texts)

        if not texts:
            return []

        try:

            response = requests.post(
                f"{self.base_url}/embed",
                json={
                    "texts": texts
                },
                timeout=self.timeout,
            )

            response.raise_for_status()

            data = response.json()

            embeddings = data.get(
                "embeddings"
            )

            if not embeddings:
                raise RuntimeError(
                    "BGE Server پاسخ embedding خالی برگرداند."
                )

            if len(embeddings) != len(texts):
                raise RuntimeError(
                    "تعداد embeddingها با تعداد متن‌ها "
                    f"برابر نیست: "
                    f"{len(embeddings)} != {len(texts)}"
                )

            return embeddings

        except requests.RequestException as e:

            raise RuntimeError(
                "اتصال به BGE Server برقرار نشد. "
                f"آدرس سرور: {self.base_url} "
                f"| خطا: {e}"
            ) from e

    def embed_query(self, text):
        """
        تبدیل یک سؤال به embedding.
        """

        result = self.embed_documents(
            [text]
        )

        if not result:

            raise RuntimeError(
                "BGE Server برای query "
                "پاسخی نداد."
            )

        return result[0]


# =============================================================
# Embedding
# =============================================================

# پسوندهایی که فایلهای ورودی متنی/تصویری میتوانند داشته باشند.
# (ingest.py و app.py از همین فهرست واحد استفاده میکنند.)
DOCUMENT_EXTENSIONS = {
    ".docx",
    ".pdf",
    ".txt",
    ".md",
    ".html",
    ".htm",
}

IMAGE_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".bmp",
    ".gif",
    ".tif",
    ".tiff",
}

SUPPORTED_EXTENSIONS = (
    DOCUMENT_EXTENSIONS | IMAGE_EXTENSIONS
)

# فرمتهای ویدئو که providerها میپذیرند (mp4 توصیهشده)
VIDEO_EXTENSIONS = {
    ".mp4",
    ".mov",
    ".avi",
    ".mkv",
    ".webm",
}


def _local_embedder():
    """
    امبدینگ لوکال با langchain-huggingface.

    وقتی EMBED_BACKEND=local باشد یا BGE Server در دسترس نباشد،
    این مسیر استفاده میشود تا پروژه بدون سرویس جدا هم کار کند.
    """

    from langchain_huggingface import HuggingFaceEmbeddings

    return HuggingFaceEmbeddings(
        model_name=EMBED_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def embedder():
    """
    دریافت Embedding.

    دو حالت پشتیبانی میشود:

        EMBED_BACKEND=bge     → BGE Server روی http://127.0.0.1:8000
        EMBED_BACKEND=local   → مدل BAAI/bge-m3 لوکال (پیشفرض)

    اگر bge انتخاب شده باشد ولی سرور در دسترس نباشد،
    خودکار به امبدینگ لوکال برمیگردیم تا ingest کرش نکند.
    """

    global _emb_cache

    if _emb_cache is not None:
        return _emb_cache

    backend = os.getenv(
        "EMBED_BACKEND",
        "local"
    ).strip().lower()

    bge_url = os.getenv(
        "BGE_SERVER_URL",
        "http://127.0.0.1:8000"
    )

    bge_timeout = int(
        os.getenv(
            "BGE_TIMEOUT",
            "120"
        )
    )

    if backend in ("local", "huggingface", "hf"):

        _emb_cache = _local_embedder()
        return _emb_cache

    candidate = BGEHttpEmbeddings(
        base_url=bge_url,
        timeout=bge_timeout
    )

    try:

        candidate.embed_query("سلام")

        _emb_cache = candidate
        return _emb_cache

    except Exception as error:

        print(
            "[!] BGE Server در دسترس نیست "
            f"({type(error).__name__}) — "
            "به امبدینگ لوکال برمیگردیم."
        )

        _emb_cache = _local_embedder()
        return _emb_cache


# =============================================================
# Text Chroma Store
# =============================================================

def text_store():
    """
    استور Chroma اسناد متنی.

    شامل DOCX، PDF، TXT، MD و HTML. (تصاویر در image_store ذخیره می‌شوند.)
    """

    from langchain_chroma import Chroma

    return Chroma(
        collection_name=TEXT_COLLECTION,
        embedding_function=embedder(),
        persist_directory=CHROMA_DIR,
    )


# =============================================================
# Video Chroma Store
# =============================================================

def video_store():
    """
    استور Chroma چانکهای ویدئویی (MP4).

    Embedding از BGE Server دریافت میشود.
    متادیتای timestamp توسط Video-RAG مدیریت میشود.
    """

    from langchain_chroma import Chroma

    return Chroma(
        collection_name=VIDEO_COLLECTION,
        embedding_function=embedder(),
        persist_directory=CHROMA_DIR,
    )


# =============================================================
# Image Chroma Store
# =============================================================

def image_store():
    """
    استور Chroma چانکهای تصویری (PNG/JPG/…).

    خروجی تحلیل تصویر با Vision Model اینجا ذخیره میشود.
    """

    from langchain_chroma import Chroma

    return Chroma(
        collection_name=IMAGE_COLLECTION,
        embedding_function=embedder(),
        persist_directory=CHROMA_DIR,
    )