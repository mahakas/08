"""
واسط انتزاعی Provider درک ویدئو — ایجنت مهک

چرا abstraction؟ چون Gemini فقط provider فعلی است، نه کل سیستم.
فردا اگر Qwen3-VL یا مدل دیگری آمد، فقط یک کلاس جدید می‌سازیم
که همین واسط را پیاده کند و در فکتوری ثبتش کنیم — هیچ فایل
دیگری تغییر نمی‌کند.

هر provider دو کار دارد:
  ۱. understand:     فایل ویدئوی محلی (mp4) → سگمنت‌های زمان‌دار
  ۲. understand_url: لینک یوتیوب → سگمنت‌های زمان‌دار — بدون دانلود؛
     provider خودش لینک را می‌بیند (Gemini با file_uri).
"""

import os
import time
from typing import List, Dict, Optional

import config

# سقف تکرار در انتظار پردازش فایل روی سرویس
POLL_MAX_TRIES = 120
POLL_INTERVAL = 4.0

# حداکثر طول هر پنجره در تحلیل لینک یوتیوب (ثانیه). چون ویدئو یک‌جا
# به گوگل می‌رود و هر پنجره یک درخواست جدا است، پنجره‌های بلندتر از
# حالت فایل محلی به‌صرفه‌ترند. در .env: VIDEO_URL_WINDOW_SECONDS
URL_WINDOW_SECONDS = int(os.getenv("VIDEO_URL_WINDOW_SECONDS", "600"))


class VideoUnderstandingError(Exception):
    """خطای پایهٔ همهٔ providerها — ایجنت بر اساس پیامش تصمیم می‌گیرد."""

    def __init__(self, message, kind="unknown"):
        super().__init__(message)
        self.kind = kind   # fatal | rate_limit | timeout | corrupt | config


class SegmentResult(dict):
    """
    خروجی هر سگمنت:
    {
      "start_time": float, "end_time": float,
      "transcript": str, "visual_description": str,
      "code": str, "content_type": "audio|visual|mixed",
    }
    """


class VideoUnderstandingProvider:
    """کلاس پایهٔ provider درک ویدئو."""

    name = "base"

    def understand(
        self,
        path: str,
        windows: List[Dict],
        progress=None,
    ) -> List[SegmentResult]:
        """
        path: مسیر فایل mp4
        windows: لیست {"start": float, "end": float} — پنجره‌های زمانی
        progress: تابع callback (پیام، درصد ۰-۱۰۰) برای UI
        خروجی: لیست SegmentResult برای همهٔ پنجره‌ها
        """
        raise NotImplementedError

    # ------------------------------------------------------ لینک یوتیوب

    def understand_url(
        self,
        url: str,
        windows: List[Dict],
        progress=None,
    ) -> List[SegmentResult]:
        """
        لینک یوتیوب را مستقیم تحلیل می‌کند — بدون دانلود.
        پیش‌فرض: provider پشتیبانی نمی‌کند؛ کلاس‌های پشتیبان override می‌کنند.
        """
        raise VideoUnderstandingError(
            f"پرووایدر «{self.name}» تحلیل لینک مستقیم را پشتیبانی نمی‌کند. "
            "ویدئو را دانلود و فایلش را بده.",
            kind="config",
        )

    # ------------------------------------------------ ابزار مشترک

    @staticmethod
    def check_file(path: str):
        """اعتبارسنجی اولیهٔ فایل — همهٔ providerها از این استفاده می‌کنند."""
        if not os.path.exists(path):
            raise VideoUnderstandingError(
                f"فایل پیدا نشد: {path}", kind="fatal"
            )
        size_mb = os.path.getsize(path) / (1024 * 1024)
        limit = config.VIDEO_MAX_FILE_SIZE_MB
        if size_mb > limit:
            raise VideoUnderstandingError(
                f"فایل ویدئو {size_mb:.0f} مگابایت است؛ سقف مجاز {limit} مگابایت. "
                "با VIDEO_MAX_FILE_SIZE_MB در .env می‌توانی این را کم/زیاد کنی.",
                kind="fatal",
            )
        if not path.lower().endswith(tuple(sorted(config.VIDEO_EXTENSIONS))):
            raise VideoUnderstandingError(
                "فرمت ویدئو پشتیبانی نمی‌شود. mp4 توصیه می‌شود.", kind="fatal"
            )
        return size_mb

    @staticmethod
    def backoff(attempt: int, base: float = 4.0):
        """عقب‌نشینی نمایی — الگوی همان config.call."""
        wait = base * (2 ** attempt)
        time.sleep(wait + (time.time() % 1))
        return wait


def get_provider(name: Optional[str] = None) -> VideoUnderstandingProvider:
    """
    فکتوری provider. اسم از .env می‌آید (VIDEO_PROVIDER).
    provider جدید = ساخت کلاس + یک خط در این فکتوری.
    """
    name = (name or config.VIDEO_PROVIDER or "gemini").lower().strip()

    if name == "gemini":
        # import دیرهنگام: بدون GEMINI_API_KEY پروژهٔ متنی نمی‌شکند
        from gemini_video import GeminiVideoProvider
        return GeminiVideoProvider()

    if name == "qwen":
        from qwen_video import QwenVideoProvider
        return QwenVideoProvider()

    # محل ثبت providerهای آینده:
    # if name == "qwen":  from qwen_video import QwenVideoProvider; ...

    raise VideoUnderstandingError(
        f"provider ویدئوی «{name}» شناخته‌شده نیست. "
        "گزینه‌های فعلی: gemini, qwen",
        kind="config",
    )
