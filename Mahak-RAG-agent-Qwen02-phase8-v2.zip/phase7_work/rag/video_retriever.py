from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import config


@dataclass
class VideoRetrievalResult:
    text: str
    metadata: Dict[str, Any]
    score: Optional[float] = None


class VideoRetriever:
    def __init__(self):
        self.store = None

    def connect(self):
        if self.store is None:
            self.store = config.video_store()
        return self.store

    def search(self, query: str, top_k: int = 5) -> List[VideoRetrievalResult]:
        store = self.connect()

        try:
            results = store.similarity_search_with_score(
                query,
                k=top_k
            )

            output = []

            for doc, score in results:
                output.append(
                    VideoRetrievalResult(
                        text=doc.page_content,
                        metadata=doc.metadata or {},
                        score=float(score)
                    )
                )

            return output

        except (AttributeError, NotImplementedError):
            docs = store.similarity_search(
                query,
                k=top_k
            )

            return [
                VideoRetrievalResult(
                    text=doc.page_content,
                    metadata=doc.metadata or {},
                    score=None
                )
                for doc in docs
            ]

    def search_text(self, query: str, top_k: int = 5) -> List[str]:
        results = self.search(query, top_k)

        return [
            result.text
            for result in results
        ]

    def format_results(self, results: List[VideoRetrievalResult]) -> str:
        if not results:
            return "No relevant video results found."

        parts = []

        for index, result in enumerate(results, start=1):
            metadata = result.metadata

            title = metadata.get(
                "title",
                metadata.get("video_title", "Unknown video")
            )

            start_time = metadata.get(
                "start_time",
                metadata.get("start", "?")
            )

            end_time = metadata.get(
                "end_time",
                metadata.get("end", "?")
            )

            url = metadata.get(
                "url",
                metadata.get("source", "")
            )

            block = (
                f"Result {index}\n"
                f"Title: {title}\n"
                f"Time: {start_time} - {end_time}\n"
                f"Text: {result.text}"
            )

            if url:
                block += f"\nURL: {url}"

            if result.score is not None:
                block += f"\nScore: {result.score:.4f}"

            parts.append(block)

        return "\n\n".join(parts)


def create_video_retriever() -> VideoRetriever:
    return VideoRetriever()


if __name__ == "__main__":
    print("VIDEO RETRIEVER TEST")
    print("-" * 40)

    retriever = VideoRetriever()

    try:
        retriever.connect()

        print("Video vector store connected successfully.")

        results = retriever.search(
            "test video",
            top_k=3
        )

        print(f"Results found: {len(results)}")

        if results:
            print()
            print(retriever.format_results(results))

        print()
        print("Video retriever module is working correctly.")

    except Exception as e:
        print()
        print("Video retriever test failed:")
        print(type(e).__name__, str(e))