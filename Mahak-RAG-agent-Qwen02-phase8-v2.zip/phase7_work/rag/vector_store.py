from __future__ import annotations

from typing import Any, Dict, List, Optional

from config import text_store


class VectorStoreManager:
    def __init__(self):
        self.store = None
        self.connected = False

    def connect(self) -> bool:
        try:
            self.store = text_store()
            self.connected = True
            return True
        except Exception as exc:
            print(f"Vector store connection error: {exc}")
            self.store = None
            self.connected = False
            return False

    def search(
        self,
        query: str,
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:

        if not query or not query.strip():
            return []

        if self.store is None:
            if not self.connect():
                return []

        try:
            documents = self.store.similarity_search(
                query,
                k=top_k,
            )
        except Exception as exc:
            print(f"Vector search error: {exc}")
            return []

        results = []

        for doc in documents:
            results.append(
                {
                    "text": doc.page_content,
                    "metadata": doc.metadata or {},
                }
            )

        return results

    def search_text(
        self,
        query: str,
        top_k: int = 5,
    ) -> List[str]:

        results = self.search(
            query=query,
            top_k=top_k,
        )

        return [
            item["text"]
            for item in results
        ]


def create_vector_store() -> VectorStoreManager:
    return VectorStoreManager()


if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI VECTOR STORE TEST")
    print("=" * 60)

    manager = VectorStoreManager()

    print()
    print("Connecting to Chroma...")

    connected = manager.connect()

    print("Connected:", connected)

    if connected:
        results = manager.search(
            "test",
            top_k=3,
        )

        print("Search results:", len(results))

        for index, result in enumerate(results, start=1):
            print()
            print(f"Result {index}:")
            print(result["text"][:300])

    print()
    print("Vector store module test finished.")