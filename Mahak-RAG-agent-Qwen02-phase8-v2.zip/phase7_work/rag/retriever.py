from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class RetrievalResult:
    text: str
    metadata: Dict[str, Any]
    score: Optional[float] = None


class RAGRetriever:

    def __init__(self, collection=None):
        self.collection = collection

    def set_collection(self, collection) -> None:
        self.collection = collection

    def search(
        self,
        query: str,
        top_k: int = 5,
    ) -> List[RetrievalResult]:

        if not query or not query.strip():
            return []

        if self.collection is None:
            return []

        try:
            # LangChain Chroma
            if hasattr(self.collection, "similarity_search_with_score"):
                results = self.collection.similarity_search_with_score(
                    query,
                    k=top_k,
                )

                output = []

                for document, score in results:
                    output.append(
                        RetrievalResult(
                            text=document.page_content,
                            metadata=document.metadata or {},
                            score=float(score),
                        )
                    )

                return output

            # LangChain Chroma بدون score
            if hasattr(self.collection, "similarity_search"):
                documents = self.collection.similarity_search(
                    query,
                    k=top_k,
                )

                return [
                    RetrievalResult(
                        text=document.page_content,
                        metadata=document.metadata or {},
                        score=None,
                    )
                    for document in documents
                ]

            # Chroma Collection خام
            if hasattr(self.collection, "query"):
                results = self.collection.query(
                    query_texts=[query],
                    n_results=top_k,
                )

                documents = results.get("documents", [[]])
                metadatas = results.get("metadatas", [[]])
                distances = results.get("distances", [[]])

                documents = documents[0] if documents else []
                metadatas = metadatas[0] if metadatas else []
                distances = distances[0] if distances else []

                output = []

                for index, document in enumerate(documents):

                    metadata = {}

                    if index < len(metadatas):
                        metadata = metadatas[index] or {}

                    score = None

                    if index < len(distances):
                        score = distances[index]

                    output.append(
                        RetrievalResult(
                            text=document,
                            metadata=metadata,
                            score=score,
                        )
                    )

                return output

        except Exception as exc:
            print(f"RAG SEARCH ERROR: {exc}")
            return []

        return []

    def search_text(
        self,
        query: str,
        top_k: int = 5,
    ) -> List[str]:

        results = self.search(
            query=query,
            top_k=top_k,
        )

        return [
            result.text
            for result in results
        ]

    def retrieve(
        self,
        query: str,
        top_k: int = 5,
    ) -> List[RetrievalResult]:

        return self.search(
            query=query,
            top_k=top_k,
        )


def create_retriever(collection=None) -> RAGRetriever:
    return RAGRetriever(collection=collection)


if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI RAG RETRIEVER TEST")
    print("=" * 60)

    retriever = RAGRetriever()

    print()
    print("Retriever created successfully.")

    print(
        "Collection connected:",
        retriever.collection is not None,
    )

    results = retriever.search("test query")

    print(
        "Search results:",
        len(results),
    )

    print()
    print("RAG retriever module is working correctly.")