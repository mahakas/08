"""
GENERAL AI - FULL INTEGRATION TEST
"""

import sys
import traceback
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent

if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))


def print_header(title):
    print()
    print("=" * 70)
    print(title)
    print("=" * 70)


def print_result(name, success, details=""):
    status = "PASS" if success else "FAIL"
    print(f"[{status}] {name}")

    if details:
        print(f"      {details}")


def test_imports():
    print_header("1. IMPORT TEST")

    try:
        from core.agent import GeneralAI
        from core.sources import SourceManager
        from core.context import ContextManager
        from core.memory import MemoryManager
        from core.router import RequestRouter
        from core.tools import create_default_registry
        from core.error_handler import ErrorHandler
        from security.guard import SecurityGuard

        print_result(
            "Core imports",
            True,
            "All required modules imported successfully."
        )

        return True

    except Exception as e:
        print_result("Core imports", False, str(e))
        traceback.print_exc()
        return False


def test_core_components():
    print_header("2. CORE COMPONENT TEST")

    try:
        from core.context import ContextManager
        from core.memory import MemoryManager
        from core.router import RequestRouter
        from core.tools import create_default_registry
        from core.error_handler import ErrorHandler
        from security.guard import SecurityGuard
        from core.sources import SourceManager

        context = ContextManager()
        memory = MemoryManager()
        router = RequestRouter()
        tools = create_default_registry()
        error_handler = ErrorHandler()
        security = SecurityGuard()
        sources = SourceManager()

        print_result("Context Manager", context is not None)
        print_result("Memory Manager", memory is not None)
        print_result("Request Router", router is not None)
        print_result("Tool Registry", tools is not None)
        print_result("Error Handler", error_handler is not None)
        print_result("Security Guard", security is not None)
        print_result("Source Manager", sources is not None)

        return True

    except Exception as e:
        print_result("Core components", False, str(e))
        traceback.print_exc()
        return False


def test_router():
    print_header("3. ROUTER TEST")

    try:
        from core.router import RequestRouter

        router = RequestRouter()

        tests = {
            "Hello": "chat",
            "Calculate 25 * 40": "tool",
            "Search my PDF": "rag",
            "What is the latest technology news?": "web",
            "Analyze this video": "video",
        }

        all_passed = True

        for message, expected in tests.items():

            result = router.classify(message)

            actual = (
                result.route
                if hasattr(result, "route")
                else result
            )

            passed = actual == expected

            print_result(
                f"Route: {message}",
                passed,
                f"Expected={expected}, Actual={actual}"
            )

            if not passed:
                all_passed = False

        return all_passed

    except Exception as e:
        print_result("Router test", False, str(e))
        traceback.print_exc()
        return False


def test_tools():
    print_header("4. TOOLS TEST")

    try:
        from core.tools import create_default_registry

        registry = create_default_registry()

        result = registry.execute(
            "calculate",
            expression="25 * 40"
        )

        calculator_passed = (
            result.success and
            result.result == 1000
        )

        print_result(
            "Calculator",
            calculator_passed,
            f"Result={result.result}"
        )

        word_result = registry.execute(
            "count_words",
            text="Hello this is a general AI test"
        )

        print_result(
            "Word Counter",
            word_result.success,
            f"Result={word_result.result}"
        )

        sqrt_result = registry.execute(
            "square_root",
            number=144
        )

        sqrt_passed = (
            sqrt_result.success and
            sqrt_result.result == 12
        )

        print_result(
            "Square Root",
            sqrt_passed,
            f"Result={sqrt_result.result}"
        )

        return (
            calculator_passed and
            word_result.success and
            sqrt_passed
        )

    except Exception as e:
        print_result("Tools test", False, str(e))
        traceback.print_exc()
        return False


def test_security():
    print_header("5. SECURITY TEST")

    try:
        from security.guard import SecurityGuard

        guard = SecurityGuard()

        safe_tests = [
            "Hello",
            "Calculate 25 * 40",
            "Write a story",
        ]

        dangerous_tests = [
            "rm -rf /",
            "format c:",
            "del /f /s /q",
        ]

        all_passed = True

        for message in safe_tests:

            result = guard.validate(message)

            passed = result.allowed

            print_result(
                f"Safe input: {message}",
                passed
            )

            if not passed:
                all_passed = False

        for message in dangerous_tests:

            result = guard.validate(message)

            passed = not result.allowed

            print_result(
                f"Dangerous input blocked: {message}",
                passed
            )

            if not passed:
                all_passed = False

        return all_passed

    except Exception as e:
        print_result("Security test", False, str(e))
        traceback.print_exc()
        return False


def test_context():
    print_header("6. CONTEXT TEST")

    try:
        from core.context import ContextManager

        manager = ContextManager()

        session_id = "integration-test"

        manager.add_user_message(
            session_id,
            "My name is Ali."
        )

        manager.add_assistant_message(
            session_id,
            "Hello Ali."
        )

        manager.add_user_message(
            session_id,
            "I like Python."
        )

        conversation = manager.get(session_id)

        message_count = len(conversation.messages)

        text = conversation.as_text()

        passed = (
            message_count == 3
            and "Ali" in text
            and "Python" in text
        )

        print_result(
            "Conversation context",
            passed,
            f"Messages={message_count}"
        )

        return passed

    except Exception as e:
        print_result("Context test", False, str(e))
        traceback.print_exc()
        return False


def test_sources():
    print_header("7. UNIFIED SOURCES TEST")

    try:
        from core.sources import SourceManager, Source

        manager = SourceManager()

        manager.add(
            Source(
                source_type="rag",
                title="test-document.pdf",
                text="RAG test document",
                file_name="test-document.pdf",
                metadata={
                    "source": "test.pdf"
                }
            )
        )

        manager.add(
            Source(
                source_type="web",
                title="Technology News",
                text="Technology news test",
                url="https://example.com"
            )
        )

        manager.add(
            Source(
                source_type="video",
                title="AI Course",
                text="Video test",
                file_name="course.mp4",
                video_id="video-001",
                start=120,
                end=180
            )
        )

        sources = manager.to_list()

        count_passed = len(sources) == 3

        print_result(
            "Unified source collection",
            count_passed,
            f"Sources={len(sources)}"
        )

        type_values = [
            source.get("type")
            for source in sources
        ]

        types_passed = (
            "rag" in type_values and
            "web" in type_values and
            "video" in type_values
        )

        print_result(
            "Source types",
            types_passed,
            f"Types={type_values}"
        )

        return count_passed and types_passed

    except Exception as e:
        print_result("Sources test", False, str(e))
        traceback.print_exc()
        return False


def test_agent():
    print_header("8. GENERAL AI AGENT TEST")

    try:
        from core.agent import GeneralAI

        ai = GeneralAI()

        test_messages = [
            "Hello",
            "Calculate 25 * 40",
            "Search my PDF file",
            "What is the latest technology news?",
            "Analyze this video",
            "rm -rf /",
        ]

        all_passed = True

        for message in test_messages:

            print()
            print(f"User: {message}")

            try:
                result = ai.ask(message)

                if isinstance(result, dict):

                    print(
                        f"Route: {result.get('route')}"
                    )

                    print(
                        f"Sources: "
                        f"{len(result.get('sources', []))}"
                    )

                    print(
                        f"Blocked: "
                        f"{result.get('blocked', False)}"
                    )

                    print(
                        f"Answer: "
                        f"{str(result.get('answer', ''))[:200]}"
                    )

                else:
                    print(
                        f"Result: {result}"
                    )

            except Exception as e:

                print(
                    f"Agent error: {e}"
                )

                traceback.print_exc()
                all_passed = False

        print()

        print_result(
            "General AI Agent",
            all_passed
        )

        return all_passed

    except Exception as e:
        print_result(
            "General AI Agent",
            False,
            str(e)
        )

        traceback.print_exc()
        return False


def main():

    print_header(
        "GENERAL AI - FULL INTEGRATION TEST"
    )

    results = []

    results.append(
        ("Imports", test_imports())
    )

    results.append(
        ("Core Components", test_core_components())
    )

    results.append(
        ("Router", test_router())
    )

    results.append(
        ("Tools", test_tools())
    )

    results.append(
        ("Security", test_security())
    )

    results.append(
        ("Context", test_context())
    )

    results.append(
        ("Unified Sources", test_sources())
    )

    results.append(
        ("Agent", test_agent())
    )

    print_header(
        "FINAL TEST RESULT"
    )

    passed = 0
    failed = 0

    for name, result in results:

        print_result(
            name,
            result
        )

        if result:
            passed += 1
        else:
            failed += 1

    print()

    print(
        f"Passed: {passed}"
    )

    print(
        f"Failed: {failed}"
    )

    print()

    if failed == 0:

        print("=" * 70)
        print("ALL INTEGRATION TESTS PASSED")
        print("=" * 70)

        print()
        print(
            "GENERAL AI CORE IS READY FOR THE NEXT STAGE."
        )

    else:

        print("=" * 70)
        print("SOME TESTS FAILED")
        print("=" * 70)

        print()
        print(
            "Fix the failed component before continuing."
        )


if __name__ == "__main__":
    main()