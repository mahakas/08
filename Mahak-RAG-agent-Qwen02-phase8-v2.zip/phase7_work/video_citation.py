"""
Video Citation System

این ماژول Citationهای ویدئویی را فقط از metadata واقعی
بازیابی‌شده می‌سازد.

LLM اجازه ندارد:
- timestamp اختراع کند
- URL اختراع کند
- نام فایل اختراع کند
- منبعی خارج از منابع بازیابی‌شده معرفی کند
"""

import re
from typing import Any, Dict, List


SOURCE_LABEL_RE = re.compile(
    r"منبع\s*[:：]\s*(.+)",
    re.IGNORECASE,
)

MAX_VIDEO_SOURCES = 2
MAX_DOC_SOURCES = 2


def _norm(value: str) -> str:
    """Normalize text for safe source-title comparison."""

    if not value:
        return ""

    bad = (
        "«»\"'?؟|!()[]—-–_.,:؛\u200c"
    )

    for char in bad:
        value = value.replace(char, " ")

    return " ".join(
        value.lower().split()
    )


def _seconds_to_ts(seconds: Any) -> str:
    """
    Convert seconds to timestamp.

    Examples:
        1040.5 -> 17:20
        3725   -> 1:02:05
    """

    try:
        seconds = int(
            round(float(seconds))
        )
    except (TypeError, ValueError):
        return ""

    hours, remainder = divmod(
        seconds,
        3600,
    )

    minutes, secs = divmod(
        remainder,
        60,
    )

    if hours:
        return (
            f"{hours:d}:"
            f"{minutes:02d}:"
            f"{secs:02d}"
        )

    return (
        f"{minutes:02d}:"
        f"{secs:02d}"
    )


def _extract_metadata(item: Dict[str, Any]) -> Dict[str, Any]:
    """
    Supports both metadata structures used in the project.

    Structure 1:
        {
            "meta": {...}
        }

    Structure 2:
        {
            "metadata": {...}
        }

    Structure 3:
        {
            "type": "video",
            "title": "...",
            ...
        }
    """

    if not isinstance(item, dict):
        return {}

    meta = item.get("meta")

    if isinstance(meta, dict):
        return meta

    meta = item.get("metadata")

    if isinstance(meta, dict):
        return meta

    return item


def _is_video_metadata(meta: Dict[str, Any]) -> bool:
    """Detect whether metadata belongs to a video source."""

    source_type = str(
        meta.get(
            "source_type",
            meta.get(
                "type",
                ""
            ),
        )
    ).lower()

    if source_type == "video":
        return True

    if source_type in ("image", "document", "doc", "text"):
        return False

    video_keys = {
        "video_id",
        "video_title",
        "start_time",
        "end_time",
    }

    return bool(
        video_keys.intersection(
            meta.keys()
        )
    )


def build_video_citation(
    meta: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Build a structured citation from real video metadata.

    No missing value is invented.
    """

    if not isinstance(meta, dict):
        meta = {}

    start = meta.get(
        "start_time",
        meta.get("start"),
    )

    end = meta.get(
        "end_time",
        meta.get("end"),
    )

    title = (
        meta.get("title")
        or meta.get("video_title")
        or meta.get("file_name")
        or meta.get("filename")
        or "ویدئو"
    )

    url = (
        meta.get("url")
        or ""
    )

    file_name = (
        meta.get("file_name")
        or meta.get("filename")
        or ""
    )

    video_id = (
        meta.get("video_id")
        or ""
    )

    has_time = (
        start is not None
        and end is not None
    )

    citation = {
        "type": "video",
        "title": title,
        "file_name": file_name,
        "video_id": video_id,
        "start": (
            float(start)
            if has_time
            else None
        ),
        "end": (
            float(end)
            if has_time
            else None
        ),
        "timestamp": (
            f"{_seconds_to_ts(start)} – "
            f"{_seconds_to_ts(end)}"
            if has_time
            else ""
        ),
        "url": url,
        "content_type": meta.get(
            "content_type",
            "",
        ),
    }

    # -------------------------------------------------
    # YouTube timestamp URL
    # -------------------------------------------------

    if url and has_time:

        match = re.search(
            r"(?:v=|youtu\.be/)([\w-]{6,})",
            url,
        )

        if match:

            video_id_from_url = match.group(1)

            citation["url"] = (
                "https://www.youtube.com/watch?"
                f"v={video_id_from_url}"
                f"&t={int(float(start))}s"
            )

    return citation


def build_doc_citation(
    meta: Dict[str, Any],
) -> Dict[str, Any]:
    """Build a structured document citation."""

    if not isinstance(meta, dict):
        meta = {}

    kind = str(meta.get("source_type", "") or "").lower()

    if kind == "image":
        default_label = "تصویر"
        citation_type = "image"
    else:
        default_label = "سند"
        citation_type = "doc"

    return {
        "type": citation_type,
        "title": (
            meta.get("title")
            or meta.get("file")
            or meta.get("file_name")
            or default_label
        ),
        "url": meta.get(
            "url",
            "",
        ),
        "chunk": meta.get(
            "chunk",
            0,
        ),
    }


def collect_sources(
    retrieved_items: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Convert retrieved results into unique structured citations.

    Works with:
    - VideoRetriever results
    - GeneralAI sources
    - legacy RAG source format
    """

    sources = []
    seen = set()

    for item in retrieved_items:

        meta = _extract_metadata(
            item
        )

        if not meta:
            continue

        if _is_video_metadata(meta):

            citation = build_video_citation(
                meta
            )

            key = (
                "video",
                citation.get(
                    "video_id",
                    "",
                ),
                citation.get(
                    "start",
                    None,
                ),
                citation.get(
                    "end",
                    None,
                ),
                citation.get(
                    "title",
                    "",
                ),
            )

        else:

            citation = build_doc_citation(
                meta
            )

            key = (
                citation.get("type", "doc"),
                citation.get(
                    "title",
                    "",
                ),
                citation.get(
                    "chunk",
                    0,
                ),
            )

        if key in seen:
            continue

        seen.add(key)
        sources.append(
            citation
        )

    videos = [
        source
        for source in sources
        if source.get("type") == "video"
    ][:MAX_VIDEO_SOURCES]

    docs = [
        source
        for source in sources
        if source.get("type") in ("doc", "image", "document")
    ][:MAX_DOC_SOURCES]

    return videos + docs


def resolve_source_labels(
    answer: str,
    retrieved_items: List[Dict[str, Any]],
) -> str:
    """
    Validate source labels written by the model.

    Any source title not present in retrieved metadata
    is removed.
    """

    if not answer:
        return answer

    valid_titles = set()

    for item in retrieved_items:

        meta = _extract_metadata(
            item
        )

        title = (
            meta.get("title")
            or meta.get("video_title")
            or meta.get("file_name")
        )

        if title:
            valid_titles.add(
                _norm(str(title))
            )

    lines = answer.splitlines()

    output = []
    changed = False

    for line in lines:

        match = SOURCE_LABEL_RE.search(
            line
        )

        if not match:

            output.append(line)
            continue

        claimed = _norm(
            match.group(1)
        )

        valid = any(
            claimed
            and (
                claimed in title
                or title in claimed
            )
            for title in valid_titles
        )

        if valid:

            output.append(line)

        else:

            changed = True

    if changed:
        return "\n".join(output)

    return answer


def format_sources_block(
    sources: List[Dict[str, Any]],
) -> str:
    """
    Format structured citations for CLI/UI display.
    """

    if not sources:
        return ""

    lines = []

    for source in sources:

        source_type = source.get(
            "type"
        )

        if source_type == "video":

            title = source.get(
                "title",
                "ویدئو",
            )

            line = f"🎥 {title}"

            timestamp = source.get(
                "timestamp",
                "",
            )

            if timestamp:

                line += (
                    f" — ⏱ {timestamp}"
                )

            lines.append(line)

            url = source.get(
                "url",
                "",
            )

            if url:

                lines.append(
                    f"   ▶ {url}"
                )

            else:

                file_name = source.get(
                    "file_name",
                    "",
                )

                if file_name:

                    lines.append(
                        f"   📁 {file_name}"
                        " (فایل محلی)"
                    )

        elif source_type == "image":

            title = source.get(
                "title",
                "تصویر",
            )

            lines.append(
                f"🖼 {title}"
            )

        else:

            title = source.get(
                "title",
                "سند",
            )

            lines.append(
                f"📄 {title}"
            )

    return "\n".join(lines)


def build_citations_from_agent_sources(
    agent_sources: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Convert GeneralAI.state.sources directly into
    safe citations.

    This is the main bridge between GeneralAI
    and the citation system.
    """

    normalized = []

    for source in agent_sources:

        if not isinstance(source, dict):
            continue

        if source.get("type") == "video":

            metadata = {
                "source_type": "video",
                "title": source.get(
                    "title",
                    "",
                ),
                "video_id": source.get(
                    "video_id",
                    "",
                ),
                "file_name": source.get(
                    "file_name",
                    "",
                ),
                "start_time": (
                    source.get("start_time")
                    if source.get("start_time") is not None
                    else source.get("start")
                ),
                "end_time": (
                    source.get("end_time")
                    if source.get("end_time") is not None
                    else source.get("end")
                ),
                "url": source.get(
                    "url",
                    "",
                ),
                "content_type": source.get(
                    "content_type",
                    "",
                ),
            }

            normalized.append(
                {
                    "meta": metadata
                }
            )

        else:

            normalized.append(
                {
                    "meta": source
                }
            )

    return collect_sources(
        normalized
    )


# ---------------------------------------------------------
# Standalone test
# ---------------------------------------------------------

if __name__ == "__main__":

    print("=" * 60)
    print("VIDEO CITATION TEST")
    print("=" * 60)

    test_sources = [
        {
            "type": "video",
            "title": "آموزش هوش مصنوعی",
            "video_id": "test-video-001",
            "file_name": "ai-course.mp4",
            "start_time": 1040.5,
            "end_time": 1105.2,
            "url": "",
            "content_type": "lecture",
        }
    ]

    citations = build_citations_from_agent_sources(
        test_sources
    )

    print()
    print("Structured citations:")
    print(citations)

    print()
    print("Formatted:")
    print(
        format_sources_block(
            citations
        )
    )

    print()
    print("Citation system is working correctly.")

    print("=" * 60)