"""
واسط انتزاعی Provider درک تصویر — ایجنت مهک

تصاویر (PNG/JPG/WEBP/…) با یک مدل Vision تحلیل میشوند و خروجی
متنی آنها وارد Chroma میشود؛ دقیقا مثل ویدئو و DOCX.

سه مسیر پشتیبانی میشود:

    ۱. qwen   → endpoint سازگار با OpenAI با ورودی image_url
    ۲. gemini → Google Gemini (inline bytes)
    ۳. ocr    → فقط متن تصویر با pytesseract (بدون مدل Vision)

انتخاب با IMAGE_PROVIDER در .env است. اگر مدل Vision در دسترس
نباشد، خودکار به OCR برمیگردیم تا ingest کرش نکند.
"""

import base64
import json
import os
from pathlib import Path

import requests

import config


class ImageUnderstandingError(Exception):
    """خطای پایهٔ درک تصویر."""

    def __init__(self, message, kind="unknown"):
        super().__init__(message)
        self.kind = kind   # fatal | rate_limit | timeout | config


# =============================================================
# کلاس پایه
# =============================================================

class ImageUnderstandingProvider:
    """کلاس پایهٔ provider درک تصویر."""

    name = "base"

    def describe(self, path: str, hint: str = "") -> dict:
        """
        یک تصویر را تحلیل میکند.

        خروجی:
            {
                "text": str,        # متن قابل embed و جستوجو
                "transcript": str,  # متن داخل تصویر (OCR/خواندهشده)
                "visual": str,      # توصیف تصویری
                "kind": str,        # photo | screenshot | diagram | scan | other
            }
        """
        raise NotImplementedError

    @staticmethod
    def check_file(path: str):
        """اعتبارسنجی فایل تصویر."""
        if not os.path.exists(path):
            raise ImageUnderstandingError(
                f"تصویر پیدا نشد: {path}", kind="fatal"
            )
        if not path.lower().endswith(tuple(config.IMAGE_EXTENSIONS)):
            raise ImageUnderstandingError(
                "فرمت تصویر پشتیبانی نمیشود. "
                "png/jpg/jpeg/webp/bmp/gif/tiff مجاز است.",
                kind="fatal",
            )
        size_mb = os.path.getsize(path) / (1024 * 1024)
        limit = config.IMAGE_MAX_FILE_SIZE_MB
        if size_mb > limit:
            raise ImageUnderstandingError(
                f"حجم تصویر {size_mb:.1f} MB بیش از سقف {limit} MB.",
                kind="fatal",
            )
        return size_mb

    @staticmethod
    def _mime(path: str) -> str:
        suffix = Path(path).suffix.lower()
        return {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".webp": "image/webp",
            ".bmp": "image/bmp",
            ".gif": "image/gif",
            ".tif": "image/tiff",
            ".tiff": "image/tiff",
        }.get(suffix, "image/png")

    @staticmethod
    def _prompt(hint: str = "") -> str:
        extra = f"\nاطلاعات اضافه از نام فایل: {hint}" if hint else ""
        return f"""این تصویر را تحلیل کن و خروجی را فقط به شکل JSON معتبر
و بدون Markdown برگردان:{extra}
{{
  "transcript": "هر متن فارسی/انگلیسی داخل تصویر، دقیق و کامل",
  "visual_description": "توضیح دقیق محتوای تصویر: نمودار، اسلاید، اسکرینشات، عکس و جزئیات مهم",
  "kind": "photo یا screenshot یا diagram یا scan یا other"
}}"""


# =============================================================
# Qwen (OpenAI-compatible)
# =============================================================

class QwenImageProvider(ImageUnderstandingProvider):
    """تحلیل تصویر با endpoint سازگار OpenAI (Qwen-VL)."""

    name = "qwen"

    def __init__(self):

        if not config.QWEN_API_KEY:
            raise ImageUnderstandingError(
                "QWEN_API_KEY در فایل .env پیدا نشد.", kind="config"
            )

        endpoint = config.QWEN_BASE_URL or ""
        if not endpoint:
            raise ImageUnderstandingError(
                "QWEN_BASE_URL تنظیم نشده است.", kind="config"
            )

        self._endpoint = endpoint.rstrip("/") + "/chat/completions"
        self._model = config.QWEN_IMAGE_MODEL

    def describe(self, path: str, hint: str = "") -> dict:

        self.check_file(path)

        encoded = base64.b64encode(Path(path).read_bytes()).decode("ascii")
        data_url = f"data:{self._mime(path)};base64,{encoded}"

        payload = {
            "model": self._model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": self._prompt(hint)},
                        {"type": "image_url", "image_url": {"url": data_url}},
                    ],
                }
            ],
            "temperature": 0.1,
            "max_tokens": 2048,
        }

        try:
            response = requests.post(
                self._endpoint,
                headers={
                    "Authorization": f"Bearer {config.QWEN_API_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=config.QWEN_TIMEOUT,
            )

            if response.status_code == 429:
                raise ImageUnderstandingError(
                    "سهمیه یا نرخ درخواست Qwen تمام شده است.",
                    kind="rate_limit",
                )

            response.raise_for_status()
            content = response.json()["choices"][0]["message"]["content"]

        except ImageUnderstandingError:
            raise

        except (requests.RequestException, KeyError, IndexError, TypeError, ValueError) as error:
            raise ImageUnderstandingError(
                f"درخواست Qwen برای تصویر ناموفق بود: "
                f"{type(error).__name__}: {error}",
                kind="timeout",
            ) from error

        return _parse_payload(content)


# =============================================================
# Gemini
# =============================================================

class GeminiImageProvider(ImageUnderstandingProvider):
    """تحلیل تصویر با Google Gemini."""

    name = "gemini"

    def __init__(self):

        if not config.GEMINI_API_KEY:
            raise ImageUnderstandingError(
                "GEMINI_API_KEY در فایل .env پیدا نشد.", kind="config"
            )

        try:
            from google import genai
        except ImportError:
            raise ImageUnderstandingError(
                "کتابخانهٔ google-genai نصب نیست. "
                "اجرا کن: pip install google-genai",
                kind="config",
            )

        self._client = genai.Client(api_key=config.GEMINI_API_KEY)
        self._model = config.GEMINI_IMAGE_MODEL

    def describe(self, path: str, hint: str = "") -> dict:

        self.check_file(path)

        from google.genai import types

        part = types.Part.from_bytes(
            data=Path(path).read_bytes(),
            mime_type=self._mime(path),
        )

        try:
            response = self._client.models.generate_content(
                model=self._model,
                contents=[self._prompt(hint), part],
                config={"temperature": 0.1},
            )
        except Exception as error:
            message = str(error)
            if "429" in message or "RESOURCE_EXHAUSTED" in message:
                raise ImageUnderstandingError(
                    "سهمیهٔ Gemini تمام شده است.", kind="rate_limit"
                )
            raise ImageUnderstandingError(
                f"تحلیل تصویر با Gemini ناموفق بود: "
                f"{type(error).__name__}: {error}",
                kind="timeout",
            ) from error

        return _parse_payload(getattr(response, "text", "") or "")


# =============================================================
# OCR (بدون مدل Vision)
# =============================================================

class OcrImageProvider(ImageUnderstandingProvider):
    """استخراج متن تصویر با pytesseract — بدون مدل Vision."""

    name = "ocr"

    def __init__(self):
        try:
            import pytesseract  # noqa: F401
        except ImportError:
            raise ImageUnderstandingError(
                "برای مسیر OCR این را نصب کن: "
                "pip install pytesseract  (به علاوهٔ موتور Tesseract)",
                kind="config",
            )

    def describe(self, path: str, hint: str = "") -> dict:

        self.check_file(path)

        import pytesseract
        from PIL import Image

        try:
            text = pytesseract.image_to_string(
                Image.open(path),
                lang=config.OCR_LANG,
            )
        except Exception as error:
            raise ImageUnderstandingError(
                f"OCR تصویر ناموفق بود: {type(error).__name__}: {error}",
                kind="fatal",
            ) from error

        text = (text or "").strip()

        if not text:
            raise ImageUnderstandingError(
                "OCR هیچ متنی از تصویر استخراج نکرد.", kind="fatal"
            )

        return {
            "transcript": text,
            "visual": "",
            "kind": "scan",
            "text": text,
        }


# =============================================================
# تجزیهٔ خروجی مدل
# =============================================================

def _strip_json(raw: str) -> str:
    raw = (raw or "").strip()

    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]

    return raw.strip()


def _parse_payload(content) -> dict:
    """JSON مدل را میخواند و به dict یکدست تبدیل میکند."""

    if isinstance(content, list):
        content = "".join(
            item.get("text", "")
            for item in content
            if isinstance(item, dict)
        )

    raw = _strip_json(str(content or ""))

    try:
        data = json.loads(raw)

    except json.JSONDecodeError:

        # مدل گاهی متن را با JSON قاطی میکند: اولین { تا آخرین }
        start, end = raw.find("{"), raw.rfind("}")

        if start == -1 or end <= start:
            # خروجی JSON نبود؛ همان متن خام را بهعنوان متن تصویر میپذیریم
            if raw:
                return {
                    "transcript": raw,
                    "visual": "",
                    "kind": "other",
                    "text": raw,
                }
            raise ImageUnderstandingError(
                "خروجی مدل تصویر قابل تجزیه نبود.", kind="timeout"
            )

        try:
            data = json.loads(raw[start:end + 1])
        except json.JSONDecodeError as error:
            raise ImageUnderstandingError(
                "خروجی مدل تصویر JSON معتبر نبود.", kind="timeout"
            ) from error

    transcript = str(data.get("transcript", "") or "").strip()
    visual = str(
        data.get("visual_description", "")
        or data.get("visual", "")
        or ""
    ).strip()
    kind = str(data.get("kind", "") or "other").strip().lower()

    if kind not in {"photo", "screenshot", "diagram", "scan", "other"}:
        kind = "other"

    text = "\n".join(
        part for part in (transcript, visual) if part
    ).strip()

    if not text:
        raise ImageUnderstandingError(
            "مدل هیچ محتوایی از تصویر استخراج نکرد.", kind="fatal"
        )

    return {
        "transcript": transcript,
        "visual": visual,
        "kind": kind,
        "text": text,
    }


# =============================================================
# فکتوری
# =============================================================

def get_image_provider(name: str = None) -> ImageUnderstandingProvider:
    """
    فکتوری provider تصویر.

    ترتیب: نام دادهشده → IMAGE_PROVIDER از .env → qwen → gemini → ocr.
    اگر provider مدل Vision بالا نیاید، OCR فالبک است.
    """

    requested = (
        name or config.IMAGE_PROVIDER or "qwen"
    ).strip().lower()

    factories = {
        "qwen": QwenImageProvider,
        "gemini": GeminiImageProvider,
        "ocr": OcrImageProvider,
    }

    order = [requested] + [
        candidate
        for candidate in ("qwen", "gemini", "ocr")
        if candidate != requested
    ]

    last_error = None

    for candidate in order:

        factory = factories.get(candidate)

        if factory is None:
            continue

        try:
            return factory()

        except ImageUnderstandingError as error:

            last_error = error
            print(
                f"[!] provider تصویر «{candidate}» بالا نیامد: {error}"
            )

    raise ImageUnderstandingError(
        "هیچ provider تصویری در دسترس نیست. "
        f"آخرین خطا: {last_error}",
        kind="config",
    )