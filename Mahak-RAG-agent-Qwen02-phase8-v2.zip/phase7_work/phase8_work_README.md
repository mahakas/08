# Mahak AI v2 — Phase 8

## General Chat + Web Search + Session File Context

### مسیر عمومی

`GeneralChatService` یک مسیر Open-World دارد:

```text
User Query
  -> QueryPlanner
  -> optional session-file context
  -> optional web search
  -> ProviderOrchestrator (CHAT)
  -> Answer + web citations
```

### Web Search
وب از طریق `WebSearchAdapter` انتزاع شده است تا Provider واقعی بعداً بدون تغییر هسته متصل شود.

### Session Files
چت عمومی می‌تواند `session_file_ids` دریافت کند و از یک `FileContextProvider` برای واردکردن محتوای فایل به prompt استفاده کند. در فاز فعلی یک In-Memory provider برای تست وجود دارد؛ اتصال به فایل‌های واقعی در فاز فایل/Upload تکمیل می‌شود.

### API

`POST /api/chat/general`

نمونه:

```json
{
  "conversation_id": "g1",
  "query": "آخرین اخبار فناوری چیست؟",
  "session_file_ids": [],
  "use_web": null,
  "top_k_web": 5
}
```

`use_web = null` یعنی Planner بر اساس Query تصمیم بگیرد.

`use_web = true` یعنی در صورت فعال بودن Web Search آن را مجبور کند.

`use_web = false` یعنی فقط LLM و فایل‌های Session استفاده شوند.

## Tests

```bash
python -m pytest -q tests_v2
```

نتیجه داخلی فاز ۸:

`46 passed, 1 skipped`

Skip مربوط به تست یکپارچه Chroma در محیطی است که dependency واقعی Chroma در دسترس نباشد.
